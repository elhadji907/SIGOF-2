
<?php $__env->startSection('title', 'Détails employé'); ?>
<?php $__env->startSection('space-work'); ?>

    <section class="section profile">
        <div class="row">
            
            <span class="d-flex mt-2 align-items-baseline"><a href="<?php echo e(route('employes.index')); ?>"
                    class="btn btn-success btn-sm" title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                <p> | retour, liste des employés</p>
            </span>
            

            <div class="col-xl-12">

                <div class="card border-info mb-3">
                    <?php if($message = Session::get('status')): ?>
                        <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                            role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="card-body pt-3">
                        <!-- Bordered Tabs -->
                        <ul class="nav nav-tabs nav-tabs-bordered">

                            <li class="nav-item">
                                <button class="nav-link active" data-bs-toggle="tab"
                                    data-bs-target="#profile-overview">Employé</button>
                            </li>
                            

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#employe-edit">Modifier
                                </button>
                            </li>

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#decisions">Décision
                                </button>
                            </li>

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-autre">Info.
                                </button>
                            </li>

                        </ul>
                        <div class="tab-content pt-0">

                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <h5 class="card-title">Détails</h5>
                                    <?php if($employe->user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$employe->user->hasVerifiedEmail()): ?>
                                        <div>
                                            <p class="text-sm mt-2 text-gray-800 dark:text-gray-200 text-danger">
                                                <?php echo e(__('l\'adresse e-mail de cet employé n\'est pas vérifiée.')); ?>

                                            
                                        </div>
                                    <?php endif; ?>
                                    <small>
                                        <a href="<?php echo url('file-decision', ['$id' => $employe->id]); ?>" class='btn btn-primary btn-sm'
                                            title="télécharger la décision" target="_blank">
                                            <i class="fa fa-print" aria-hidden="true"></i>&nbsp;Télécharger décision
                                        </a>
                                    </small>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Matricule</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($employe?->matricule); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Prénom & Nom</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($user?->civilite . ' ' . $user->firstname . ' ' . $user->name); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Date & lieu naissance</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($user->date_naissance?->format('d/m/Y') . ' à ' . $user->lieu_naissance); ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Email</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($user->email); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Téléphone</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($user->telephone); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Adresse</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($user->adresse); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Date embauche</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($employe->date_embauche?->format('d/m/Y')); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">CIN</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($employe?->user?->cin); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label">Situation familiale</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php echo e($employe->user?->situation_familiale); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Direction</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($employe->direction?->name); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Fonction</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($employe->fonction?->name); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Catégorie</div>
                                    <div class="col-lg-10 col-md-8"><?php echo e($employe->category?->name); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Lois</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php $__currentLoopData = $employe->lois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b>Vu</b>&nbsp;&nbsp;
                                            <?php echo e($loi?->name); ?>;<br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Decrets</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php $__currentLoopData = $employe->decrets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decret): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b>Vu</b>&nbsp;&nbsp;
                                            <?php echo e($decret?->name); ?>;<br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Procès verbaux</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php $__currentLoopData = $employe->procesverbals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procesverbal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b>Vu</b>&nbsp;&nbsp;
                                            <?php echo e($procesverbal?->name); ?>;<br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Décisions</div>
                                    <div class="col-lg-10 col-md-8">
                                        <?php $__currentLoopData = $employe->decisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b>Vu</b>&nbsp;&nbsp;
                                            <?php echo e($decision?->name); ?>;<br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4 label ">Articles</div>
                                    <div class="col-lg-10 col-md-8" style="line-height: 100%">
                                        <?php $i = 3; ?>
                                        <b><u>Article premier</u> :
                                            <?php echo e($employe->user->civilite . ' ' . $employe->user->firstname . ' ' . $employe->user->name . ', '); ?></b>
                                        
                                        <?php echo e(' né le ' . $employe->user->date_naissance?->translatedFormat('d F Y') . ' à ' . $employe->user->lieu_naissance . ', titulaire d\'un(e) '); ?>

                                        <b> <?php echo e($employe->diplome . ', '); ?> </b> matricule de solde
                                        <b><?php echo e($employe->matricule . ', '); ?></b> précédemment <b>
                                            <?php echo e($employe->fonction_precedente . ', '); ?> </b> est nommé(e)
                                        <b><?php echo e($employe->fonction?->name); ?></b>
                                        ;<br><br>
                                        <b><u>Article 2</u> :
                                            <?php echo e($employe->user->civilite . ' ' . $employe->user->firstname . ' ' . $employe->user->name); ?></b>
                                        percevra un salaire mensuel de base de
                                        <b><?php echo e($employe?->category?->salaire_lettre . '(' . $employe?->category?->salaire . ')' . 'Francs CFA '); ?></b>
                                        correspondant à la catégorie <b><?php echo e($employe?->category?->name); ?></b> de la grille
                                        salariale du personnel de l'ONFP
                                        adoptée par le Conseil d'Administration du 21 Août 2014.
                                        ;<br><br>
                                        <b><u>Article 3</u> :
                                            <?php echo e($employe->user->civilite . ' ' . $employe->user->firstname . ' ' . $employe->user->name); ?></b>
                                        bénéficiera :<br><br>
                                        <?php $__currentLoopData = $employe->indemnites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indemnite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span
                                                style="padding-left: 50px"><?php echo e(' ' . ' - ' . $indemnite?->name); ?>;<br></span>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $employe->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <br><b><u>Article <?php echo e(++$i); ?></u> :</b>&nbsp;&nbsp;
                                            <?php echo e($article?->name); ?>;<br><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-content pt-2">
                                
                                
                                <div class="tab-pane fade profile-edit pt-3" id="employe-edit">
                                    <form method="post" action="<?php echo e(route('employes.update', $employe->id)); ?>"
                                        enctype="multipart/form-data" class="row g-3">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>
                                        <h5 class="card-title">Modification employé</h5>
                                        <!-- Profile Edit Form -->
                                        <div class="row mb-3">
                                            <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Image
                                                de
                                                profil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <img class="rounded-circle w-25" alt="Profil"
                                                    src="<?php echo e(asset($employe->user?->getImage())); ?>" width="50"
                                                    height="auto">

                                                
                                                <div class="pt-2">
                                                    <input type="file" name="image" id="image" multiple
                                                        class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> btn btn-primary btn-sm">
                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="Civilité" class="col-md-4 col-lg-3 col-form-label">Civilité<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-md-8 col-lg-9">
                                                <div class="pt-2">
                                                    <select name="civilite"
                                                        class="form-select form-select-sm <?php $__errorArgs = ['civilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        aria-label="Select" id="select-field-civilite"
                                                        data-placeholder="Choisir civilité">
                                                        <option value="<?php echo e($employe->user?->civilite); ?>">
                                                            <?php echo e($employe->user?->civilite ?? old('civilite')); ?>

                                                        </option>
                                                        <option value="Monsieur">
                                                            Monsieur
                                                        </option>
                                                        <option value="Madame">
                                                            Madame
                                                        </option>
                                                    </select>
                                                    <?php $__errorArgs = ['civilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="firstname" class="col-md-4 col-lg-3 col-form-label">Prénom<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-md-8 col-lg-9">
                                                <div class="pt-2">
                                                    <input name="firstname" type="text"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="firstname"
                                                        value="<?php echo e($employe->user?->firstname ?? old('firstname')); ?>"
                                                        autocomplete="firstname" placeholder="Votre prénom">
                                                </div>
                                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="name" class="col-md-4 col-lg-3 col-form-label">Nom<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="name" type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="name" value="<?php echo e($employe->user?->name ?? old('name')); ?>"
                                                    autocomplete="name" placeholder="Votre Nom">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="date_naissance" class="col-md-4 col-lg-3 col-form-label">Date
                                                naissance<span class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="date" name="date_naissance"
                                                    value="<?php echo e($employe->user?->date_naissance?->format('Y-m-d') ?? old('date_naissance')); ?>"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="date_naissance" placeholder="Date naissance">
                                                <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="lieu naissance" class="col-md-4 col-lg-3 col-form-label">Lieu
                                                naissance<span class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="lieu_naissance" type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="lieu_naissance"
                                                    value="<?php echo e($employe->user?->lieu_naissance ?? old('lieu_naissance')); ?>"
                                                    autocomplete="lieu_naissance" placeholder="Votre Lieu naissance">
                                                <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="adresse" class="col-md-4 col-lg-3 col-form-label">Adresse<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="adresse" type="adresse"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="adresse"
                                                    value="<?php echo e($employe->user?->adresse ?? old('adresse')); ?>"
                                                    autocomplete="adresse" placeholder="Votre adresse de résidence">
                                                <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="Email" class="col-md-4 col-lg-3 col-form-label">Email<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="email" type="email"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="Email" value="<?php echo e($employe->user?->email ?? old('email')); ?>"
                                                    autocomplete="email" placeholder="Votre adresse e-mail">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="telephone" class="col-md-4 col-lg-3 col-form-label">Téléphone<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="telephone" type="telephone"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="telephone"
                                                    value="<?php echo e($employe->user?->telephone ?? old('telephone')); ?>"
                                                    autocomplete="telephone" placeholder="Votre n° de téléphone">
                                                <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="cin" class="col-md-4 col-lg-3 col-form-label">CIN<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="cin" type="cin"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="cin" value="<?php echo e($employe?->user?->cin ?? old('cin')); ?>"
                                                    autocomplete="cin" placeholder="Votre n° de téléphone">
                                                <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="matricule" class="col-md-4 col-lg-3 col-form-label">Matricule<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="text" name="matricule"
                                                    value="<?php echo e($employe->matricule ?? old('matricule')); ?>"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['matricule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="matricule" placeholder="matricule">
                                                <?php $__errorArgs = ['matricule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="familiale" class="col-md-4 col-lg-3 col-form-label">Situation
                                                familiale<span class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <select name="situation_familiale"
                                                    class="form-select form-select-sm <?php $__errorArgs = ['situation_familiale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-familiale"
                                                    data-placeholder="Choisir situation familiale">
                                                    <option value="<?php echo e($employe->user?->situation_familiale); ?>">
                                                        <?php echo e($employe->user?->situation_familiale ?? old('situation_familiale')); ?>

                                                    </option>
                                                    <option value="Marié(e)">
                                                        Marié(e)
                                                    </option>
                                                    <option value="Célibataire">
                                                        Célibataire
                                                    </option>
                                                    <option value="Veuf(ve)">
                                                        Veuf(ve)
                                                    </option>
                                                    <option value="Divorsé(e)">
                                                        Divorsé(e)
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['situation_familiale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                        
                                        <div class="row mb-3">
                                            <label for="date_embauche" class="col-md-4 col-lg-3 col-form-label">Date
                                                embauche<span class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <input type="date" name="date_embauche"
                                                    value="<?php echo e($employe->date_embauche?->format('Y-m-d') ?? old('date_embauche')); ?>"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['date_embauche'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="date_embauche" placeholder="Date naissance">
                                                <?php $__errorArgs = ['date_embauche'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="category" class="col-md-4 col-lg-3 col-form-label">Catégorie<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <select name="categorie"
                                                    class="form-select <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-categorie"
                                                    data-placeholder="Choisir categorie">
                                                    <option value="<?php echo e($employe->category?->id); ?>">
                                                        <?php echo e($employe->category?->name); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($categorie->id); ?>">
                                                            <?php echo e($categorie->name ?? old('categorie')); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <?php $__errorArgs = ['situation_familiale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="category" class="col-md-4 col-lg-3 col-form-label">Direction<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <select name="direction"
                                                    class="form-select <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field"
                                                    data-placeholder="Choisir direction">
                                                    <option value="<?php echo e($employe->direction?->id); ?>">
                                                        <?php echo e($employe->direction?->name); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($direction->id); ?>">
                                                            <?php echo e($direction->name ?? old('direction')); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="category" class="col-md-4 col-lg-3 col-form-label">Fonction<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-md-8 col-lg-9">
                                                <select name="fonction"
                                                    class="form-select <?php $__errorArgs = ['fonction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-fonction"
                                                    data-placeholder="Choisir fonction">
                                                    <option value="<?php echo e($employe->fonction?->id); ?>">
                                                        <?php echo e($employe->fonction?->name); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $fonctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fonction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($fonction->id); ?>">
                                                            <?php echo e($fonction->name ?? old('fonction')); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['fonction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="diplome" class="col-md-4 col-lg-3 col-form-label">Diplome
                                                employé(e)</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="diplome" type="diplome"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['diplome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="diplome" value="<?php echo e($employe?->diplome ?? old('diplome')); ?>"
                                                    autocomplete="diplome" placeholder="le diplome de l'employé">
                                                <?php $__errorArgs = ['diplome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="fonction_precedente"
                                                class="col-md-4 col-lg-3 col-form-label">Fonction précédente de
                                                employé(e)</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="fonction_precedente" type="fonction_precedente"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['fonction_precedente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="fonction_precedente"
                                                    value="<?php echo e($employe?->fonction_precedente ?? old('fonction_precedente')); ?>"
                                                    autocomplete="fonction_precedente"
                                                    placeholder="la fonction précédente de l'employé">
                                                <?php $__errorArgs = ['fonction_precedente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="twitter" class="col-md-4 col-lg-3 col-form-label">Twitter
                                                profil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="twitter" type="twitter"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="twitter"
                                                    value="<?php echo e($employe->user?->twitter ?? old('twitter')); ?>"
                                                    autocomplete="twitter"
                                                    placeholder="lien de votre compte x (ex twitter)">
                                                <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="facebook" class="col-md-4 col-lg-3 col-form-label">Facebook
                                                profil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="facebook" type="facebook"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="facebook"
                                                    value="<?php echo e($employe->user?->facebook ?? old('facebook')); ?>"
                                                    autocomplete="facebook" placeholder="lien de votre compte facebook">
                                                <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="instagram" class="col-md-4 col-lg-3 col-form-label">Instagram
                                                profil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="instagram" type="instagram"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="instagram"
                                                    value="<?php echo e($employe->user?->instagram ?? old('instagram')); ?>"
                                                    autocomplete="instagram" placeholder="lien de votre compte instagram">
                                                <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="linkedin" class="col-md-4 col-lg-3 col-form-label">Linkedin
                                                profil</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="linkedin" type="linkedin"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="linkedin"
                                                    value="<?php echo e($employe->user?->linkedin ?? old('linkedin')); ?>"
                                                    autocomplete="linkedin" placeholder="lien de votre ompte linkedin">
                                                <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">Sauvegarder les
                                                modifications</button>
                                        </div>

                                        <!-- End Profile Edit Form -->

                                </div>
                                </form>
                            </div>
                        </div>
                        <div class="tab-content pt-2">
                            <div class="tab-pane fade profile-overview" id="decisions">

                                

                                <div class="card-body profile-card pt-1 d-flex flex-column">
                                    <h5 class="card-title">AJOUTER DE NOUVELLES INFORMATIONS A LA DECISION</h5>
                                    <a type="button" class="btn btn-outline-primary"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-lois')); ?>">LOI</a><br>
                                    <a type="button" class="btn btn-outline-secondary"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-decrets')); ?>">DECRET</a><br>
                                    <a type="button" class="btn btn-outline-success"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-procesverbals')); ?>">PROCES
                                        VERBAL</a><br>
                                    <a type="button" class="btn btn-outline-info"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-decisions')); ?>">DECISION</a><br>
                                    <a type="button" class="btn btn-outline-secondary"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-articles')); ?>">ARTICLE</a><br>
                                    <a type="button" class="btn btn-outline-warning"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-nomminations')); ?>">ESSAI/NOMMINATION/RECLASSEMENT</a><br>
                                    <a type="button" class="btn btn-outline-secondary"
                                        href="<?php echo e(url('employes/' . $employe->id . '/give-indemnites')); ?>">INDEMNITES</a><br>
                                </div>
                            </div>
                        </div>
                        <div class="tab-content pt-2">
                            <div class="tab-pane fade profile-overview" id="profile-autre">

                                

                                <div class="card-body profile-card pt-1 d-flex flex-column">
                                    <h5 class="card-title">Informations complémentaires</h5>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label pb-2">Créé par </div>
                                        <div class="col-lg-9 col-md-8 pb-2"><?php echo e($user_create_name); ?>

                                            <?php echo e($user->created_at->diffForHumans()); ?></div>

                                        <div class="col-lg-3 col-md-4 label pt-2">Modification</div>
                                        <?php if($user->created_at != $user->updated_at): ?>
                                            <div class="col-lg-9 col-md-8 pt-2">
                                                <?php echo e('modifié par : ' . $user_update_name); ?>

                                                <?php echo e($user->updated_at->diffForHumans()); ?></div>
                                        <?php else: ?>
                                            <div class="col-lg-9 col-md-8 pt-2">
                                                jamais modifié</div>
                                        <?php endif; ?>

                                        <div class="col-lg-3 col-md-4 label pt-3">Roles</div>
                                        <div class="col-lg-9 col-md-8 pt-3">
                                            <?php if(isset($user->roles) && $user->roles != '[]'): ?>
                                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-info"><?php echo e($role->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>

                                
                            </div>
                        </div>
                    </div><!-- End Bordered Tabs -->

                </div>
            </div>

        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/employes/show.blade.php ENDPATH**/ ?>