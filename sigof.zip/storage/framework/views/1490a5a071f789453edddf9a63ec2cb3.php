
<?php $__env->startSection('title', 'ajouter dans la formation'); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 pt-0">
                                <span class="d-flex mt-0 align-items-baseline"><a
                                        href="<?php echo e(route('formations.show', $formation->id)); ?>" class="btn btn-success btn-sm"
                                        title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                    <p> | Liste des formations</p>
                                </span>
                            </div>
                        </div>
                        <h5><u><b>Région</b></u> : <?php echo e($region->nom); ?></h5>
                        <h5><u><b>Module</b></u> : <?php echo e($module->name); ?></h5>
                        
                        <h5><u><b>Sélectionnés </b></u> : <?php echo e($candidatsretenus?->count() ?? ''); ?></h5>
                        <form method="post"
                            action="<?php echo e(url('formationdemandeurs', ['$idformation' => $formation->id, '$idmodule' => $formation->module->id, '$idlocalite' => $formation->departement->id])); ?>"
                            enctype="multipart/form-data" class="row g-3 mt-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row mb-3">
                                
                                <div class="form-check col-md-12">
                                    <table class="table datatables align-middle" id="table-individuelles">
                                        <thead>
                                            <tr>
                                                <th><input type="checkbox" class="form-check-input" id="checkAll">Civilité
                                                </th>
                                                
                                                <th>Prénom</th>
                                                <th>NOM</th>
                                                <th>Date naissance</th>
                                                <th>Lieu naissance</th>
                                                
                                                <th>Département</th>
                                                <th>Module</th>
                                                <th>Statut</th>
                                                <?php if(!empty($formation->projets_id)): ?>
                                                    <th>Projet</th>
                                                <?php endif; ?>
                                                <th><i class="bi bi-gear"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($individuelle?->numero)): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="individuelles[]"
                                                                value="<?php echo e($individuelle->id); ?>"
                                                                <?php echo e(in_array($individuelle->formations_id, $individuelleFormation) ? 'checked' : ''); ?>

                                                                <?php echo e(in_array($individuelle->formations_id, $individuelleFormationCheck) ? 'disabled' : ''); ?>

                                                                class="form-check-input <?php $__errorArgs = ['individuelles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                            <?php echo e($individuelle?->user?->civilite); ?>

                                                            <?php $__errorArgs = ['individuelles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <div><?php echo e($message); ?></div>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </td>
                                                        
                                                        <td><?php echo e($individuelle?->user?->firstname); ?></td>
                                                        <td><?php echo e($individuelle?->user?->name); ?></td>
                                                        <td><?php echo e($individuelle?->user->date_naissance?->format('d/m/Y')); ?>

                                                        </td>
                                                        <td><?php echo e($individuelle?->user->lieu_naissance); ?></td>
                                                        
                                                        <td><?php echo e($individuelle?->departement->nom); ?></td>
                                                        <td><?php echo e($individuelle?->module->name); ?></td>
                                                        <td><span
                                                                class="<?php echo e($individuelle?->statut); ?>"><?php echo e($individuelle?->statut); ?></span>
                                                        </td>
                                                        <?php if(!empty($formation->projets_id)): ?>
                                                            <td><?php echo e($individuelle?->projet?->sigle); ?></td>
                                                        <?php endif; ?>
                                                        <td>
                                                            <span class="d-flex align-items-baseline"><a
                                                                    href="<?php echo e(route('individuelles.show', $individuelle->id)); ?>"
                                                                    class="btn btn-primary btn-sm" title="voir détails"
                                                                    target="_blanck"><i class="bi bi-eye"></i></a>
                                                                <div class="filter">
                                                                    <a class="icon" href="#"
                                                                        data-bs-toggle="dropdown"><i
                                                                            class="bi bi-three-dots"></i></a>
                                                                    <ul
                                                                        class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                        <li><a class="dropdown-item btn btn-sm"
                                                                                href="<?php echo e(route('individuelles.edit', $individuelle->id)); ?>"
                                                                                class="mx-1" title="Modifier"><i
                                                                                    class="bi bi-pencil"></i>Modifier</a>
                                                                        </li>
                                                                        <li>
                                                                            <form
                                                                                action="<?php echo e(route('individuelles.destroy', $individuelle->id)); ?>"
                                                                                method="post">
                                                                                <?php echo csrf_field(); ?>
                                                                                <button type="submit"
                                                                                    class="dropdown-item show_confirm"
                                                                                    title="Supprimer"><i
                                                                                        class="bi bi-trash"></i>Supprimer</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-outline-primary btn-sm"><i
                                                class="bi bi-check2-circle"></i>&nbsp;Sélectionner</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formations/individuelles/add-individuelles.blade.php ENDPATH**/ ?>