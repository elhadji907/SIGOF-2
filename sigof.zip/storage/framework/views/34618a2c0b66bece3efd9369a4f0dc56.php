
<?php $__env->startSection('title', $operateur?->user?->username); ?>
<?php $__env->startSection('space-work'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operateur-show')): ?>
        <section
            class="section profile min-vh-0 d-flex flex-column align-items-center justify-content-center py-0 section profile">
            <div class="container-fluid">
                <div class="pagetitle">
                    
                    <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                            <li class="breadcrumb-item">Tables</li>
                            <li class="breadcrumb-item active"><?php echo e($operateur?->user?->username); ?></li>
                        </ol>
                    </nav>
                </div><!-- End Page Title -->
                <div class="row justify-content-center">
                    <?php if($message = Session::get('status')): ?>
                        <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                            role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('danger')): ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert">
                            <strong><?php echo e($message); ?></strong>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                                role="alert"><strong><?php echo e($error); ?></strong></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="flex items-center gap-4">
                        <div class="card">
                            <div class="card-body">
                                <ul class="nav nav-tabs nav-tabs-bordered">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operateur-view')): ?>
                                        <li class="nav-item">
                                            <span class="nav-link"><a href="<?php echo e(route('operateurs.index', $operateur?->id)); ?>"
                                                    class="btn btn-secondary btn-sm" title="retour"><i
                                                        class="bi bi-arrow-counterclockwise"></i></a>
                                            </span>
                                        </li>
                                    <?php endif; ?>
                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#profile-overview">Opérateur</button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link active" data-bs-toggle="tab"
                                            data-bs-target="#module-overview">Module
                                        </button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#references-overview">Références</button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#equipement-overview">Equipements</button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#formateur-overview">Formateurs</button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#localites-overview">Localités</button>
                                    </li>

                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#formation-overview">Formations</button>
                                    </li>

                                </ul>
                                <div class="d-flex justify-content-between align-items-center">
                                </div>
                                
                                <div class="tab-content pt-0">
                                    <div class="tab-pane fade profile-overview" id="profile-overview">
                                        <form method="post" action="#" enctype="multipart/form-data" class="row">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">Opérateur</h5>
                                            </div>
                                            <div class="col-12 col-md-12 col-lg-12 mb-2">
                                                <div class="label">Raison sociale</div>
                                                <div><?php echo e($operateur?->user?->operateur); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Sigle</div>
                                                <div><?php echo e($operateur?->user?->username); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Numéro agrément</div>
                                                <div><?php echo e($operateur?->numero_agrement); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Adresse email</div>
                                                <div><a
                                                        href="mailto:<?php echo e($operateur?->user?->email); ?>"><?php echo e($operateur?->user?->email); ?></a>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Téléphone fixe</div>
                                                <div><a
                                                        href="tel:+221<?php echo e($operateur?->user?->fixe); ?>"><?php echo e($operateur?->user?->fixe); ?></a>
                                                </div>
                                            </div>
                                            <?php if(isset($operateur?->user?->bp)): ?>
                                                <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                    <div class="label">Boite postale</div>
                                                    <div><?php echo e($operateur?->user?->bp); ?></div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Catégorie</div>
                                                <div><?php echo e($operateur?->user?->categorie); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Statut juridique</div>
                                                <div><?php echo e($operateur?->statut); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Autre statut</div>
                                                <div><?php echo e($operateur?->autre_statut); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Siège</div>
                                                <div><?php echo e($operateur?->departement?->nom); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Adrese</div>
                                                <div><?php echo e($operateur?->user?->adresse); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">RCCM/Ninea</div>
                                                <div><?php echo e($operateur?->user?->rccm); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">N° RCCM/Ninea</div>
                                                <div><?php echo e($operateur?->user?->ninea); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Quitus</div>
                                                <div>
                                                    <a class="btn btn-outline-secondary btn-sm" title="télécharger le quitus"
                                                        target="_blank" href="<?php echo e(asset($operateur?->getQuitus())); ?>">
                                                        <i class="bi bi-file-image"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4">
                                                <div class="label">Date délivrance quitus</div>
                                                <div><?php echo e($operateur?->debut_quitus?->diffForHumans()); ?></div>
                                            </div>
                                        </form>
                                        <form method="post" action="#" enctype="multipart/form-data" class="row">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <h5 class="card-title">Personne morale</h5>
                                            <div class="col-12 col-md-4 col-lg-4">
                                                <div class="label">Civilité</div>
                                                <div><?php echo e($operateur?->user?->civilite); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Prénom</div>
                                                <div><?php echo e($operateur?->user?->firstname); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Nom</div>
                                                <div><?php echo e($operateur?->user?->name); ?></div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Email</div>
                                                <div><a
                                                        href="mailto:<?php echo e($operateur?->user?->email_responsable); ?>"><?php echo e($operateur?->user?->email_responsable); ?></a>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Téléphone</div>
                                                <div><a
                                                        href="tel:+221<?php echo e($operateur?->user?->telephone); ?>"><?php echo e($operateur?->user?->telephone); ?></a>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-4 col-lg-4 mb-2">
                                                <div class="label">Fonction</div>
                                                <div><?php echo e($operateur?->user?->fonction_responsable); ?>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                
                                <div class="tab-content pt-2">
                                    <div class="tab-pane fade profile-overview pt-3" id="references-overview">
                                        <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>

                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">EXPERIENCES ET REFERENCES PROFESSIONNELLES</h5>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-ouvert')): ?>
                                                    <h5 class="card-title">
                                                        <a href="<?php echo e(route('showReference', ['id' => $operateur?->id])); ?>"
                                                            class="btn btn-outline-primary float-end btn-rounded btn-sm"
                                                            target="_blank">
                                                            <i class="bi bi-plus" title="Ajouter, Modifier, Supprimer"></i> </a>
                                                        
                                                    </h5>
                                                <?php endif; ?>
                                            </div>

                                            <table
                                                class="table table-bordered table-hover datatables align-middle justify-content-center table-borderless">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">DENOMINATION L'ORGANISME</th>
                                                        <th scope="col">CONTACTS</th>
                                                        <th scope="col">PERIODES D'INTERVENTION</th>
                                                        <th scope="col">DESCRIPTION DES INTERVENTIONS</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $operateur?->operateureferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateureference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($operateureference?->organisme); ?></td>
                                                            <td><?php echo e($operateureference?->contact); ?></td>
                                                            <td><?php echo e($operateureference?->periode); ?></td>
                                                            <td><?php echo e($operateureference?->description); ?></td>
                                                            
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-content pt-2">
                                    <div class="tab-pane fade profile-overview pt-3" id="equipement-overview">
                                        <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">INFRASTRUCTURES / EQUIPEMENTS</h5>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-ouvert')): ?>
                                                    <h5 class="card-title">
                                                        <a href="<?php echo e(route('showEquipement', ['id' => $operateur?->id])); ?>"
                                                            class="btn btn-outline-primary float-end btn-rounded btn-sm"
                                                            target="_blank">
                                                            <i class="bi bi-plus" title="Ajouter, Modifier, Supprimer"></i> </a>
                                                        
                                                    </h5>
                                                <?php endif; ?>
                                            </div>
                                            <table
                                                class="table table-bordered table-hover datatables align-middle justify-content-center table-borderless">
                                                <thead>
                                                    <tr>
                                                        <th>DESIGNATION</th>
                                                        <th class="text-center">QUANTITE</th>
                                                        <th class="text-center">ETAT</th>
                                                        <th class="text-center">TYPE</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $operateur?->operateurequipements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurequipement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($operateurequipement->designation); ?></td>
                                                            <td style="text-align: center;">
                                                                <?php echo e($operateurequipement->quantite); ?></td>
                                                            <td style="text-align: center;"><?php echo e($operateurequipement->etat); ?>

                                                            </td>
                                                            <td style="text-align: center;"><?php echo e($operateurequipement->type); ?>

                                                            </td>
                                                            
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-content pt-2">
                                    <div class="tab-pane fade profile-overview pt-3" id="formateur-overview">
                                        <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">FORMATEURS</h5>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-ouvert')): ?>
                                                    <h5 class="card-title">
                                                        <a href="<?php echo e(route('showFormateur', ['id' => $operateur?->id])); ?>"
                                                            class="btn btn-outline-primary float-end btn-rounded btn-sm"
                                                            target="_blank">
                                                            <i class="bi bi-plus" title="Ajouter, Modifier, Supprimer"></i> </a>
                                                        
                                                    </h5>
                                                <?php endif; ?>
                                            </div>
                                            <table
                                                class="table table-bordered table-hover datatables align-middle justify-content-center">
                                                <thead>
                                                    <tr>
                                                        <th>PRENOM(S) ET NOM</th>
                                                        <th>CHAMPS PROFESSIONNELS</th>
                                                        <th class="text-center">NOMBRE D'ANNEES D'EXPERIENCE</th>
                                                        <th>REFERENCES</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $operateur?->operateurformateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurformateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($operateurformateur->name); ?></td>
                                                            <td><?php echo e($operateurformateur->domaine); ?></td>
                                                            <td style="text-align: center;">
                                                                <?php echo e($operateurformateur->nbre_annees_experience); ?></td>
                                                            <td><?php echo e($operateurformateur->references); ?></td>
                                                            
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-content pt-2">
                                    <div class="tab-pane fade profile-overview pt-3" id="localites-overview">
                                        <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">LOCALITES</h5>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-ouvert')): ?>
                                                    <h5 class="card-title">
                                                        <a href="<?php echo e(route('showLocalite', ['id' => $operateur?->id])); ?>"
                                                            class="btn btn-outline-primary float-end btn-rounded btn-sm"
                                                            target="_blank">
                                                            <i class="bi bi-plus" title="Ajouter, Modifier, Supprimer"></i> </a>
                                                        
                                                    </h5>
                                                <?php endif; ?>
                                            </div>
                                            <table
                                                class="table table-bordered table-hover datatables align-middle justify-content-center">
                                                <thead>
                                                    <tr>
                                                        <th class="text-center">N°</th>
                                                        <th>LOCALITE</th>
                                                        <th>REGION</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $operateur?->operateurlocalites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurlocalite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="text-align: center;"><?php echo e($i++); ?></td>
                                                            <td><?php echo e($operateurlocalite->name); ?></td>
                                                            <td><?php echo e($operateurlocalite->region); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                                
                                
                                <div class="tab-content pt-2">
                                    <div class="tab-pane fade show active profile-overview pt-3" id="module-overview">
                                        <form method="post" action="<?php echo e(url('operateurmodules')); ?>"
                                            enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-ouvert')): ?>
                                                <div class="col-12 col-md-12 col-lg-12 mb-0">
                                                    <table class="table table-bordered table-hover" id="dynamicAddRemove">

                                                        <tr>
                                                            <th>MODULE OU SPECIALITE<span class="text-danger mx-1">*</span></th>
                                                            <th>NIVEAU QUALIFICATION<span class="text-danger mx-1">*</span>
                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <input type="hidden" name="operateur"
                                                                value="<?php echo e($operateur?->id); ?>">
                                                            <td>
                                                                <input type="text" name="module" id="module_operateur"
                                                                    class="form-control form-control-sm"
                                                                    placeholder="Module ou spécialité" />
                                                                <div id="moduleList"></div>
                                                                <?php echo e(csrf_field()); ?>

                                                                <p class="small fst-italic">
                                                                    <small><?php echo e(__('Le nombre de modules est limité à deux')); ?></small>
                                                                    <small>
                                                                        <?php echo e(__(' sauf pour les établissements publics ')); ?></small>
                                                                </p>
                                                            </td>
                                                            <td><input type="text" name="categorie"
                                                                    placeholder="Niveau de qualification"
                                                                    class="form-control form-control-sm" />
                                                                <p class="small fst-italic">
                                                                    <small><?php echo e(__("Préciser le niveau de qualification,l'emploi ou le métier correspondant lorsqu'il s'agit")); ?></small><br>
                                                                    <small><?php echo e(__("d'une pré-qualification ou qualification")); ?></small>
                                                                </p>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>DOMAINE<span class="text-danger mx-1">*</span></th>
                                                            <th>QUALIFICATION CORRESPONDANTE
                                                                <span class="text-danger mx-1">*</span>
                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <td><input type="text" name="domaine"
                                                                    placeholder="Domaine d'intervention"
                                                                    class="form-control form-control-sm" />
                                                            </td>
                                                            <td>
                                                                <select name="niveau_qualification"
                                                                    class="form-select form-select-sm <?php $__errorArgs = ['niveau_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    aria-label="Select" id="select-field-civilite"
                                                                    data-placeholder="Choisir qualification">
                                                                    <option value="">
                                                                        <?php echo e(old('niveau_qualification')); ?>

                                                                    </option>
                                                                    <option value="Initiation">
                                                                        Initiation
                                                                    </option>
                                                                    <option value="Pré-qualification">
                                                                        Pré-qualification
                                                                    </option>
                                                                    <option value="Qualification">
                                                                        Qualification
                                                                    </option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-outline-success btn-sm"><i
                                                                class="bi bi-printer"></i> Enregistrer</button>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                        </form><!-- End module -->

                                        <div class="col-12 col-md-12 col-lg-12 mb-0">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h5 class="card-title">DOMAINES DE COMPETENCES OU PROGRAMMES DE FORMATION</h5>
                                                <span class="card-title d-flex align-items-baseline">Statut
                                                    :&nbsp;
                                                    <span class="<?php echo e($operateur?->statut_agrement); ?> text-white btn-sm">
                                                        <?php echo e($operateur?->statut_agrement); ?></span>
                                                    

                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                </span>
                                            </div>
                                            
                                            <div class="row g-3">
                                                <table
                                                    class="table table-bordered table-hover datatables align-middle justify-content-center"
                                                    id="table-operateurModules">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">N°</th>
                                                            <th scope="col">DOMAINE</th>
                                                            <th scope="col">MODULE</th>
                                                            <th scope="col">NIVEAU QUALIFICATION</th>
                                                            <th scope="col">QUALIFICATION</th>
                                                            <th class="text-center">STATUT</th>
                                                            <th class="text-center"><i class="bi bi-gear"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $operateur?->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td style="text-align: center;"><?php echo e($i++); ?></td>
                                                                <td><?php echo e($operateurmodule?->domaine); ?></td>
                                                                <td><?php echo e($operateurmodule?->module); ?></td>
                                                                <td><?php echo e($operateurmodule?->categorie); ?></td>
                                                                <td><?php echo e($operateurmodule?->niveau_qualification); ?></td>
                                                                <td style="text-align: center;">
                                                                    <span
                                                                        class="<?php echo e($operateurmodule?->statut); ?>"><?php echo e($operateurmodule?->statut); ?></span>
                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-show')): ?>
                                                                        <span
                                                                            class="d-flex align-items-baseline justify-content-center">
                                                                            <a href="<?php echo e(route('operateurmodules.show', $operateurmodule->id)); ?>"
                                                                                class="btn btn-primary btn-sm"
                                                                                title="voir détails"><i class="bi bi-eye"></i></a>
                                                                            <div class="filter">
                                                                                <a class="icon" href="#"
                                                                                    data-bs-toggle="dropdown"><i
                                                                                        class="bi bi-three-dots"></i></a>
                                                                                <ul
                                                                                    class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                    
                                                                                    
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-update')): ?>
                                                                                        <button class="dropdown-item btn btn-sm mx-1"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#EditOperateurmoduleModal<?php echo e($operateurmodule->id); ?>">Modifier
                                                                                        </button>
                                                                                    <?php endif; ?>
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-agrement-delete')): ?>
                                                                                        <form
                                                                                            action="<?php echo e(route('operateurmodules.destroy', $operateurmodule->id)); ?>"
                                                                                            method="post">
                                                                                            <?php echo csrf_field(); ?>
                                                                                            <?php echo method_field('DELETE'); ?>
                                                                                            <button type="submit"
                                                                                                class="dropdown-item show_confirm"
                                                                                                title="Supprimer">Supprimer</button>
                                                                                        </form>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </div>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="tab-content">
                                    <div class="tab-pane fade profile-overview pt-0" id="formation-overview">
                                        <h5 class="card-title">FORMATIONS</h5>
                                        <table
                                            class="table table-bordered table-hover datatables  align-middle justify-content-center"
                                            id="table-formations">
                                            <thead>
                                                <tr>
                                                    <th>Code</th>
                                                    <th>Type</th>
                                                    <th>Intitulé formation</th>
                                                    <th>Localité</th>
                                                    <th>Modules</th>
                                                    
                                                    <th>Effectif</th>
                                                    <th>Statut</th>
                                                    <th class="text-center"><i class="bi bi-gear"></i></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1; ?>
                                                <?php $__currentLoopData = $operateur?->formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($formation?->code); ?></td>
                                                        <td><a href="#"><?php echo e($formation->types_formation?->name); ?></a>
                                                        </td>
                                                        <td><?php echo e($formation?->name); ?></td>
                                                        <td><?php echo e($formation->departement?->region?->nom); ?></td>
                                                        <?php if(isset($formation?->collectivemodule?->module)): ?>
                                                            <td><?php echo e($formation->collectivemodule->module); ?></td>
                                                            <td class="text-center">
                                                                <?php $__currentLoopData = $formation->listecollectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listecollective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($loop->last): ?>
                                                                        <a class="text-primary fw-bold"
                                                                            href="<?php echo e(route('formations.show', $formation->id)); ?>"><?php echo $loop->count ?? '0'; ?></a>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                        <?php endif; ?>
                                                        <?php if(isset($formation?->module?->name)): ?>
                                                            <td><?php echo e($formation->module->name); ?></td>
                                                            <td class="text-center">
                                                                <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($loop->last): ?>
                                                                        <a class="text-primary fw-bold"
                                                                            href="<?php echo e(route('formations.show', $formation->id)); ?>"><?php echo $loop->count ?? '0'; ?></a>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td><a href="#">
                                                                <span
                                                                    class="<?php echo e($formation?->statut); ?>"><?php echo e($formation?->statut); ?></span>
                                                            </a>
                                                        </td>
                                                        <td>
                                                            <span class="d-flex align-items-baseline"><a
                                                                    href="<?php echo e(route('formations.show', $formation->id)); ?>"
                                                                    class="btn btn-primary btn-sm" title="voir détails"><i
                                                                        class="bi bi-eye"></i></a>
                                                                <div class="filter">
                                                                    <a class="icon" href="#"
                                                                        data-bs-toggle="dropdown"><i
                                                                            class="bi bi-three-dots"></i></a>
                                                                    <ul
                                                                        class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                        <li><a class="dropdown-item btn btn-sm"
                                                                                href="<?php echo e(route('formations.edit', $formation->id)); ?>"
                                                                                class="mx-1" title="Modifier"><i
                                                                                    class="bi bi-pencil"></i>Modifier</a>
                                                                        </li>
                                                                        <li>
                                                                            <form
                                                                                action="<?php echo e(route('formations.destroy', $formation->id)); ?>"
                                                                                method="post">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('DELETE'); ?>
                                                                                <button type="submit"
                                                                                    class="dropdown-item show_confirm"
                                                                                    title="Supprimer"><i
                                                                                        class="bi bi-trash"></i>Supprimer</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                        <!-- End Table with stripped rows -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Edit Operateur-->
            <!-- Edit Operateur Module -->
            <?php $__currentLoopData = $operateur?->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="EditOperateurmoduleModal<?php echo e($operateurmodule->id); ?>" tabindex="-1"
                    role="dialog" aria-labelledby="EditOperateurmoduleModalLabel<?php echo e($operateurmodule->id); ?>"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            
                            <form method="post" action="<?php echo e(route('operateurmodules.update', $operateurmodule->id)); ?>"
                                enctype="multipart/form-data" class="row g-3">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="modal-header" id="EditOperateurmoduleModalLabel<?php echo e($operateurmodule->id); ?>">
                                    <h5 class="modal-title">Modification module
                                        opérateur</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id" value="<?php echo e($operateurmodule->id); ?>">

                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <label for="module" class="form-label">Module<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="text" name="module" id="module_operateur_edit"
                                            value="<?php echo e($operateurmodule->module ?? old('module')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="module">
                                        <div id="moduleListEdit"></div>
                                        <?php echo e(csrf_field()); ?>

                                        <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <label for="domaine" class="form-label">Domaine<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="text" name="domaine"
                                            value="<?php echo e($operateurmodule->domaine ?? old('domaine')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['domaine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="domaine">
                                        <?php $__errorArgs = ['domaine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <label for="categorie" class="form-label">Catégorie<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="text" name="categorie"
                                            value="<?php echo e($operateurmodule->categorie ?? old('categorie')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="categorie">
                                        <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <label for="niveau_qualification" class="form-label">Niveau de qualification<span
                                                class="text-danger mx-1">*</span></label>
                                        <select name="niveau_qualification" class="form-select selectpicker"
                                            data-live-search="true <?php $__errorArgs = ['niveau_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Select" id="select-field-niveau_qualification-update"
                                            data-placeholder="Choisir niveau qualification">
                                            <option value="<?php echo e($operateurmodule->niveau_qualification); ?>">
                                                <?php echo e($operateurmodule->niveau_qualification ?? old('niveau_qualification')); ?>

                                            </option>
                                            <option value="Initiation">
                                                Initiation
                                            </option>
                                            <option value="Pré-qualification">
                                                Pré-qualification
                                            </option>
                                            <option value="Qualification">
                                                Qualification
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['niveau_qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                    <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                                        Modifier</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Edit Operateur Module-->
            <!-- The Modal Delete -->
            <?php $__currentLoopData = $operateur?->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal" id="myModal<?php echo e($operateurmodule->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Confirmation</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                                Êtes-vous sûre de bien vouloir supprimer ?
                            </div>

                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <form method="post" action="<?php echo e(route('operateurmodules.destroy', $operateurmodule->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                            Non</button>
                                        <button class="btn btn-danger">
                                            <i class="bi bi-trash"></i> Oui
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-operateurModules', {
            layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            },
            "order": [
                [0, 'asc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/operateurs/show.blade.php ENDPATH**/ ?>