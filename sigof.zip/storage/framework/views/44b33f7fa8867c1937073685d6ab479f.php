<nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

        
        <!-- End Search Icon-->

        <?php if (! (auth()->user()->unReadNotifications->isEmpty())): ?>
            <li class="nav-item dropdown">

                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <span class="badge bg-primary badge-number"><?php echo auth()->user()->unReadNotifications->count(); ?></span>
                </a><!-- End Notification Icon -->

                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                    <li class="dropdown-header">
                        <?php echo auth()->user()->unReadNotifications->count(); ?> nouvelles notifications
                        <a href="<?php echo e(url('notifications')); ?>"><span class="badge rounded-pill bg-primary p-2 ms-2">Voir
                                toutes</span></a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <?php $__currentLoopData = auth()->user()->unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item d-flex align-items-centers"
                            href="<?php echo e(route('courriers.showFromNotification', ['courrier' => $notification->data['courrierId'], 'notification' => $notification->id])); ?>">
                            <li class="notification-item">
                                <i class="bi bi-check-circle text-success"></i>
                                <div>
                                    <h4><?php echo $notification->data['firstname']; ?>&nbsp;<?php echo $notification->data['name']; ?></h4>
                                    <p><?php echo $notification->data['courrierTitle']; ?></p>
                                    <p><?php echo $notification->created_at->diffForHumans(); ?></p>
                                </div>
                            </li>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr class="dropdown-divider">
                    <li class="dropdown-footer">
                        <a href="<?php echo e(url('notifications')); ?>">Voir toutes les notifications</a>
                    </li>

                </ul><!-- End Notification Dropdown Items -->

            </li>
        <?php endif; ?>
        <!-- End Notification Nav -->

        
        <!-- End Messages Icon -->

        
        <!-- End Messages Dropdown Items -->

        
        <!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

            <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                
                <img class="rounded-circle" alt="Profil" src="<?php echo e(asset(Auth::user()->getImage())); ?>">
                <span class="d-none d-md-block dropdown-toggle ps-2">
                    <?php if(Auth::user()->operateur): ?>
                        <?php echo e(Auth::user()->username); ?>

                    <?php elseif(Auth::user()->name): ?>
                        <?php echo e(Auth::user()->civilite . ' ' . Auth::user()->name); ?>

                    <?php else: ?>
                        <?php echo e(Auth::user()->username); ?>

                    <?php endif; ?>
                </span>
            </a><!-- End Profile Iamge Icon -->

            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                <li class="dropdown-header">
                    <h6>
                        <?php if(Auth::user()->operateur): ?>
                            <?php echo e(Auth::user()->username); ?>

                        <?php elseif(Auth::user()->name): ?>
                            <?php echo e(Auth::user()->civilite . ' ' . Auth::user()->firstname . ' ' . Auth::user()->name); ?>

                        <?php else: ?>
                            <?php echo e(Auth::user()->username); ?>

                        <?php endif; ?>
                    </h6>
                    <span><a href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a></span>
                    
                </li>
                <li>
                    <hr class="dropdown-divider">
                </li>

                <li>
                    <a class="dropdown-item d-flex align-items-center" href="<?php echo e(url('/profil')); ?>">
                        <i class="bi bi-person"></i>
                        <span>Mon Profil</span>
                    </a>
                </li>
                <li>
                    <hr class="dropdown-divider">
                </li>

                

                <li>
                    
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item show_confirm_disconnect"><i
                                class="bi bi-box-arrow-in-left"></i>Se
                            déconnecter</button>
                    </form>
                </li>

            </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\html\sigof-2\resources\views/layout/page-navbar.blade.php ENDPATH**/ ?>