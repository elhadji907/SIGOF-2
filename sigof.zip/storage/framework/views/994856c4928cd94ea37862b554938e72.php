
<?php $__env->startSection('title', 'ONFP - toutes les notifications'); ?>
<?php $__env->startSection('space-work'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employe-view')): ?>
            <div class="pagetitle">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                        <li class="breadcrumb-item">Tables</li>
                        <li class="breadcrumb-item active">Notifications</li>
                    </ol>
                </nav>
            </div>
            <section class="section faq">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                        

                        <?php if(isset(Auth::user()->employee->arrives)): ?>
                            <div class="accordion">
                                <div class="accordion-item">
                                    <div class="accordion-body">
                                        <div class="activity">
                                            <?php $__empty_1 = true; $__currentLoopData = Auth::user()->unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                    <div class="row">
                                                        
                                                        <div class="accordion-body">
                                                            <span class="card-title"><?php echo $notification->data['firstname'] . ' ' . $notification->data['name']; ?></span>
                                                            <div class="activity-item d-flex">
                                                                <div
                                                                    class="activite-label col-2 col-md-2 col-lg-2 col-sm-2 col-xs-2 col-xxl-2 small fst-italic">
                                                                    <?php echo $notification->created_at->diffForHumans(); ?> <br>
                                                                    <a
                                                                        href="<?php echo e(route('courriers.showFromNotification', ['courrier' => $notification->data['courrierId'], 'notification' => $notification->id])); ?>"><button
                                                                            type="button"
                                                                            class="btn btn-outline-info btn-sm">Lire</button></a>
                                                                </div>
                                                                
                                                                <div
                                                                    class="activity-content col-10 col-md-10 col-lg-10 col-sm-10 col-xs-10 col-xxl-10">
                                                                    <p><?php echo $notification->data['courrierTitle']; ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <hr>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <div class="alert alert-info">Aucun commentaire non lu disponible</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info"> <?php echo e(__("Vous n'avez pas de courrier à votre nom")); ?> </div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/courriers/notifications.blade.php ENDPATH**/ ?>