
<?php $__env->startSection('title', 'ONFP - ' . $formation->name); ?>
<?php $__env->startSection('space-work'); ?>

    <section
        class="section profile min-vh-0 d-flex flex-column align-items-center justify-content-center py-0 section profile">
        <div class="container-fluid">
            <div class="pagetitle">
                
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                        <li class="breadcrumb-item">Tables</li>
                        <li class="breadcrumb-item active">Formations <?php echo e($type_formation); ?></li>
                    </ol>
                </nav>
            </div>
            <!-- End Title -->
            <div class="row justify-content-center">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="flex items-center gap-4">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-bordered">

                                <li class="nav-item">
                                    <span class="nav-link"><a href="<?php echo e(route('formations.index', $formation->id)); ?>"
                                            class="btn btn-secondary btn-sm" title="retour"><i
                                                class="bi bi-arrow-counterclockwise"></i></a>
                                    </span>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-overview">Détails
                                        formation</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#responsable-overview">Opérateur</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                        data-bs-target="#beneficiaires-overview">Bénéficiaires
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#module-overview">Module
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#ingenieur-overview">Ingénieur
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#evaluation-overview">Évaluation
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#retrait-attestation-overview">Attestations
                                    </button>
                                </li>

                            </ul>
                            <div class="tab-content pt-0">
                                <div class="tab-pane fade profile-overview pt-3" id="profile-overview">
                                    <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <span class="card-title">Détails formation : <span
                                                class="<?php echo e($formation?->statut); ?> text-white">
                                                <?php echo e($formation?->statut); ?></span>
                                        </span>
                                        <div class="col-12 col-md-12 col-lg-12 mb-0">
                                            <div class="label">Intitulé formation</div>
                                            <div><?php echo e($formation?->name); ?></div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Code</div>
                                            <div><?php echo e($formation?->code); ?></div>
                                        </div>
                                        <?php if(isset($formation?->module?->name)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Module</div>
                                                <div><?php echo e($formation?->module?->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Région</div>
                                            <div><?php echo e($formation?->departement->region->nom); ?></div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Département</div>
                                            <div><?php echo e($formation->departement->nom); ?>

                                            </div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Adresse exacte</div>
                                            <div><?php echo e($formation?->lieu); ?>

                                            </div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Type formation</div>
                                            <div><?php echo e($formation?->types_formation?->name); ?></div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Statut juridique</div>
                                            <div><?php echo e($formation?->statut); ?></div>
                                        </div>
                                        <div class="col-12 col-md-3 col-lg-3 mb-0">
                                            <div class="label">Niveau qualification</div>
                                            <div><?php echo e($formation->niveau_qualification); ?></div>
                                        </div>
                                        <?php if(isset($formation?->date_debut)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Date début</div>
                                                <div><?php echo e($formation?->date_debut->format('d/m/Y')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->date_fin)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Date fin</div>
                                                <div><?php echo e($formation?->date_fin->format('d/m/Y')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->effectif_prevu)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Effectif prévu</div>
                                                <div><?php echo e($formation?->effectif_prevu); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->prevue_h)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Prévu homme</div>
                                                <div><?php echo e($formation?->prevue_h); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->prevue_f)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Prévu femmes</div>
                                                <div><?php echo e($formation?->prevue_f); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->frais_operateurs)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Frais opérateur</div>
                                                <div><?php echo e(number_format($formation?->frais_operateurs, 2, ',', ' ')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->frais_add)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Frais additionels</div>
                                                <div><?php echo e(number_format($formation?->frais_add, 2, ',', ' ')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->autes_frais)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Autres frais</div>
                                                <div><?php echo e(number_format($formation?->autes_frais, 2, ',', ' ')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->projets_id)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Projet</div>
                                                <div><?php echo e($formation?->projet?->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->programmes_id)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Programme</div>
                                                <div><?php echo e($formation?->programme?->name); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($formation?->choixoperateur?->description)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Choix opérateur</div>
                                                <div><?php echo e($formation?->choixoperateur?->description); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(!empty($formation?->attestation)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 mb-0">
                                                <div class="label">Titres - Attestations</div>
                                                <div><?php echo e($formation?->attestation); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </form>
                                    <div class="col-12 col-md-12 col-lg-12 mb-0 text-center">
                                        <a class="btn btn-outline-primary"
                                            href="<?php echo e(route('formations.edit', $formation->id)); ?>" class="mx-1"
                                            title="Modifier"><i class="bi bi-pencil"></i>&nbsp;Modifier</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="tab-content">
                                <div class="tab-pane fade profile-overview" id="responsable-overview">
                                    <?php if(!empty($operateur)): ?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h5 class="card-title">
                                                <?php echo e($formation?->operateur?->user?->operateur . '(' . $formation?->operateur?->user?->username . ')'); ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operateur-check')): ?>
                                                    <a class="btn btn-info btn-sm" title=""
                                                        href="<?php echo e(route('operateurs.show', $formation?->operateur?->id)); ?>"><i
                                                            class="bi bi-eye"></i></a>&nbsp;
                                                    <a href="<?php echo e(url('formationoperateurs', ['$idformation' => $formation->id, '$idmodule' => $formation->module->id, '$idlocalite' => $formation->departement->region->id])); ?>"
                                                        class="btn btn-primary float-end btn-sm">
                                                        <i class="bi bi-pencil" title="Changer opérateur"></i> </a>
                                                <?php endif; ?>
                                            </h5>
                                        </div>
                                    <?php elseif(!empty($module)): ?>
                                        <div class="pt-2">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operateur-check')): ?>
                                                <a href="<?php echo e(url('formationoperateurs', ['$idformation' => $formation?->id, '$idmodule' => $formation?->module?->id, '$idlocalite' => $formation?->departement?->region?->id])); ?>"
                                                    class="btn btn-primary float-end btn-sm">
                                                    <i class="bi bi-person-plus-fill" title="Ajouter opérateur"></i> </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <?php if(!empty($operateur)): ?>
                                            <h1 class="card-title">
                                                Liste des formations
                                            </h1>
                                            <div class="row g-3">
                                                <table class="table table-bordered table-hover datatables"
                                                    id="table-formations">
                                                    <thead>
                                                        <tr>
                                                            <th>Code</th>
                                                            <th>Type</th>
                                                            <th>Intitulé formation</th>
                                                            <th>Localité</th>
                                                            
                                                            
                                                            <th>Effectif</th>
                                                            <th>Statut</th>
                                                            <th class="text-center">#</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $operateur?->formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($operateurformation?->code); ?></td>
                                                                <td><a
                                                                        href="#"><?php echo e($operateurformation->types_formation?->name); ?></a>
                                                                </td>
                                                                <td><?php echo e($operateurformation?->name); ?></td>
                                                                <td><?php echo e($operateurformation->departement?->region?->nom); ?>

                                                                </td>
                                                                
                                                                
                                                                <td class="text-center">
                                                                    <?php $__currentLoopData = $operateurformation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($loop->last): ?>
                                                                            <a class="text-primary fw-bold"
                                                                                href="<?php echo e(route('formations.show', $operateurformation->id)); ?>"><?php echo $loop->count ?? '0'; ?></a>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </td>
                                                                <td><a href="#"><span
                                                                            class="<?php echo e($operateurformation?->statut); ?>"><?php echo e($operateurformation?->statut); ?></span></a>
                                                                </td>
                                                                <td>
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-show')): ?>
                                                                        <span class="d-flex align-items-baseline"><a
                                                                                href="<?php echo e(route('formations.show', $operateurformation->id)); ?>"
                                                                                class="btn btn-primary btn-sm"
                                                                                title="voir détails"><i
                                                                                    class="bi bi-eye"></i></a>
                                                                            <div class="filter">
                                                                                <a class="icon" href="#"
                                                                                    data-bs-toggle="dropdown"><i
                                                                                        class="bi bi-three-dots"></i></a>
                                                                                <ul
                                                                                    class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-update')): ?>
                                                                                        <li><a class="dropdown-item btn btn-sm"
                                                                                                href="<?php echo e(route('formations.edit', $operateurformation->id)); ?>"
                                                                                                class="mx-1" title="Modifier"><i
                                                                                                    class="bi bi-pencil"></i>Modifier</a>
                                                                                        </li>
                                                                                    <?php endif; ?>

                                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-delete')): ?>
                                                                                        <li>
                                                                                            <form
                                                                                                action="<?php echo e(route('formations.destroy', $operateurformation->id)); ?>"
                                                                                                method="post">
                                                                                                <?php echo csrf_field(); ?>
                                                                                                <?php echo method_field('DELETE'); ?>
                                                                                                <button type="submit"
                                                                                                    class="dropdown-item show_confirm"
                                                                                                    title="Supprimer"><i
                                                                                                        class="bi bi-trash"></i>Supprimer</button>
                                                                                            </form>
                                                                                        </li>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </div>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php else: ?>
                                            <div class="alert alert-info mt-5">Aucun opérateur pour le moment !!!</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-content pt-0">
                                <div class="tab-pane fade show active profile-overview" id="beneficiaires-overview">
                                    <?php if(!empty($module)): ?>
                                        <div class="col-12 col-md-12 col-lg-12 mb-0">
                                            <div class="d-flex justify-content-between align-items-center mt-3">
                                                <span class="card-title d-flex align-items-baseline">Code formation :&nbsp;
                                                    <span class="badge bg-info text-white">
                                                        <?php echo e($formation?->code); ?></span>
                                                </span>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-show')): ?>
                                                    <span class="card-title d-flex align-items-baseline">Statut formation
                                                        :&nbsp;
                                                        <span class="<?php echo e($formation?->statut); ?> text-white">
                                                            <?php echo e($formation?->statut); ?></span>
                                                        <div class="filter">
                                                            <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                                                    class="bi bi-three-dots"></i></a>
                                                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('demarrer-formation')): ?>
                                                                    <form
                                                                        action="<?php echo e(route('validation-formations.update', $formation?->id)); ?>"
                                                                        method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('PUT'); ?>
                                                                        <button
                                                                            class="show_confirm_valider btn btn-sm mx-1">Démarrer</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('terminer-formation')): ?>
                                                                    <form action="<?php echo e(route('formationTerminer')); ?>"
                                                                        method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button
                                                                            class="show_confirm_valider btn btn-sm mx-1">Terminer</button>
                                                                    </form>
                                                                <?php endif; ?>

                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('annuler-formation')): ?>
                                                                    <button class="btn btn-sm mx-1" data-bs-toggle="modal"
                                                                        data-bs-target="#RejetDemandeModal">Annuler
                                                                    </button>
                                                                <?php endif; ?>
                                                                <hr>
                                                                <form action="<?php echo e(route('ficheSuivi')); ?>" method="post"
                                                                    target="_blank">
                                                                    <?php echo csrf_field(); ?>
                                                                    
                                                                    <input type="hidden" name="id"
                                                                        value="<?php echo e($formation->id); ?>">
                                                                    <button class="btn btn-sm mx-1">Fiche de suivi</button>
                                                                </form>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pv-formation')): ?>
                                                                    <form action="<?php echo e(route('pvVierge')); ?>" method="post"
                                                                        target="_blank">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">PV (vierge)</button>
                                                                    </form>
                                                                    <form action="<?php echo e(route('pvEvaluation')); ?>" method="post"
                                                                        target="_blank">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">PV (finale)</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lettre-formation')): ?>
                                                                    <hr>
                                                                    <form action="<?php echo e(route('lettreEvaluation')); ?>" method="post"
                                                                        target="_blank">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">Lettre mission</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lettre-formation')): ?>
                                                                    <form action="<?php echo e(route('abeEvaluation')); ?>" method="post"
                                                                        target="_blank">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">A B E</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('email-formation')): ?>
                                                                    <hr>
                                                                    <form action="<?php echo e(route('sendFormationEmail')); ?>"
                                                                        method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">Démarrage
                                                                            (e-mail)</button>
                                                                    </form>
                                                                    <form action="<?php echo e(route('sendWelcomeEmail')); ?>"
                                                                        method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        
                                                                        <input type="hidden" name="id"
                                                                            value="<?php echo e($formation->id); ?>">
                                                                        <button class="btn btn-sm mx-1">Résultats
                                                                            (e-mail)</button>
                                                                    </form>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </span>
                                                <?php endif; ?>
                                                <div class="float-end">
                                                    <a href="<?php echo e(url('formationdemandeurs', ['$idformation' => $formation->id, '$idmodule' => $formation?->module?->id, '$idlocalite' => $formation->departement->region->id])); ?>"
                                                        class="btn btn-outline-primary btn-rounded btn-sm">
                                                        <i class="bi bi-plus" title="Ajouter demandeur"></i> </a>
                                                </div>
                                            </div>
                                            <div class="row g-3 pt-3">
                                                <table
                                                    class="table table-bordered table-hover datatables align-middle justify-content-center table-borderless"
                                                    id="table-operateurModules">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">N°</th>
                                                            <th class="text-center">N° Dossier</th>
                                                            <th class="text-center">Civilité</th>
                                                            <th class="text-center">CIN</th>
                                                            <th>Prénom</th>
                                                            <th>NOM</th>
                                                            <th class="text-center">Date naissance</th>
                                                            <th class="text-center">Lieu de naissance</th>
                                                            
                                                            
                                                            <th class="text-center">Note</th>
                                                            
                                                            
                                                            
                                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-suivi-formes-view')): ?>
                                                                <th width='3%' class="text-center">Suivi</th>
                                                            <?php endif; ?>
                                                            <th width='2%' class="text-center"><i
                                                                    class="bi bi-gear"></i>
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td class="text-center"><?php echo e($i++); ?></td>
                                                                <td class="text-center"><?php echo e($individuelle?->numero); ?></td>
                                                                <td class="text-center">
                                                                    <?php echo e($individuelle?->user?->civilite); ?>

                                                                </td>
                                                                <td style="text-align: center;">
                                                                    <?php echo e($individuelle?->user?->cin); ?></td>
                                                                <td><?php echo e($individuelle?->user?->firstname); ?></td>
                                                                <td><?php echo e($individuelle?->user?->name); ?></td>
                                                                <td style="text-align: center;">
                                                                    <?php echo e($individuelle?->user->date_naissance?->format('d/m/Y')); ?>

                                                                </td>
                                                                <td class="text-center">
                                                                    <?php echo e($individuelle?->user?->lieu_naissance); ?></td>
                                                                <td class="text-center">
                                                                    <?php echo e($individuelle?->note_obtenue ?? ' '); ?></td>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-suivi-formes-view')): ?>
                                                                    <td style="text-align: center;">
                                                                        <?php if(empty($individuelle?->suivi)): ?>
                                                                            <form
                                                                                action="<?php echo e(route('SuivreFormes', $individuelle?->id)); ?>"
                                                                                method="post">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php echo method_field('PUT'); ?>
                                                                                <button
                                                                                    class="show_confirm_suivi btn btn-dark rounded-pill btn-sm float-center">Suivre</button>
                                                                            </form>
                                                                        <?php else: ?>
                                                                            <button type="button"
                                                                                class="btn btn-success rounded-pill btn-sm float-center">Suivi</button>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                <?php endif; ?>
                                                                <td>
                                                                    <span class="d-flex align-items-baseline"><a
                                                                            href="<?php echo e(route('individuelles.show', $individuelle?->id)); ?>"
                                                                            class="btn btn-primary btn-sm"
                                                                            title="voir détails"><i
                                                                                class="bi bi-eye"></i></a>
                                                                        <div class="filter">
                                                                            <a class="icon" href="#"
                                                                                data-bs-toggle="dropdown"><i
                                                                                    class="bi bi-three-dots"></i></a>
                                                                            <ul
                                                                                class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('retirer-demandeur-formation')): ?>
                                                                                    <button class="btn btn-sm mx-1"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#indiponibleModal<?php echo e($individuelle->id); ?>">Retirer
                                                                                    </button>
                                                                                <?php endif; ?>
                                                                            </ul>
                                                                        </div>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-info mt-3">Aucun bénéficiaire pour le moment !!!</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade module-overview pt-3" id="module-overview">
                                    <?php if(!empty($module)): ?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h5 class="card-title">
                                                <?php echo e($module?->name); ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('module-check')): ?>
                                                    <a class="btn btn-info btn-sm" title=""
                                                        href="<?php echo e(route('modules.show', $module?->id)); ?>"><i
                                                            class="bi bi-eye"></i></a>&nbsp;
                                                    <a href="<?php echo e(url('formationmodules', ['$idformation' => $formation->id, '$idlocalite' => $formation->departement->region->id])); ?>"
                                                        class="btn btn-primary float-end btn-sm">
                                                        <i class="bi bi-pencil" title="Changer module"></i></a>
                                                <?php endif; ?>
                                            </h5>
                                        </div>
                                    <?php else: ?>
                                        <div>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('module-check')): ?>
                                                <a href="<?php echo e(url('moduleformations', ['$idformation' => $formation->id, '$idlocalite' => $formation->departement->region->id])); ?>"
                                                    class="btn btn-primary float-end btn-sm">
                                                    <i class="bi bi-plus" title="Ajouter module"></i> </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="alert alert-info mt-5">Aucun module pour le moment !!!</div>
                                    <?php endif; ?>
                                    

                                </div>
                            </div>
                            
                            <div class="tab-content">
                                <div class="tab-pane fade ingenieur-overview" id="ingenieur-overview">
                                    <?php if(!empty($ingenieur)): ?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h5 class="card-title">
                                                <?php echo e($ingenieur?->name); ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingenieur-check')): ?>
                                                    <a class="btn btn-info btn-sm" title=""
                                                        href="<?php echo e(route('ingenieurs.show', $ingenieur?->id)); ?>"><i
                                                            class="bi bi-eye"></i></a>&nbsp;
                                                    <a href="<?php echo e(url('formationingenieurs', ['$idformation' => $formation->id])); ?>"
                                                        class="btn btn-primary float-end btn-sm">
                                                        <i class="bi bi-pencil" title="Changer ingenieur"></i> </a>
                                                <?php endif; ?>
                                            </h5>
                                            <h5 class="card-title">
                                                Agent de suivi
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingenieur-check')): ?>
                                                    <button type="button" class="btn btn-outline-primary btn-sm"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#EditAgentSuiviModal<?php echo e($formation->id); ?>">
                                                        <i class="bi bi-plus" title="Ajouter un agent de suivi"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </h5>
                                        </div>
                                    <?php else: ?>
                                        <div class="pb-2">
                                            <a href="<?php echo e(url('formationingenieurs', ['$idformation' => $formation->id])); ?>"
                                                class="btn btn-primary float-end btn-sm">
                                                <i class="bi bi-plus" title="Ajouter ingenieur"></i> </a>
                                        </div>
                                        <div class="alert alert-info mt-5">Aucun ingénieur pour le moment !!!</div>
                                    <?php endif; ?>
                                    <div class="col-12 col-md-12 col-lg-12 mb-0">
                                        <?php if(isset($ingenieur)): ?>
                                            <h1 class="card-title">
                                                Liste des formations
                                                <?php if(isset($ingenieur)): ?>
                                                    de <?php echo e($ingenieur?->name); ?>

                                                <?php endif; ?>
                                            </h1>
                                            <div class="row g-3">
                                                <table class="table table-bordered table-hover datatables"
                                                    id="table-formations">
                                                    <thead>
                                                        <tr>
                                                            <th>Code</th>
                                                            <th>Type</th>
                                                            <th>Intitulé formation</th>
                                                            <th>Localité</th>
                                                            
                                                            
                                                            <th>Effectif</th>
                                                            <th>Statut</th>
                                                            <th class="text-center"><i class="bi bi-gear"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $ingenieur?->formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingenieurformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($ingenieurformation?->code); ?></td>
                                                                <td><a
                                                                        href="#"><?php echo e($ingenieurformation->types_formation?->name); ?></a>
                                                                </td>
                                                                <td><?php echo e($ingenieurformation?->name); ?></td>
                                                                <td><?php echo e($ingenieurformation->departement?->region?->nom); ?></td>
                                                                
                                                                
                                                                <td class="text-center">
                                                                    <?php $__currentLoopData = $ingenieurformation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($loop->last): ?>
                                                                            <a class="text-primary fw-bold"
                                                                                href="<?php echo e(route('formations.show', $ingenieurformation->id)); ?>"><?php echo $loop->count ?? '0'; ?></a>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </td>
                                                                <td><a href="#"><span
                                                                            class="<?php echo e($ingenieurformation?->statut); ?>"><?php echo e($ingenieurformation?->statut); ?></span></a>
                                                                </td>
                                                                <td>
                                                                    <span class="d-flex align-items-baseline"><a
                                                                            href="<?php echo e(route('formations.show', $ingenieurformation->id)); ?>"
                                                                            class="btn btn-primary btn-sm"
                                                                            title="voir détails"><i class="bi bi-eye"></i></a>
                                                                        <div class="filter">
                                                                            <a class="icon" href="#"
                                                                                data-bs-toggle="dropdown"><i
                                                                                    class="bi bi-three-dots"></i></a>
                                                                            <ul
                                                                                class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                <li><a class="dropdown-item btn btn-sm"
                                                                                        href="<?php echo e(route('formations.edit', $ingenieurformation->id)); ?>"
                                                                                        class="mx-1" title="Modifier"><i
                                                                                            class="bi bi-pencil"></i>Modifier</a>
                                                                                </li>
                                                                                <li>
                                                                                    <form
                                                                                        action="<?php echo e(route('formations.destroy', $ingenieurformation->id)); ?>"
                                                                                        method="post">
                                                                                        <?php echo csrf_field(); ?>
                                                                                        <?php echo method_field('DELETE'); ?>
                                                                                        <button type="submit"
                                                                                            class="dropdown-item show_confirm"
                                                                                            title="Supprimer"><i
                                                                                                class="bi bi-trash"></i>Supprimer</button>
                                                                                    </form>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade module-overview pt-3" id="evaluation-overview">
                                    <?php if(isset($module)): ?>
                                        <div class="col-12 col-md-12 col-lg-12 mb-0">
                                            <form method="post"
                                                action="<?php echo e(url('notedemandeurs', ['$idformation' => $formation->id])); ?>"
                                                enctype="multipart/form-data" class="row g-3">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <h1 class="card-title"> Liste des bénéficiaires :
                                                        <?php echo e($count_demandes); ?></h1>
                                                    <h5 class="card-title">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jury-formation')): ?>
                                                            Membres du jury
                                                            <button type="button" class="btn btn-outline-primary btn-sm"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#EditMembresJuryModal<?php echo e($formation->id); ?>">
                                                                <i class="bi bi-plus" title="Ajouter les membres du jury"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </h5>
                                                </div>
                                                <div class="row g-3">
                                                    <table class="table table-bordered table-hover datatables"
                                                        id="table-evaluation">
                                                        <thead>
                                                            <tr>
                                                                <th>N°</th>
                                                                
                                                                <th>Civilité</th>
                                                                <th>CIN</th>
                                                                <th>Prénom</th>
                                                                <th>NOM</th>
                                                                <th>Date naissance</th>
                                                                <th>Lieu de naissance</th>
                                                                <th>Note<span class="text-danger mx-1">*</span></th>
                                                                <th>Observations</th>
                                                                
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $i = 1; ?>
                                                            <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($i++); ?></td>
                                                                    
                                                                    <td><?php echo e($individuelle?->user?->civilite); ?></td>
                                                                    <td><?php echo e($individuelle?->user?->cin); ?></td>
                                                                    <td><?php echo e($individuelle?->user?->firstname); ?></td>
                                                                    <td><?php echo e($individuelle?->user?->name); ?></td>
                                                                    <td><?php echo e($individuelle?->user->date_naissance?->format('d/m/Y')); ?>

                                                                    </td>
                                                                    <td><?php echo e($individuelle?->user->lieu_naissance); ?></td>
                                                                    <td><input type="number"
                                                                            value="<?php echo e($individuelle?->note_obtenue); ?>"
                                                                            name="notes[]" placeholder="note" step="0.01"
                                                                            min="0" max="20">
                                                                        <input type="hidden" name="individuelles[]"
                                                                            value="<?php echo e($individuelle?->id); ?>">
                                                                    </td>
                                                                    <td style="text-align: center; vertical-align: middle;">
                                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('evaluer-formation')): ?>
                                                                            <button type="button"
                                                                                class="btn btn-outline-primary btn-sm"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#EditDemandeurModal<?php echo e($individuelle->id); ?>">
                                                                                <i class="bi bi-plus" title="Observations"></i>
                                                                            </button>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    </table>
                                                </div>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('evaluation-formation')): ?>
                                                    <div class="text-center">
                                                        <button type="submit" class="btn btn-outline-primary"><i
                                                                class="bi bi-check2-circle"></i>&nbsp;Save</button>
                                                    </div>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade attestation-overview pt-1" id="retrait-attestation-overview">
                                    <?php if(isset($module)): ?>
                                        <div class="col-12 col-md-12 col-lg-12 mb-0">
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h1 class="card-title">Retrait des attestations</h1>
                                                <h5 class="card-title">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attestation-formation')): ?>
                                                        Informer
                                                        <button type="button" class="btn btn-outline-primary btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#EditRemiseAttestationsModal<?php echo e($formation->id); ?>">
                                                            <i class="bi bi-plus" title="Ajouter les membres du jury"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </h5>
                                            </div>
                                            <div class="row g-3">
                                                <table class="table table-bordered table-hover datatables"
                                                    id="table-evaluation">
                                                    <thead>
                                                        <tr>
                                                            <th>N°</th>
                                                            
                                                            <th>Civilité</th>
                                                            <th>CIN</th>
                                                            <th>Prénom</th>
                                                            <th>NOM</th>
                                                            <th>Date naissance</th>
                                                            <th>Lieu de naissance</th>
                                                            <th class="text-center">Note<span
                                                                    class="text-danger mx-1">*</span></th>
                                                            <th>Diplôme</th>
                                                            <th class="col"><i class="bi bi-gear"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($i++); ?></td>
                                                                
                                                                <td><?php echo e($individuelle?->user?->civilite); ?></td>
                                                                <td><?php echo e($individuelle?->user?->cin); ?></td>
                                                                <td><?php echo e($individuelle?->user?->firstname); ?></td>
                                                                <td><?php echo e($individuelle?->user?->name); ?></td>
                                                                <td><?php echo e($individuelle?->user?->date_naissance?->format('d/m/Y')); ?>

                                                                </td>
                                                                <td><?php echo e($individuelle?->user?->lieu_naissance); ?></td>
                                                                <td style="text-align: center">
                                                                    
                                                                    <span><?php echo e($individuelle?->note_obtenue); ?></span>
                                                                </td>
                                                                <td style="text-align: center; vertical-align: middle;">
                                                                    <?php if(isset($individuelle?->retrait_diplome)): ?>
                                                                        <button type="button"
                                                                            class="btn btn-outline-success btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#EditShowModal<?php echo e($individuelle?->id); ?>">
                                                                            <i class="bi bi-eye" title="Attestation"></i>
                                                                        </button>
                                                                        
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td style="text-align: center; vertical-align: middle;">
                                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attestation-formation')): ?>
                                                                        <button type="button"
                                                                            class="btn btn-outline-primary btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#EditAttestationsModal<?php echo e($individuelle->id); ?>">
                                                                            <i class="bi bi-plus" title="Attestation"></i>
                                                                        </button>
                                                                    <?php endif; ?>
                                                                </td>
                                                                
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                </table>
                                            </div>
                                            
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Edit Operateur-->
        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="indiponibleModal<?php echo e($individuelle->id); ?>" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post" action="<?php echo e(url('indisponibles', ['$idformation' => $formation->id])); ?>"
                            enctype="multipart/form-data" class="row">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-header">
                                <h5 class="modal-title"><i class="bi bi-plus" title="Ajouter"></i> Retirer demandeur</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="individuelleid" value="<?php echo e($individuelle->id); ?>">
                                <label for="motif" class="form-label">Justification du retrait</label>
                                <textarea name="motif" id="motif" rows="5"
                                    class="form-control form-control-sm <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Expliquer les raisons du retrait de ce bénéficiaire"><?php echo e(old('motif')); ?></textarea>
                                <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                <button type="submit" class="btn btn-danger btn-sm"><i
                                        class="bi bi-arrow-right-circle"></i>
                                    Retirer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Remise attestation-->
        <div class="modal fade" id="EditRemiseAttestationsModal<?php echo e($formation->id); ?>" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="<?php echo e(url('remiseAttestations', ['$idformation' => $formation->id])); ?>"
                        enctype="multipart/form-data" class="row">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-plus" title="Ajouter"></i> Situation des attestations
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="formationid" value="<?php echo e($formation->id); ?>">
                            <label for="region" class="form-label">Statut attestations<span
                                    class="text-danger mx-1">*</span></label>
                            <select name="statut"
                                class="form-select form-select-sm <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                aria-label="Select" id="select-field-statut-attestations"
                                data-placeholder="Choisir statut attestations">
                                <option value="<?php echo e($formation?->attestation ?? old('statut')); ?>">
                                    <?php echo e($formation?->attestation ?? old('statut')); ?>

                                </option>
                                <option value="disponibles">
                                    disponibles
                                </option>
                                <option value="En cours">
                                    En cours
                                </option>
                                <option value="retirés">
                                    retirers
                                </option>
                            </select>
                            <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <div><?php echo e($message); ?></div>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary btn-sm"><i
                                    class="bi bi-arrow-right-circle"></i>
                                Valider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="modal fade" id="RejetDemandeModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="<?php echo e(route('validation-formations.destroy', $formation->id)); ?>"
                        enctype="multipart/form-data" class="row">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-plus" title="Ajouter"></i> Rejet demande</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <label for="motif" class="form-label">Motifs du rejet</label>
                            <textarea name="motif" id="motif" rows="5"
                                class="form-control form-control-sm <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Enumérer les motifs du rejet"><?php echo e(old('motif')); ?></textarea>
                            <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <div><?php echo e($message); ?></div>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-printer"></i>
                                Annuler</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="EditDemandeurModal<?php echo e($individuelle->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="EditDemandeurModalLabel<?php echo e($individuelle->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post" action="<?php echo e(route('individuelles.updateObservations')); ?>"
                            enctype="multipart/form-data" class="row g-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="modal-header" id="EditDemandeurModalLabel<?php echo e($individuelle->id); ?>">
                                <h5 class="modal-title">Ajouter un commentaire ou une observation</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?php echo e($individuelle->id); ?>">
                                <label for="floatingInput" class="mb-3">Observation<span
                                        class="text-danger mx-1">*</span></label>
                                <textarea name="observations" id="observations" cols="30" rows="5"
                                    class="form-control form-control-sm <?php $__errorArgs = ['observations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Observations"
                                    autofocus><?php echo e($individuelle->observations ?? old('observations')); ?></textarea>
                                <?php $__errorArgs = ['observations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                                    Valider</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="EditAttestationsModal<?php echo e($individuelle->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="EditAttestationsModalLabel<?php echo e($individuelle->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post" action="<?php echo e(route('individuelles.updateAttestations')); ?>"
                            enctype="multipart/form-data" class="row g-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                            <div class="modal-header" id="EditAttestationsModalLabel<?php echo e($individuelle->id); ?>">
                                <h5 class="modal-title">Retrait attestation de
                                    <?php echo e($individuelle?->user?->civilite . ' ' . $individuelle?->user?->firstname . ' ' . $individuelle?->user?->name); ?>

                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?php echo e($individuelle->id); ?>">
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <div class="row g-3">
                                        <label for="retrait" class="form-label">Choisir<span
                                                class="text-danger mx-1">*</span></label>
                                        <div class="col-6 col-md-6 col-lg-6 col-sm-6 col-xs-6 col-xxl-6">
                                            <label class="form-check-label" for="moi">
                                                Moi même
                                            </label>
                                            <input type="radio" name="moi" value="moi"
                                                class="form-check-input <?php $__errorArgs = ['moi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['moi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-6 col-md-6 col-lg-6 col-sm-6 col-xs-6 col-xxl-6">
                                            <label class="form-check-label" for="autre">
                                                Autre
                                            </label>
                                            <input type="radio" name="autre" value="autre"
                                                class="form-check-input <?php $__errorArgs = ['autre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['autre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12 pt-3">
                                    <label for="date_retrait" class="form-label">Date retrait<span
                                            class="text-danger mx-1">*</span></label>
                                    <input type="date" name="date_retrait"
                                        value="<?php echo e(date('Y-m-d') ?? old('date_retrait')); ?>"
                                        class="form-control form-control-sm <?php $__errorArgs = ['date_retrait'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="date_retrait" placeholder="Date naissance">
                                    <?php $__errorArgs = ['date_retrait'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <div><?php echo e($message); ?></div>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <hr>
                                <label for="form-label">Si autre</label>
                                <hr>
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <label for="cin" class="form-label">N° CIN</label>
                                    <input minlength="13" maxlength="14" type="text" name="cin"
                                        value="<?php echo e(old('cin')); ?>"
                                        class="form-control form-control-sm <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Numéro carte d'identité nationale">
                                    <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <div><?php echo e($message); ?></div>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                                        class="form-control form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Prénom et NOM">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <div><?php echo e($message); ?></div>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <label for="commentaires" class="form-label">Commentaires</label>
                                    <input type="text" maxlength="150" name="commentaires"
                                        value="<?php echo e(old('commentaires')); ?>"
                                        class="form-control form-control-sm <?php $__errorArgs = ['commentaires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Un petit commentaire...">
                                    <?php $__errorArgs = ['commentaires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <div><?php echo e($message); ?></div>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                                    Valider</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php $__currentLoopData = $formation->individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="EditShowModal<?php echo e($individuelle->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="EditShowModalLabel<?php echo e($individuelle->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        
                        <div class="modal-header" id="EditShowModalLabel<?php echo e($individuelle->id); ?>">
                            <h5 class="modal-title">Attestation de
                                <?php echo e($individuelle?->user?->civilite . ' ' . $individuelle?->user?->firstname . ' ' . $individuelle?->user?->name); ?>

                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo e($individuelle->id); ?>">
                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                <div class="row g-3">
                                    <label for="retrait" class="form-label">Informations !<span
                                            class="text-danger mx-1">*</span></label>
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <label class="form-check-label" for="moi">
                                            <?php echo e($individuelle?->retrait_diplome); ?>

                                        </label>

                                    </div>

                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div class="modal fade" id="EditAgentSuiviModal<?php echo e($formation->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="EditAgentSuiviModalLabel<?php echo e($formation->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="<?php echo e(route('formations.updateAgentSuivi')); ?>"
                        enctype="multipart/form-data" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="modal-header" id="EditAgentSuiviModalLabel<?php echo e($formation->id); ?>">
                            <h5 class="modal-title">Ajouter un agent de suivi</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo e($formation->id); ?>">
                            <div class="form-floating mb-3">
                                <input type="text" name="suivi_dossier"
                                    value="<?php echo e($formation?->suivi_dossier ?? old('suivi_dossier')); ?>"
                                    class="form-control form-control-sm <?php $__errorArgs = ['suivi_dossier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="suivi_dossier" placeholder="Nom de l'agent de suivi" autofocus>
                                <?php $__errorArgs = ['suivi_dossier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="floatingInput">Agent suivi</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="date" name="date_suivi"
                                    value="<?php echo e($formation?->date_suivi?->format('Y-m-d') ?? old('date_suivi')); ?>"
                                    class="form-control form-control-sm <?php $__errorArgs = ['date_suivi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="date_suivi" placeholder="Date suivi">
                                <?php $__errorArgs = ['date_suivi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="floatingInput">Date suivi</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                                Vavilider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="EditMembresJuryModal<?php echo e($formation->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="EditMembresJuryModalLabel<?php echo e($formation->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form method="post" action="<?php echo e(route('formations.updateMembresJury')); ?>"
                        enctype="multipart/form-data" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="modal-header" id="EditMembresJuryModalLabel<?php echo e($formation->id); ?>">
                            <h5 class="modal-title text-center">Evaluation formation <br>
                                <?php echo e($formation?->module?->name); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo e($formation->id); ?>">

                            <div class="row">
                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>N° convention<span class="text-danger mx-1">*</span></label>
                                        <input type="text" name="numero_convention"
                                            value="<?php echo e($formation?->numero_convention ?? old('numero_convention')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['numero_convention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="numero_convention" placeholder="n° convention">
                                        <?php $__errorArgs = ['numero_convention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>Date convention<span class="text-danger mx-1">*</span></label>
                                        <input type="date" name="date_convention"
                                            value="<?php echo e($formation?->date_convention?->format('Y-m-d') ?? old('date_convention')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['date_convention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="date_convention" placeholder="date_convention">
                                        <?php $__errorArgs = ['date_convention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>Date évaluation<span class="text-danger mx-1">*</span></label>
                                        <input type="date" name="date_pv"
                                            value="<?php echo e($formation?->date_pv?->format('Y-m-d') ?? old('date_pv')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['date_pv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="date_pv" placeholder="date_pv">
                                        <?php $__errorArgs = ['date_pv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>Montant indemnité de membre <span class="text-danger mx-1">*</span></label>
                                        <input type="number" name="frais_evaluateur" min="0" step="0.001"
                                            value="<?php echo e($formation?->frais_evaluateur ?? old('frais_evaluateur')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['frais_evaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="frais_evaluateur" placeholder="Montant indemnité de membre ">
                                        <?php $__errorArgs = ['frais_evaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label for="evaluateur" class="form-label">Evaluateur<span
                                                class="text-danger mx-1">*</span></label>
                                        <select name="evaluateur"
                                            class="form-select <?php $__errorArgs = ['evaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Select" id="select-field" data-placeholder="Choisir evaluateur">
                                            <option value="<?php echo e($formation?->evaluateur?->id); ?>">
                                                <?php if(!empty($formation?->evaluateur?->name)): ?>
                                                    <?php echo e($formation?->evaluateur?->name . ', ' . $formation?->evaluateur?->fonction); ?>

                                                <?php endif; ?>
                                            </option>
                                            <?php $__currentLoopData = $evaluateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($evaluateur->id); ?>">
                                                    <?php echo e($evaluateur?->name . ', ' . $evaluateur?->fonction ?? old('evaluateur')); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['evaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                


                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label for="evaluateur" class="form-label">Evaluateur ONFP<span
                                                class="text-danger mx-1">*</span></label>
                                        <select name="onfpevaluateur"
                                            class="form-select <?php $__errorArgs = ['onfpevaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Select" id="select-field-onfp"
                                            data-placeholder="Choisir evaluateur ONFP">
                                            <option value="<?php echo e($formation->onfpevaluateur?->id); ?>">
                                                <?php if(!empty($formation?->onfpevaluateur?->name)): ?>
                                                    <?php echo e($formation?->onfpevaluateur?->name . ', ' . $formation?->onfpevaluateur?->fonction); ?>

                                                <?php endif; ?>
                                            </option>
                                            <?php $__currentLoopData = $onfpevaluateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onfpevaluateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($onfpevaluateur->id); ?>">
                                                    <?php echo e($onfpevaluateur?->name . ', ' . $onfpevaluateur?->fonction ?? old('onfpevaluateur')); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['onfpevaluateur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>Titre (convention)<span class="text-danger mx-1">*</span></label>
                                        

                                        <select name="titre" class="form-select  <?php $__errorArgs = ['titre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Select" id="select-field-titre" data-placeholder="Choisir titre">
                                            <option>
                                                <?php echo e($formation?->titre ?? ($formation?->referentiel?->titre ?? old('titre'))); ?>

                                            </option>
                                            <option value="null">
                                                Aucun
                                            </option>
                                            <?php $__currentLoopData = $referentiels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referentiel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($referentiel?->titre); ?>">
                                                    <?php echo e($referentiel?->titre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['titre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-12 col-md-12 col-lg-6 col-sm-12 col-xs-12 col-xxl-6">
                                    <div class="mb-3">
                                        <label>Type certification<span class="text-danger mx-1">*</span></label>
                                        <select name="type_certification"
                                            class="form-select  <?php $__errorArgs = ['type_certification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            aria-label="Select" id="select-field-type_certification_update"
                                            data-placeholder="Choisir type certification">
                                            <option value="<?php echo e($formation?->type_certification); ?>">
                                                <?php echo e($formation?->type_certification ?? old('type_certification')); ?>

                                            </option>
                                            <option value="<?php echo e(old('c')); ?>">
                                                <?php echo e(old('type_certification')); ?>

                                            </option>
                                            <option value="Titre">
                                                Titre
                                            </option>
                                            <option value="Attestation">
                                                Attestation
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['type_certification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>
                            <div class="mb-3">

                                <label for="membres_jury">Autre membres du jury</label>

                                <textarea name="membres_jury" id="membres_jury" cols="30" rows="3"
                                    class="form-control form-control-sm <?php $__errorArgs = ['membres_jury'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Membre 1; Membre 2; Membre 3 " autofocus><?php echo e($formation->membres_jury ?? old('membres_jury')); ?></textarea>

                                
                                <?php $__errorArgs = ['membres_jury'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">

                                <label for="recommandations">Recommandations</label>

                                <textarea name="recommandations" id="recommandations" cols="30" rows="3s"
                                    class="form-control form-control-sm <?php $__errorArgs = ['recommandations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Recommandations"
                                    autofocus><?php echo e($formation?->recommandations ?? old('recommandations')); ?></textarea>
                                <?php $__errorArgs = ['recommandations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn btn-sm"
                                data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary btn btn-sm"><i class="bi bi-printer"></i>
                                Vavilider</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/formations/individuelles/show.blade.php ENDPATH**/ ?>