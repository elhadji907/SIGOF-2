<!DOCTYPE html>
<html lang="fr">
    <title><?php echo e($title); ?></title>

<head>

    <meta charset="utf-8" />
    <style>
        
        @page {
            margin-top: 0cm;
        }

        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            font-size: 14px;
            line-height: 20px;
            color: color: rgb(0, 0, 0);
            ;
        }

        /** RTL **/
        .rtl {
            imputation: rtl;
        }

        .invoice-box table tr.heading td {
            background: rgb(255, 255, 255);
            border: 1px solid #000000;
            font-weight: bold;
        }

        .invoice-box table tr.total td {
            border-top: 0px solid #eee;
            border-bottom: 0px solid #eee;
            border-left: 0px solid #eee;
            border-right: 0px solid #eee;
            background: #eee;
            font-weight: bold;
        }

        .invoice-box table tr.item td {
            border: 1px solid #000000;
        }

        table {
            border-left: 0px solid rgb(0, 0, 0);
            border-right: 0;
            border-top: 0px solid rgb(0, 0, 0);
            border-bottom: 0;
            width: 100%;
            border-spacing: 0px;
        }

        table td,
        table th {
            border-left: 0;
            border-right: 0px solid rgb(0, 0, 0);
            border-top: 0;
            border-bottom: 0px solid rgb(0, 0, 0);
        }

        .X {
            background-color: #DC3545;
            color: white;
            padding: 4px 8px;
            text-align: center;
            border-radius: 25% 10%;
            /* border-radius: 5px; */
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//db.onlinewebfonts.com/c/dd79278a2e4c4a2090b763931f2ada53?family=ArialW02-Regular" rel="stylesheet"
        type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
</head>

<body>
    <div class="invoice-box">
        <table class="table table-responsive" cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td>
                        
                        
                        <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('assets/img/entete_lettre_mission.png')))); ?>"
                        style="width: 100%; max-width: 300px" />
                    </td>
                    <td colspan="2" align="right" valign="top">
                        <p>
                            <b> <?php echo e(__("Date d'imputation : ")); ?> </b>
                            <?php if(isset($courrier->date_imp)): ?>
                                <?php echo e($courrier->date_imp?->format('d/m/Y')); ?> <br />
                            <?php else: ?>
                                <?php echo e(__('- - - - - - - - - - - -')); ?> <br />
                            <?php endif; ?>
                            <b> <?php echo e(__("Date d'arrivée : ")); ?> </b>
                            <?php echo e($courrier->date_recep?->format('d/m/Y')); ?> <br />
                            <b> <?php echo e(__('N° du courrier : ')); ?> </b> <span
                                style="color:red"><?php echo e('CA-'.$arrive->numero); ?></span> <br />
                                <h1><br><u><?php echo e(__("FICHE D'IMPUTATION")); ?></u></h1>

                        </p>
                    </td>
                </tr>
            </tbody>
        </table>
       
        <table class="table table-responsive">
            <tbody>
                <tr>
                    <td colspan="4" align="left" valign="top">
                        <p>
                            <b><?php echo e(__('Expéditeur')); ?></u></b> : <?php echo e(mb_strtoupper($courrier->expediteur)); ?><br>
                            <b><?php echo e(__('Réf')); ?></u></b> : <?php echo e($courrier->reference); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                            <b><?php echo e(__('du')); ?></u></b> :
                            <?php echo e($courrier->date_recep?->format('d/m/Y')); ?><br>
                            <b><?php echo e(__('Objet')); ?></u></b> : <?php echo e(ucfirst($courrier->objet)); ?><br>
                            
                        </p>
                        <table class="table table-responsive table-striped">
                            <tbody>
                                

                                <tr class="item">
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td style="padding-left:5px;">
                                            <?php echo $direction ?? 'Aucune'; ?>

                                            <span style="float:right;">
                                                <span style="color: red; padding-right:5px;"><?php echo in_array($direction, $arriveDirections) ? "X" : ""; ?></span></span>
                                        </td>
                                        <?php if($i % 4 == 0): ?>
                                </tr>
                                <tr class="item">
                                    <?php endif; ?>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>

                    </td>
                    <td style="padding-left:10px; padding-top:20px; float:right;" colspan="4" valign="top">
                        <table class="table table-responsive table-striped">
                            <tbody>
                                <tr class="heading">
                                    <td colspan="4" align="center"><b><?php echo e(__('ACTIONS ATTENDUES')); ?></b>
                                    </td>
                                </tr>
                                <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="item">
                                        <td colspan="2" style="padding-left:5px;">
                                            <?php echo e($action); ?>

                                        </td>
                                        <td colspan="2" align="center">
                                            <?php if($action == $courrier->description): ?>
                                                <span style="color: red;"><?php echo e(__('X')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
        
        <table class="table table-responsive">
            <tbody>
                <tr>
                    <td colspan="2" align="left" valign="top">
                        <?php if(isset($courrier->observation)): ?>
                            <h4><u>Observations</u></h4>
                            <?php echo e($courrier->observation); ?>

                        <?php else: ?>
                            <h4><u>Observations</u>:
                        <?php endif; ?>
                        </h4>

                    </td>
                </tr>
            </tbody>
        </table>
        
       
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/courriers/arrives/arrive-coupon.blade.php ENDPATH**/ ?>