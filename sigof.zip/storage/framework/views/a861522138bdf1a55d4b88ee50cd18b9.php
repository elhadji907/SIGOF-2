
<?php $__env->startSection('title', 'Détails demande individuelle'); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section min-vh-0 d-flex flex-column align-items-center justify-content-center py-0 section profile">
        <div class="container">
            <div class="row justify-content-center">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="col-12 col-lg-12 col-md-12 d-flex flex-column align-items-center justify-content-center">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mt-3">

                                
                                
                                

                                <?php if(auth()->user()->hasRole('super-admin|admin|DIOF|DEC')): ?>
                                    <span class="d-flex mt-2 align-items-baseline"><a
                                            href="<?php echo e(route('individuelles.index')); ?>" class="btn btn-secondary btn-sm"
                                            title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                        <p> | retour</p>
                                    </span>
                                <?php else: ?>
                                    <span class="d-flex mt-2 align-items-baseline"><a
                                            href="<?php echo e(route('demandesIndividuelle')); ?>" class="btn btn-info btn-sm"
                                            title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                        <p> | retour</p>
                                    </span>
                                <?php endif; ?>
                                

                                <span>
                                    <nav class="header-nav ms-auto">
                                        <ul class="d-flex align-items-center">
                                            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                                                <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                                                    <i class="bi bi-chat-left-text m-1"></i>
                                                    <span class="badge bg-success badge-number"
                                                        title="<?php echo e($individuelle?->statut); ?>"><?php echo e($individuelle?->validationindividuelles->count()); ?></span>
                                                </a>
                                            </a>
                                            <!-- End Notification Icon -->
                                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
                                                <li class="dropdown-header">
                                                    Vous avez
                                                    <?php echo e($individuelle?->validationindividuelles->count() . ' validation(s)'); ?>

                                                    <a href="<?php echo e(url('validationsRejetMessage/' . $individuelle?->id)); ?>"><span
                                                            class="badge rounded-pill bg-primary p-2 ms-2">Voir
                                                            toutes</span></a>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider">
                                                </li>
                                                <?php $i = 1; ?>
                                                <?php $__currentLoopData = $individuelle?->validationindividuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count => $validationindividuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($count < 2): ?>
                                                        <li class="message-item">
                                                            <a
                                                                href="<?php echo e(url('validationsRejetMessage/' . $individuelle?->id)); ?>">
                                                                <img src="<?php echo e(asset($validationindividuelle->user->getImage())); ?>"
                                                                    alt="" class="rounded-circle">
                                                                <div>
                                                                    <h4><?php echo e($validationindividuelle->user->firstname . ' ' . $validationindividuelle->user->name); ?>

                                                                    </h4>
                                                                    <p><span class="<?php echo e($validationindividuelle->action); ?>">
                                                                            <?php echo e($validationindividuelle->action); ?>

                                                                        </span>
                                                                        
                                                                    </p>
                                                                    <p><?php echo $validationindividuelle->created_at->diffForHumans(); ?></p>
                                                                </div>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <hr class="dropdown-divider">
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($individuelle?->validationindividuelles->count() != '0'): ?>
                                                    <li class="dropdown-footer">
                                                        <a
                                                            href="<?php echo e(url('validationsRejetMessage/' . $individuelle?->id)); ?>">Voir
                                                            toutes les validations</a>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </ul>
                                    </nav>
                                </span>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                                    <span class="d-flex align-items-baseline">
                                        <span class="<?php echo e($individuelle?->statut); ?>"><?php echo e($individuelle?->statut); ?></span>
                                        <div class="filter">
                                            <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                                    class="bi bi-three-dots"></i></a>
                                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                <form
                                                    action="<?php echo e(route('validation-individuelles.update', $individuelle?->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <button class="show_confirm_valider btn btn-sm mx-1">Accepter</button>
                                                </form>
                                                
                                                <button class="btn btn-sm mx-1" data-bs-toggle="modal"
                                                    data-bs-target="#RejetDemandeModal">Rejeter
                                                </button>
                                                
                                                
                                                
                                                
                                                
                                                
                                            </ul>
                                        </div>
                                    </span>
                                <?php endif; ?>
                                
                            </div>
                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <form method="post" action="<?php echo e(url('individuelles/' . $individuelle?->id)); ?>"
                                    enctype="multipart/form-data" class="row g-3">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Formation sollicitée</div>
                                        <div><?php echo e($individuelle?->module?->name); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Numéro</div>
                                        <div><?php echo e($individuelle?->numero); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Civilité</div>
                                        <div><?php echo e($individuelle?->user?->civilite); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">N° CIN</div>
                                        <div><?php echo e($individuelle?->user?->cin); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Prénom</div>
                                        <div><?php echo e($individuelle?->user->firstname); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Nom</div>
                                        <div><?php echo e($individuelle?->user->name); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div for="date_naissance" class="label">Date naissance</div>
                                        <div><?php echo e($individuelle?->user->date_naissance?->format('d/m/Y')); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Lieu naissance</div>
                                        <div><?php echo e($individuelle?->user->lieu_naissance); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Adresse</div>
                                        <div><?php echo e($individuelle?->user->adresse); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Email</div>
                                        <div><?php echo e($individuelle?->user->email); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Téléphone personnel</div>
                                        <div><?php echo e($individuelle?->user->telephone); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Téléphone secondaire</div>
                                        <div><?php echo e($individuelle?->user?->telephone_secondaire); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Lieu de formation</div>
                                        <div><?php echo e($individuelle?->departement?->nom); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Situation familiale</div>
                                        <div><?php echo e($individuelle?->user->situation_familiale); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Situation professionnelle</div>
                                        <div><?php echo e($individuelle?->user->situation_professionnelle); ?></div>
                                    </div>


                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Niveau étude</div>
                                        <div><?php echo e($individuelle?->niveau_etude); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Diplôme académique</div>
                                        <div><?php echo e($individuelle?->diplome_academique); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Si autre ? précisez</div>
                                        <div><?php echo e($individuelle?->autre_diplome_academique); ?></div>
                                    </div>

                                    <?php if(!empty($individuelle?->option_diplome_academique)): ?>
                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Option du diplôme</div>
                                            <div><?php echo e($individuelle?->option_diplome_academique); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Etablissement académique</div>
                                        <div><?php echo e($individuelle?->etablissement_academique); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Diplôme professionnel</div>
                                        <div><?php echo e($individuelle?->diplome_professionnel); ?></div>
                                    </div>

                                    <?php if(!empty($individuelle?->autre_diplome_professionnel)): ?>
                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Si autre ? précisez</div>
                                            <div><?php echo e($individuelle?->autre_diplome_professionnel); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Etablissement professionnel</div>
                                        <div><?php echo e($individuelle?->etablissement_professionnel); ?></div>
                                    </div>

                                    <?php if(!empty($individuelle?->specialite_diplome_professionnel)): ?>
                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Spécialité</div>
                                            <div><?php echo e($individuelle?->specialite_diplome_professionnel); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Votre projet après la formation</div>
                                        <div><?php echo e($individuelle?->projet_poste_formation); ?></div>
                                    </div>

                                    <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                        <div class="label">Qualification et autres diplômes</div>
                                        <div><?php echo e($individuelle?->qualification); ?></div>
                                    </div>

                                    <?php if(isset($individuelle?->note_obtenue)): ?>
                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Note</div>
                                            <div><?php echo e($individuelle?->note_obtenue); ?></div>
                                        </div>

                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Appréciation</div>
                                            <div><?php echo e($individuelle?->appreciation); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($individuelle?->experience)): ?>
                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Expériences et stages</div>
                                            <div><?php echo e($individuelle?->experience); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="label">Informations complémentaires sur
                                            le projet
                                            professionnel</div>
                                        <div><?php echo e($individuelle?->projetprofessionnel); ?></div>
                                    </div>

                                    <?php if(!empty($individuelle?->projets_id)): ?>
                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <div class="label">Projet</div>
                                            <div>
                                                <?php echo e($individuelle?->projet?->name . ' (' . $individuelle?->projet?->sigle . ')'); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="text-center">
                                        <a href="<?php echo e(route('individuelles.edit', $individuelle?->id)); ?>"
                                            class="btn btn-primary btn-sm text-white" title="voir détails"><i
                                                class="bi bi-pencil"></i>&nbsp;Modifier</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="RejetDemandeModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form method="post" action="<?php echo e(route('validation-individuelles.destroy', $individuelle?->id)); ?>"
                        enctype="multipart/form-data" class="row">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-plus" title="Ajouter"></i> Rejet demande</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <label for="motif" class="form-label">Motifs du rejet</label>
                            <textarea name="motif" id="motif" rows="5"
                                class="form-control form-control-sm <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Enumérer les motifs du rejet"><?php echo e(old('motif')); ?></textarea>
                            <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <div><?php echo e($message); ?></div>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-printer"></i>
                                Rejeter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/individuelles/show.blade.php ENDPATH**/ ?>