
<?php $__env->startSection('title', 'ONFP - ' . $projet?->name); ?>
<?php $__env->startSection('space-work'); ?>

    <section
        class="section profile min-vh-0 d-flex flex-column align-items-center justify-content-center py-0 section profile">
        <div class="container-fluid">
            <div class="pagetitle">
                
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                        <li class="breadcrumb-item">Tables</li>
                        <li class="breadcrumb-item active">Projet <?php echo e($projet?->sigle); ?></li>
                    </ol>
                </nav>
            </div>
            <!-- End Title -->
            <div class="row justify-content-center">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="flex items-center gap-4">
                    <div class="card">
                        <div class="card-body">
                            <ul class="nav nav-tabs nav-tabs-bordered">

                                <li class="nav-item">
                                    <span class="nav-link"><a href="<?php echo e(route('projets.index', $projet?->id)); ?>"
                                            class="btn btn-secondary btn-sm" title="retour"><i
                                                class="bi bi-arrow-counterclockwise"></i></a>
                                    </span>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-overview">Projet
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                        data-bs-target="#modules-overview">Modules</button>
                                </li>

                                
                                <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab"
                                            data-bs-target="#localites-overview">Localités</button>
                                    </li>
                                <?php endif; ?>
                            </ul>

                            <div class="tab-content">

                                <div class="tab-pane fade profile-overview" id="profile-overview">
                                    <form method="post" action="#" enctype="multipart/form-data" class="row g-3">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <h5 class="card-title">À propos</h5>
                                        <?php if(isset($projet?->description)): ?>
                                            <div class="label">Description</div>
                                            <p class="fst-italic"><?php echo e($projet?->description); ?></p>
                                        <?php endif; ?>

                                        

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <div class="label">Intitulé projet / programme</div>
                                            <div><?php echo e($projet?->name); ?></div>
                                        </div>

                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Sigle projet / programme</div>
                                            <div><?php echo e($projet?->sigle); ?></div>
                                        </div>

                                        <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                            <div class="label">Date signature</div>
                                            <div><?php echo e($projet?->date_signature->format('d/m/Y')); ?></div>
                                        </div>
                                        <?php if(isset($projet?->budjet)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                                <div class="label">Budjet</div>
                                                <div><?php echo e(number_format($projet?->budjet, 2, ',', ' ')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($projet?->duree)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                                <div class="label">Durée</div>
                                                <div><?php echo e($projet?->duree . ' mois'); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($projet?->debut)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                                <div class="label">Date début</div>
                                                <div><?php echo e($projet?->debut->format('d/m/Y')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(isset($projet?->fin)): ?>
                                            <div class="col-12 col-md-3 col-lg-3 col-sm-12 col-xs-12 col-xxl-3">
                                                <div class="label">Date fin</div>
                                                <div><?php echo e($projet?->fin->format('d/m/Y')); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </form>
                                </div>
                                <div class="tab-pane fade show active profile-overview" id="modules-overview">
                                    <form method="post" action="<?php echo e(url('projetmodules')); ?>" enctype="multipart/form-data"
                                        class="row g-3">
                                        <?php echo csrf_field(); ?>

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <h5 class="card-title">Ajouter nouveau module</h5>
                                            <table class="table table-bordered" id="dynamicAddRemove">
                                                <tr>
                                                    <th>Modules<span class="text-danger mx-1">*</span></th>
                                                    <th>Domaines<span class="text-danger mx-1">*</span></th>
                                                    <th>Effectif<span class="text-danger mx-1">*</span></th>
                                                </tr>
                                                <tr>
                                                    <input type="hidden" name="projet" value="<?php echo e($projet?->id); ?>">
                                                    <td>
                                                        <input type="text" name="module" id="module_name"
                                                            class="form-control form-control-sm"
                                                            placeholder="Enter module" />
                                                        <div id="countryList"></div>
                                                        <?php echo e(csrf_field()); ?>

                                                    </td>
                                                    <td><input type="text" name="domaine" placeholder="Entrer un domaine"
                                                            class="form-control form-control-sm" /></td>
                                                    <td><input type="text" name="effectif" placeholder="Entrer effectif"
                                                            class="form-control form-control-sm" /></td>
                                                </tr>
                                            </table>
                                            <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                                <div class="text-center">
                                                    <button type="submit" class="btn btn-outline-success btn-sm"><i
                                                            class="bi bi-printer"></i> Enregistrer</button>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </form><!-- End module -->

                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <h5 class="card-title">Modules</h5>
                                            <h5 class="card-title">Effectif total: <?php echo e($projet?->effectif); ?></h5>
                                        </div>
                                        
                                        <div class="row g-3">
                                            <table
                                                class="table datatables align-middle justify-content-center table-borderless"
                                                id="table-operateurModules">
                                                <thead>
                                                    <tr>
                                                        <th width="5%" scope="col">N°</th>
                                                        <th scope="col">Module</th>
                                                        <th scope="col">Domaines</th>
                                                        <th width="5%" scope="col">Effectif</th>
                                                        <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                                            <th width="5%" class="col"><i class="bi bi-gear"></i>
                                                            </th>
                                                        <?php endif; ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $projet?->projetmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projetmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="text-align: center;"><?php echo e($i++); ?></td>
                                                            <td><?php echo e($projetmodule?->module); ?></td>
                                                            <td><?php echo e($projetmodule?->domaine); ?></td>
                                                            <td style="text-align: center;"><?php echo e($projetmodule?->effectif); ?>

                                                            </td>
                                                            <td>
                                                                <span class="d-flex align-items-baseline">
                                                                    <a href="<?php echo e(route('projetmodules.show', $projetmodule?->id)); ?>"
                                                                        class="btn btn-primary btn-sm"
                                                                        title="voir détails"><i class="bi bi-eye"></i></a>
                                                                    <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                                                        <div class="filter">
                                                                            <a class="icon" href="#"
                                                                                data-bs-toggle="dropdown"><i
                                                                                    class="bi bi-three-dots"></i></a>
                                                                            <ul
                                                                                class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                <button
                                                                                    class="dropdown-item btn btn-sm mx-1"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#EditprojetmoduleModal<?php echo e($projetmodule?->id); ?>">Modifier
                                                                                </button>
                                                                                
                                                                                <button
                                                                                    class="dropdown-item btn btn-sm mx-1"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#AddRegionModal<?php echo e($projetmodule?->id); ?>">Rejeter
                                                                                </button>
                                                                            </ul>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div>

                                <div class="tab-pane fade profile-overview" id="localites-overview">

                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="d-flex justify-content-between align-items-center mt-3">
                                            <h5 class="card-title">Localités</h5>
                                            <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                                <div class="pt-1">
                                                    <button type="button"
                                                        class="btn btn-primary btn-sm float-end btn-rounded"
                                                        data-bs-toggle="modal" data-bs-target="#AddprojetlocaliteModal">
                                                        <i class="bi bi-person-plus" title="Ajouter"></i>
                                                    </button>
                                                </div>
                                            <?php endif; ?>
                                    </div>
                                    
                                    <div class="row g-3">
                                        <table class="table datatables align-middle justify-content-center"
                                            id="table-projetlocalites">
                                            <thead>
                                                <tr>
                                                    <th width="5%" class="text-center" scope="col">N°</th>
                                                    <th>Localité</th>
                                                    <th class="text-center" scope="col">Effectif</th>
                                                    <th class="text-center" scope="col">Type localité</th>
                                                    <th width="5%" class="text-center" scope="col">#</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $i = 1; ?>
                                                <?php $__currentLoopData = $projetlocalites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projetlocalite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td style="text-align: center;"><?php echo e($i++); ?></td>
                                                        <td><?php echo e($projetlocalite?->localite); ?></td>
                                                        <td style="text-align: center;">
                                                            <?php echo e($projetlocalite?->effectif); ?>

                                                        </td>
                                                        <td style="text-align: center;">
                                                            <?php echo e($projetlocalite?->projet?->type_localite); ?>

                                                        </td>
                                                        <td style="text-align: center;">
                                                            <span class="d-flex mt-2 align-items-baseline"><a
                                                                    href="<?php echo e(route('projetlocalites.show', $projetlocalite?->id)); ?>"
                                                                    class="btn btn-warning btn-sm mx-1"
                                                                    title="Voir détails">
                                                                    <i class="bi bi-eye"></i></a>
                                                                <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                                                                    <div class="filter">
                                                                        <a class="icon" href="#"
                                                                            data-bs-toggle="dropdown"><i
                                                                                class="bi bi-three-dots"></i></a>
                                                                        <ul
                                                                            class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                            <li>
                                                                                <button type="button"
                                                                                    class="dropdown-item btn btn-sm mx-1"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#EditprojetlocaliteModal<?php echo e($projetlocalite?->id); ?>">
                                                                                    <i class="bi bi-pencil"
                                                                                        title="Modifier"></i>
                                                                                    Modifier
                                                                                </button>
                                                                            </li>
                                                                            <li>
                                                                                <form
                                                                                    action="<?php echo e(url('projetlocalites', $projetlocalite?->id)); ?>"
                                                                                    method="post">
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <?php echo method_field('DELETE'); ?>
                                                                                    <button type="submit"
                                                                                        class="dropdown-item show_confirm"><i
                                                                                            class="bi bi-trash"></i>Supprimer</button>
                                                                                </form>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                <?php endif; ?>
                                                        </span>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                
                            </div>
                        </div>
                    </div><!-- End Bordered Tabs -->
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $projet?->projetmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projetmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="EditprojetmoduleModal<?php echo e($projetmodule?->id); ?>" tabindex="-1"
            role="dialog" aria-labelledby="EditprojetmoduleModalLabel<?php echo e($projetmodule?->id); ?>"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    
                    <form method="post" action="<?php echo e(route('projetmodules.update', $projetmodule?->id)); ?>"
                        enctype="multipart/form-data" class="row g-3">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="modal-header" id="EditprojetmoduleModalLabel<?php echo e($projetmodule?->id); ?>">
                            <h5 class="modal-title"><i class="bi bi-pencil" title="Ajouter"></i> Modifier module
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo e($projetmodule?->id); ?>">
                            <div class="form-floating mb-3">
                                <input type="text" name="module"
                                    value="<?php echo e($projetmodule?->module ?? old('module')); ?>"
                                    class="form-control form-control-sm <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Module" autofocus>
                                <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="floatingInput">Module</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" name="domaine"
                                    value="<?php echo e($projetmodule?->domaine ?? old('domaine')); ?>"
                                    class="form-control form-control-sm <?php $__errorArgs = ['domaine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="domaine" placeholder="Domaine">
                                <?php $__errorArgs = ['domaine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="floatingInput">Domaine</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="number" name="effectif" min="0" step="1"
                                    value="<?php echo e($projetmodule?->effectif ?? old('effectif')); ?>"
                                    class="form-control form-control-sm <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="effectif" placeholder="effectif">
                                <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <div><?php echo e($message); ?></div>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <label for="floatingInput">effectif</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                data-bs-dismiss="modal">Fermer</button>
                            <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                                Modifier</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Add projetlocalite -->
<div class="modal fade" id="AddprojetlocaliteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            
            <form method="post" action="<?php echo e(url('projetlocalites')); ?>" enctype="multipart/form-data"
                class="row g-3">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus" title="Ajouter"></i> Ajouter une nouvelle
                        Localité</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input name="projet" value="<?php echo e($projet?->id); ?>" type="hidden">

                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                        <label for="localite" class="form-label">Localité<span
                                class="text-danger mx-1">*</span></label>
                        <input type="text" name="localite" value="<?php echo e(old('localite')); ?>"
                            class="form-control form-control-sm <?php $__errorArgs = ['localite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="localite" placeholder="localite">
                        <?php $__errorArgs = ['localite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <div><?php echo e($message); ?></div>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                        <label for="effectif" class="form-label">Effectif<span
                                class="text-danger mx-1">*</span></label>
                        <input type="number" min="0" name="effectif" value="<?php echo e(old('effectif')); ?>"
                            class="form-control form-control-sm <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="effectif" placeholder="Effectif">
                        <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <div><?php echo e($message); ?></div>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm"
                        data-bs-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="bi bi-printer"></i>
                        Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Add projetlocalite-->
<?php $__currentLoopData = $projetlocalites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projetlocalite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="EditprojetlocaliteModal<?php echo e($projetlocalite?->id); ?>" tabindex="-1"
        role="dialog" aria-labelledby="EditprojetlocaliteModalLabel<?php echo e($projetlocalite?->id); ?>"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                
                <form method="post" action="<?php echo e(route('projetlocalites.update', $projetlocalite?->id)); ?>"
                    enctype="multipart/form-data" class="row g-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div class="modal-header" id="EditprojetlocaliteModalLabel<?php echo e($projetlocalite?->id); ?>">
                        <h5 class="modal-title"><i class="bi bi-pencil" title="Ajouter"></i> Modifier localité
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?php echo e($projetlocalite?->projet->id); ?>">
                        
                        
                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                            <label for="localite" class="form-label">Localité<span
                                    class="text-danger mx-1">*</span></label>
                            <input type="text" name="localite"
                                value="<?php echo e($projetlocalite?->localite ?? old('localite')); ?>"
                                class="form-control form-control-sm <?php $__errorArgs = ['localite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="localite" placeholder="localite">
                            <?php $__errorArgs = ['localite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <div><?php echo e($message); ?></div>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                            <label for="effectif" class="form-label">Effectif<span
                                    class="text-danger mx-1">*</span></label>
                            <input type="number" min="0" name="effectif"
                                value="<?php echo e($projetlocalite?->effectif ?? old('effectif')); ?>"
                                class="form-control form-control-sm <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="effectif" placeholder="Effectif">
                            <?php $__errorArgs = ['effectif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <div><?php echo e($message); ?></div>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i>
                            Modifier</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#table-operateurModules', {
        layout: {
            topStart: {
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
            }
        },
        "order": [
            [0, 'asc']
        ],
        language: {
            "sProcessing": "Traitement en cours...",
            "sSearch": "Rechercher&nbsp;:",
            "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
            "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
            "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
            "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
            "sInfoPostFix": "",
            "sLoadingRecords": "Chargement en cours...",
            "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
            "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
            "oPaginate": {
                "sFirst": "Premier",
                "sPrevious": "Pr&eacute;c&eacute;dent",
                "sNext": "Suivant",
                "sLast": "Dernier"
            },
            "oAria": {
                "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
            },
            "select": {
                "rows": {
                    _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                    0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                    1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/projets/show.blade.php ENDPATH**/ ?>