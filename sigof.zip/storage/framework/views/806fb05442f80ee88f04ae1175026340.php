
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('space-work'); ?>
    <div class="pagetitle">
        <nav>
            <ol class="breadcrumb">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Suivi des formé</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <strong><?php echo e($error); ?></strong>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <div class="align-items-center">
        <span class="d-flex mt-2 align-items-baseline"><a href="<?php echo e(route('home')); ?>" class="btn btn-success btn-sm"
                title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
            <p> | Tableau de bord</p>
        </span>
        
    </div>
    <section class="section">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                <div class="pb-0">
                    <?php if(empty($formes)): ?>
                        <h4 class="card-title">Aucun bénéficiaire suivi pour le moment</h4>
                    <?php endif; ?>
                </div>
                <?php if(!empty($formes)): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($title); ?></h5>
                            <div class="table-responsive">
                                <table class="table datatables align-middle" id="table-formes">
                                    <thead>
                                        <tr>
                                            
                                            <th scope="col">Civilité</th>
                                            <th scope="col">Prénom</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Date naissance</th>
                                            <th scope="col">Lieu naissance</th>
                                            <th scope="col" width="5%">Téléphone</th>
                                            <th scope="col">Module</th>
                                            <th scope="col">Niveau étude</th>
                                            
                                            <th scope="col" class="text-center">Informations</th>
                                            <th class="text-center">#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1; ?>
                                        <?php $__currentLoopData = $formes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listecollective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($listecollective?->cin)): ?>
                                                <tr>
                                                    
                                                    <td><?php echo e($listecollective?->civilite); ?></td>
                                                    <td><?php echo e($listecollective?->prenom); ?></td>
                                                    <td><?php echo e($listecollective?->nom); ?></td>
                                                    <td><?php echo e($listecollective?->date_naissance->format('d/m/Y')); ?>

                                                    </td>
                                                    <td><?php echo e($listecollective?->lieu_naissance); ?></td>
                                                    <td><?php echo e($listecollective?->telephone); ?></td>
                                                    <td><?php echo e($listecollective?->collectivemodule?->module); ?></td>
                                                    <td><?php echo e($listecollective?->niveau_etude); ?></td>
                                                    
                                                    <td class="text-center"><?php echo e($listecollective?->informations_suivi); ?>

                                                    </td>
                                                    <td>
                                                        <button type="button"
                                                            class="btn btn-outline-primary btn-sm float-center"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#generate_suivi<?php echo e($listecollective?->id); ?>"><i
                                                                class="bi bi-pencil-square"></i></button>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php $__currentLoopData = $formes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listecollective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="generate_suivi<?php echo e($listecollective?->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="generate_suiviLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <?php echo e($listecollective?->civilite . ' ' . $listecollective?->prenom . ' ' . $listecollective?->nom); ?>

                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="post" action="<?php echo e(route('FormeColSuivi')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">
                                <div class="row g-3">
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="row">
                                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                <div class="form-group">
                                                    <input type="hidden" name="id"
                                                        value="<?php echo e($listecollective?->id); ?>">
                                                    
                                                    <textarea name="informations_suivi" id="informations_suivi" rows="5"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['informations_suivi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ecrire ici..."><?php echo e($listecollective?->informations_suivi ?? old('informations_suivi')); ?></textarea>
                                                    <?php $__errorArgs = ['informations_suivi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <div><?php echo e($message); ?></div>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Fermer</button>
                                <div class="text-center">
                                    <button type="submit"
                                        class="btn btn-primary btn-block submit_rapport btn-sm">Enregistrer</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-formes', {
            layout: {
                topStart: {
                    buttons: ['excel'],
                }
            },
            /* "order": [
                [0, 'ASC']
            ], */
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formes/suivi-collective.blade.php ENDPATH**/ ?>