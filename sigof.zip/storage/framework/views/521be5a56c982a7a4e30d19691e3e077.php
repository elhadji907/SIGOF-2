
<?php $__env->startSection('title', 'Générer rapport operateurs'); ?>
<?php $__env->startSection('space-work'); ?>
    <div class="pagetitle">
        <nav>
            <ol class="breadcrumb">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Générer rapport opérateurs</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <strong><?php echo e($error); ?></strong>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="d-flex justify-content-between align-items-center mt-3">
        <span class="d-flex mt-2 align-items-baseline"><a href="<?php echo e(route('home')); ?>" class="btn btn-success btn-sm"
                title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
            <p> | Tableau de bord</p>
        </span>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-operateur-view')): ?>
            <span class="d-flex align-items-baseline">
                <a href="#" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                    data-bs-target="#generate_rapport_module_region" title="Générer rapports">Générer rapport</a>
                <div class="filter">
                    <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <li>
                            <button type="button" class="dropdown-item btn btn-sm" data-bs-toggle="modal"
                                data-bs-target="#generate_rapport"></i>Par région</button>
                        </li>
                        <li>
                            <button type="button" class="dropdown-item btn btn-sm" data-bs-toggle="modal"
                                data-bs-target="#generate_rapport_module"></i>Par module</button>
                        </li>
                    </ul>
                </div>
            </span>
        <?php endif; ?>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                <?php if(!empty($operateurs)): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($title); ?></h5>
                            <div class="table-responsive">
                                <table class="table datatables align-middle" id="table-operateur">
                                    <thead>
                                        <tr>
                                            <th width="15%" class="text-center">N° agrément</th>
                                            <th width="45%">Opérateurs</th>
                                            <th width="10%" class="text-center">Sigle</th>
                                            <th width="5%" class="text-center">Modules</th>
                                            <th width="5%" class="text-center">Formations</th>
                                            <th width="15%" class="text-center">Statut</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $operateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($operateur?->numero_agrement)): ?>
                                                <tr>

                                                    <td><?php echo e($operateur?->numero_agrement); ?></td>
                                                    <td><?php echo e($operateur?->user?->operateur); ?></td>
                                                    <td style="text-align: center;"><?php echo e($operateur?->user?->username); ?></td>
                                                    <td style="text-align: center;">
                                                        <?php $__currentLoopData = $operateur->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($loop->last): ?>
                                                                <a href="#"><span
                                                                        class="badge bg-info"><?php echo e($loop->count); ?></span></a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td class="text-center">
                                                        <?php $__currentLoopData = $operateur->formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($loop->last): ?>
                                                                <a href="#"><span
                                                                        class="badge bg-info"><?php echo e($loop->count); ?></span></a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td style="text-align: center;"><span
                                                            class="<?php echo e($operateur->statut_agrement); ?>">
                                                            <?php echo e($operateur?->statut_agrement); ?></span></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- / Rapport des ventes -->
                <?php endif; ?>
        </div>
    </div>
    <div class="modal fade" id="generate_rapport" tabindex="-1" role="dialog" aria-labelledby="generate_rapportLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Générer un rapport operateurs par région</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="<?php echo e(route('operateurs.rapport')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                <div class="row">
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="region" class="form-label">Région<span
                                                    class="text-danger mx-1">*</span></label>
                                            <input type="hidden" value="1" name="valeur_region">
                                            <select name="region"
                                                class="form-select  <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Select" id="select-field-region-rapport"
                                                data-placeholder="Choisir la région">
                                                <option value="">Toutes</option>
                                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($region->id); ?>">
                                                        <?php echo e($region->nom); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="statut" class="form-label">Statut<span
                                                    class="text-danger mx-1">*</span></label>
                                            <select name="statut"
                                                class="form-select form-select-sm <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Select" id="select-field-statut-rapport"
                                                data-placeholder="Choisir statut">
                                                <option value="<?php echo e(old('statut')); ?>">
                                                    <?php echo e(old('statut')); ?>

                                                </option>
                                                <option value="agréer">
                                                    agréer
                                                </option>
                                                <option value="nouveau">
                                                    nouveau
                                                </option>
                                                <option value="rejeter">
                                                    rejeter
                                                </option>
                                                <option value="sous réserve">
                                                    sous réserve
                                                </option>
                                                <option value="retenu">
                                                    retenu
                                                </option>
                                                <option value="attente">
                                                    attente
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Fermer</button>
                                <div class="text-center">
                                    <button type="submit"
                                        class="btn btn-primary btn-block submit_rapport btn-sm">Envoyer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="generate_rapport_module" tabindex="-1" role="dialog"
        aria-labelledby="generate_rappor_moduleLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Générer un rapport operateurs par module</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="<?php echo e(route('operateurs.rapport')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                <div class="row">
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="module" class="form-label">Module<span
                                                    class="text-danger mx-1">*</span></label>
                                            <input type="hidden" value="1" name="valeur_module">
                                            
                                            <input type="text" name="module" placeholder="module..."
                                                class="form-control form-control-sm module">
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="region" class="form-label">Statut<span
                                                    class="text-danger mx-1">*</span></label>
                                            <select name="statut"
                                                class="form-select form-select-sm <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Select" id="select-field-statut-rappor"
                                                data-placeholder="Choisir statut">
                                                <option value="<?php echo e(old('statut')); ?>">
                                                    <?php echo e(old('statut')); ?>

                                                </option>
                                                <option value="agréer">
                                                    agréer
                                                </option>
                                                <option value="nouveau">
                                                    nouveau
                                                </option>
                                                <option value="rejeter">
                                                    rejeter
                                                </option>
                                                <option value="sous réserve">
                                                    sous réserve
                                                </option>
                                                <option value="retenu">
                                                    retenu
                                                </option>
                                                <option value="attente">
                                                    attente
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Fermer</button>
                                <div class="text-center">
                                    <button type="submit"
                                        class="btn btn-primary btn-block submit_rapport btn-sm">Envoyer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="generate_rapport_module_region" tabindex="-1" role="dialog"
        aria-labelledby="generate_rappor_module_regionLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Générer rapport opérateurs par module et région</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="<?php echo e(route('operateurs.rapport')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                <div class="row">
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="module" class="form-label">Module<span
                                                    class="text-danger mx-1">*</span></label>
                                            <input type="text" name="module" id="module_operateur"
                                                class="form-control form-control-sm"
                                                placeholder="Module ou spécialité" />
                                            <div id="moduleList"></div>
                                            <?php echo e(csrf_field()); ?>

                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="region" class="form-label">Région<span
                                                    class="text-danger mx-1">*</span></label>
                                            <select name="region"
                                                class="form-select  <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Select" id="select-field-region-module-rapport"
                                                data-placeholder="Choisir la région">
                                                <option value="">Toutes</option>
                                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($region->id); ?>">
                                                        <?php echo e($region->nom); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                        <div class="form-group">
                                            <label for="region" class="form-label">Statut<span
                                                    class="text-danger mx-1">*</span></label>
                                            <select name="statut"
                                                class="form-select form-select-sm <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                aria-label="Select" id="select-field-statut-rappo"
                                                data-placeholder="Choisir statut">
                                                <option value="<?php echo e(old('statut')); ?>">
                                                    <?php echo e(old('statut')); ?>

                                                </option>

                                                <?php $__currentLoopData = $module_statuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($module?->statut); ?>">
                                                        <?php echo e($module?->statut); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                            </select>
                                            <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Fermer</button>
                                <div class="text-center">
                                    <button type="submit"
                                        class="btn btn-primary btn-block submit_rapport btn-sm">Envoyer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#table-operateur', {
        layout: {
            topStart: {
                buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
            }
        },
        "order": [
            [0, 'desc']
        ],
        language: {
            "sProcessing": "Traitement en cours...",
            "sSearch": "Rechercher&nbsp;:",
            "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
            "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
            "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
            "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
            "sInfoPostFix": "",
            "sLoadingRecords": "Chargement en cours...",
            "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
            "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
            "oPaginate": {
                "sFirst": "Premier",
                "sPrevious": "Pr&eacute;c&eacute;dent",
                "sNext": "Suivant",
                "sLast": "Dernier"
            },
            "oAria": {
                "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
            },
            "select": {
                "rows": {
                    _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                    0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                    1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                }
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/operateurs/rapports.blade.php ENDPATH**/ ?>