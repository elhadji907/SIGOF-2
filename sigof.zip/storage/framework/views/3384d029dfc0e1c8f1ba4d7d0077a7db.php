
<?php $__env->startSection('title', 'Enregistrement permission'); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 pt-5">
                                <span class="d-flex mt-2 align-items-baseline"><a href="<?php echo e(route('permissions.index')); ?>"
                                        class="btn btn-success btn-sm" title="retour"><i
                                            class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                    <p> | Liste des permissions</p>
                                </span>
                            </div>
                        </div>
                        <h5 class="card-title">Création permission</h5>
                        <!-- Permission -->
                        <form method="post" action="<?php echo e(url('permissions')); ?>" enctype="multipart/form-data"
                            class="row g-3">
                            <?php echo csrf_field(); ?>
                            


                            <table class="table table-bordered" id="dynamicAddRemove">
                                <tr>
                                    <th>Permissions<span class="text-danger mx-1">*</span></th>
                                    <th width="15%">Action</th>
                                </tr>
                                <tr>
                                    <td><input type="text" name="permissions[0][name]" placeholder="Entrer une permission"
                                            class="form-control form-control-sm" autofocus/></td>
                                    <td><button type="button" name="add" id="add-btn" class="btn btn-success"
                                            title="Ajouter une ligne">Ajouter</button>
                                    </td>
                                </tr>
                            </table>
                            <div class="col-xs-12 col-sm-12 col-md-12 text-left mt-2">
                                <button type="submit" class="btn btn-outline-success"><i
                                        class="far fa-save"></i>&nbsp;Sauvegarder</button>
                            </div>

                        </form><!-- End Permission -->
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var i = 0;
        $("#add-btn").click(function() {
            ++i;
            $("#dynamicAddRemove").append('<tr><td><input type="text" name="permissions[' + i +
                '][name]" placeholder="Entrer une autre catégorie" class="form-control" /></td><td><button type="button" class="btn btn-danger remove-tr">Supprimer</button></td></tr>'
            );
        });
        $(document).on('click', '.remove-tr', function() {
            $(this).parents('tr').remove();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/role-permission/permission/create.blade.php ENDPATH**/ ?>