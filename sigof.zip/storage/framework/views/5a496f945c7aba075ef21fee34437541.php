
<?php $__env->startSection('title', 'ONFP - Formations'); ?>
<?php $__env->startSection('space-work'); ?>

    <div class="pagetitle">
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Données</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">CONVENTIONS & DETF</h4>
                        <table class="table datatables" id="table-formations">
                            <thead>
                                <tr>
                                    <th width='10%' class="text-center">N° Conv.</th>
                                    <th width='10%' class="text-center">Date Conv.</th>
                                    
                                    <th>Bénéficiaires</th>
                                    <th width='15%'>Région</th>
                                    <th width='20%'>Modules</th>
                                    <th width='10%'>Scan Conv.</th>
                                    <th width='10%'>Scan DETF</th>
                                    <th width='5%' class="text-center">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $conventions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($formation?->numero_convention); ?></td>
                                        <td style="text-align: center"><?php echo e($formation?->date_convention?->format('d/m/Y')); ?>

                                        </td>
                                       
                                        <td><?php echo e($formation?->name); ?></td>
                                        <td><?php echo e($formation->departement?->region?->nom); ?></td>
                                        <td>
                                            <?php if(isset($formation?->module?->name)): ?>
                                                <?php echo e($formation?->module?->name); ?>

                                            <?php endif; ?>
                                            <?php if(isset($formation?->collectivemodule?->module)): ?>
                                                <?php echo e($formation?->collectivemodule?->module); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center">
                                            <?php if(!empty($formation?->file_convention)): ?>
                                                <a class="btn btn-outline-secondary btn-sm" title="Convention"
                                                    target="_blank" href="<?php echo e(asset($formation->getFileConvention())); ?>">
                                                    <i class="bi bi-file-earmark-pdf"></i>
                                                </a>
                                            <?php else: ?>
                                                <div class="badge bg-warning">Aucun</div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center">
                                            <?php if(!empty($formation?->detf_file)): ?>
                                                <a class="btn btn-outline-secondary btn-sm" title="DETF"
                                                    target="_blank" href="<?php echo e(asset($formation->getFileDetf())); ?>">
                                                    <i class="bi bi-file-earmark-pdf"></i>
                                                </a>
                                            <?php else: ?>
                                                <div class="badge bg-warning">Aucun</div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><a><span
                                                    class="<?php echo e($formation?->statut); ?>"><?php echo e($formation?->statut); ?></span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-formations', {
            layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            },
            "order": [
                [0, 'desc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formations/convention.blade.php ENDPATH**/ ?>