
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('space-work'); ?>
    <div class="pagetitle">
        <nav>
            <ol class="breadcrumb">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                <?php endif; ?>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Générer des rapports</li>
            </ol>
        </nav>
    </div>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                <strong><?php echo e($error); ?></strong>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    <section class="section">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                <?php if(isset($formations)): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><a href="<?php echo e(route('formations.index')); ?>" class="btn btn-success btn-sm"
                                    title="retour"><i class="bi bi-arrow-counterclockwise"></i></a> | <?php echo e($title); ?></h5>
                            <div class="table-responsive">
                                <table class="table datatables align-middle" id="table-formations">
                                    <thead>
                                        <tr>
                                            <th rowspan="2" style="vertical-align: middle;">REGIONS</th>
                                            <th rowspan="2" style="vertical-align: middle;">LIEUX</th>
                                            <th rowspan="2" style="vertical-align: middle;">MODULES</th>
                                            <th rowspan="2" style="vertical-align: middle;">TYPE FORMATION</th>
                                            <th rowspan="2" style="vertical-align: middle;">BENEFICIAIRES</th>
                                            <th rowspan="2" style="vertical-align: middle;">N° LM ET DATE</th>
                                            <th colspan="3" class="text-center">PREVUS</th>
                                            <th colspan="6" class="text-center">FORMES</th>
                                            <th rowspan="2" style="vertical-align: middle;">REF CONV.</th>
                                            <th rowspan="2" style="vertical-align: middle;">FRAIS OPERA.</th>
                                            <th rowspan="2" style="vertical-align: middle;">FRAIS ADDIT.</th>
                                            <th rowspan="2" style="vertical-align: middle;">AUTRES FRAIS</th>
                                            <th rowspan="2" style="vertical-align: middle;">BUDGET TOTAL</th>
                                            <th rowspan="2" style="vertical-align: middle;">NIVEAU QUALIF.</th>
                                            <th rowspan="2" style="vertical-align: middle;">OPERATEUR</th>
                                            <th rowspan="2" style="vertical-align: middle;">SUIVI DOSSIER</th>
                                            <th rowspan="2" style="vertical-align: middle;">STATUT</th>
                                        </tr>
                                        <tr>
                                            <th>HOMMES</th>
                                            <th>FEMMES</th>
                                            <th>TOTAL</th>
                                            <th>HOMMES</th>
                                            <th>FEMMES</th>
                                            <th>JEUNES</th>
                                            <th>TOTAL</th>
                                            <th>DEBUT</th>
                                            <th>FIN</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($formation->code)): ?>
                                                <tr>
                                                    <td><?php echo e($formation?->departement?->region?->nom); ?></td>
                                                    <td><?php echo e($formation?->lieu); ?></td>
                                                    <td>
                                                        <?php if(!empty($formation?->module?->name)): ?>
                                                            <?php echo e($formation?->module?->name); ?>

                                                        <?php elseif(!empty($formation?->collectivemodule?->module)): ?>
                                                            <?php echo e($formation?->collectivemodule?->module); ?>

                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($formation->types_formation?->name); ?></td>
                                                    <td><?php echo e($formation?->name); ?></td>
                                                    <td>
                                                        <?php if(!empty($formation?->lettre_mission)): ?>
                                                            <?php echo e($formation?->lettre_mission . ' du ' . $formation?->date_lettre?->format('d/m/Y')); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($formation?->prevue_h); ?></td>
                                                    <td><?php echo e($formation?->prevue_f); ?></td>
                                                    <td><?php echo e($formation?->effectif_prevu); ?></td>
                                                    <td><?php echo e($formation?->forme_h); ?></td>
                                                    <td><?php echo e($formation?->forme_f); ?></td>
                                                    <td></td>
                                                    <td><?php echo e($formation?->total); ?></td>
                                                    <td><?php echo e(date_format(date_create($formation?->date_debut), 'd/m/Y')); ?></td>
                                                    <td><?php echo e(date_format(date_create($formation?->date_fin), 'd/m/Y')); ?></td>
                                                    <td>
                                                        <?php if(!empty($formation?->numero_convention)): ?>
                                                            <?php echo e($formation?->numero_convention . ' du ' . $formation?->date_convention?->format('d/m/Y')); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($formation?->frais_operateurs); ?></td>
                                                    <td><?php echo e($formation?->frais_add); ?></td>
                                                    <td><?php echo e($formation?->autes_frais); ?></td>
                                                    <td><?php echo e($formation?->frais_operateurs + $formation?->frais_add + $formation?->autes_frais); ?>

                                                    </td>
                                                    <td>
                                                        <?php if(!empty($formation?->referentiel?->titre)): ?>
                                                            <?php echo e($formation?->referentiel?->titre); ?>

                                                            
                                                        <?php else: ?>
                                                            <?php echo e($formation?->titre); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($formation?->operateur?->user?->username); ?></td>
                                                    <td>
                                                        <?php if(!empty($formation?->ingenieur?->initiale)): ?>
                                                            <?php echo e($formation?->ingenieur?->name . ' (' . $formation?->ingenieur?->initiale . ')'); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($formation?->statut); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="modal fade" id="generate_rapport" tabindex="-1" role="dialog" aria-labelledby="generate_rapportLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Générer rapport demandes formations</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="post" action="<?php echo e(route('formations.rapport')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="row g-3">
                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <div class="row">

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <div class="form-group">
                                                <label>De</label>
                                                <input type="date" name="from_date"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> from_date">
                                            </div>
                                            <?php $__errorArgs = ['from_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <div class="form-group">
                                                <label>À</label>
                                                <input type="date" name="to_date"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> to_date">
                                            </div>
                                            <?php $__errorArgs = ['to_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Fermer</button>
                                    <div class="text-center">
                                        <button type="submit"
                                            class="btn btn-primary btn-block submit_rapport btn-sm">Envoyer</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-formations', {
            layout: {
                topStart: {
                    buttons: ['csv', 'excel', 'print'],
                }
            },
            "order": [
                [0, 'desc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formations/reports.blade.php ENDPATH**/ ?>