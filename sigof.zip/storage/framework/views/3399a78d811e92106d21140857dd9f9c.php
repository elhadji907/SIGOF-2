
<?php $__env->startSection('title', 'SIGOF - Mon profil'); ?>
<?php $__env->startSection('space-work'); ?>
    <div class="pagetitle">
        <h1>Profil</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item">Utilisateurs</li>
                <li class="breadcrumb-item active">Profil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section profile">
        <div class="row justify-content-center">
            
            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                    <div class="card">
                        <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                            
                            <img class="rounded-circle w-25" alt="Profil" src="<?php echo e(asset(Auth::user()->getImage())); ?>"
                                width="50" height="auto">

                            <h2>
                                <?php if(isset(Auth::user()->name)): ?>
                                    <?php echo e(Auth::user()->civilite . ' ' . Auth::user()->firstname . ' ' . Auth::user()->name); ?>

                                <?php else: ?>
                                    <?php echo e(Auth::user()->username); ?>

                                <?php endif; ?>
                            </h2>
                            <span><a href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a></span>
                            
                            <div class="social-links mt-2">
                                <?php if(isset(Auth::user()->twitter)): ?>
                                    <a href="<?php echo e(Auth::user()->twitter); ?>" class="twitter" target="_blank"><i
                                            class="bi bi-twitter"></i></a>
                                <?php endif; ?>
                                <?php if(isset(Auth::user()->facebook)): ?>
                                    <a href="<?php echo e(Auth::user()->facebook); ?>" class="facebook" target="_blank"><i
                                            class="bi bi-facebook"></i></a>
                                <?php endif; ?>
                                <?php if(isset(Auth::user()->instagram)): ?>
                                    <a href="<?php echo e(Auth::user()->instagram); ?>" class="instagram" target="_blank"><i
                                            class="bi bi-instagram"></i></a>
                                <?php endif; ?>
                                <?php if(isset(Auth::user()->linkedin)): ?>
                                    <a href="<?php echo e(Auth::user()->linkedin); ?>" class="linkedin" target="_blank"><i
                                            class="bi bi-linkedin"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                    <div class="card">

                        <div class="card-body pb-0">
                            <h5 class="card-title">Demandes <span>| Personnelles</span></h5>

                            <table class="table table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col">Demande</th>
                                        <th scope="col" class="text-center">Nombre</th>
                                        <th scope="col" class="text-center">#</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-primary">Individuelle</td>
                                        <td class="text-center">
                                            <?php echo e(count($individuelles)); ?>

                                            
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('demandesIndividuelle')); ?>" class="btn btn-success btn-sm"
                                                title="voir"><i class="bi bi-eye"></i></a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="text-primary">Collective</td>
                                        <td class="text-center">
                                            <?php echo e(count($collectives)); ?>

                                            
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('demandesCollective')); ?>" class="btn btn-success btn-sm"
                                                title="voir"><i class="bi bi-eye"></i></a>
                                        </td>
                                    </tr>
                                    
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
            

            
            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                <div class="flex items-center gap-4">
                    <div class="card">
                        <?php if($message = Session::get('status')): ?>
                            <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                                role="alert">
                                <strong><?php echo e($message); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('message')): ?>
                            <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                                role="alert">
                                <strong><?php echo e($message); ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->updatePassword->get('current_password')): ?>
                            <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                                role="alert">
                                <strong><?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->updatePassword->get('current_password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->updatePassword->get('current_password'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?></strong>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                                    role="alert"><strong><?php echo e($error); ?></strong></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <div class="card-body pt-3">
                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered">

                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab"
                                        data-bs-target="#profile-overview">Aperçu</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Modifier
                                        profil
                                    </button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab"
                                        data-bs-target="#profile-change-password">Changer le mot de passe</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#files">Fichiers</button>
                                </li>

                            </ul>
                            <div class="tab-content pt-2">
                                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                    <h5 class="card-title">À propos</h5>
                                    <p class="small fst-italic">
                                        créé, <?php echo e(Auth::user()->created_at->diffForHumans()); ?>

                                        
                                    </p>

                                    <div class="row">
                                        <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">
                                            Informations personnelles
                                        </div>
                                        <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                            <?php if(isset(Auth::user()->cin)): ?>
                                                <span class="badge bg-success text-white">Complètes</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-white">Incomplètes</span>, cliquez sur
                                                l'onglet modifier profil pour complèter
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">
                                            Fichiers joints
                                        </div>
                                        <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                            <?php if(!empty($user_cin)): ?>
                                                <span class="badge bg-primary text-white">Valide</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-white">Incomplètes</span>, cliquez sur
                                                l'onglet fichier pour télécharger
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    
                                    <?php if(isset(Auth::user()->cin)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">CIN</div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <?php echo e(Auth::user()->cin); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->username)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Username
                                            </div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <?php echo e(Auth::user()->username); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->firstname)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Prénom
                                            </div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <?php echo e(Auth::user()->firstname); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->name)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Nom</div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <?php echo e(Auth::user()->name); ?></div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->email)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Email
                                            </div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8"><a
                                                    href="mailto:<?php echo e(Auth::user()->email); ?>"><?php echo e(Auth::user()->email); ?></a>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->telephone)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Téléphone
                                            </div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8"><a
                                                    href="tel:+221<?php echo e(Auth::user()->telephone); ?>"><?php echo e(Auth::user()->telephone); ?></a>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(isset(Auth::user()->adresse)): ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 label">Adresse
                                            </div>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <?php echo e(Auth::user()->adresse); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="tab-content pt-2">
                                
                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
                                    <form method="post" action="<?php echo e(route('profile.update')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>
                                        <h5 class="card-title">Modification du profil</h5>
                                        <!-- Profile Edit Form -->

                                        <div class="row mb-3">
                                            <label for="profileImage"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Image
                                                de
                                                profil</label>
                                            
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <img class="rounded-circle w-25" alt="Profil"
                                                    src="<?php echo e(asset(Auth::user()->getImage())); ?>" width="50"
                                                    height="auto">

                                                
                                                <div class="pt-2">
                                                    <input type="file" name="image" id="image"
                                                        class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> btn btn-primary btn-sm">
                                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="cin"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">CIN<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <div class="pt-2">
                                                    <input name="cin" type="text"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="cin" value="<?php echo e($user->cin ?? old('cin')); ?>"
                                                        autocomplete="cin" placeholder="Votre cin">
                                                </div>
                                                <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="username"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Username<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <div class="pt-2">
                                                    <input name="username" type="text"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="username" value="<?php echo e($user->username ?? old('username')); ?>"
                                                        autocomplete="username" placeholder="Votre username">
                                                </div>
                                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        
                                        <div class="row mb-3">
                                            <label for="Civilité"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Civilité<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <div class="pt-2">
                                                    <select name="civilite"
                                                        class="form-select form-select-sm <?php $__errorArgs = ['civilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        aria-label="Select" id="select-field-civilite"
                                                        data-placeholder="Choisir civilité">
                                                        <option value="<?php echo e($user->civilite ?? old('civilite')); ?>">
                                                            <?php echo e($user->civilite ?? old('civilite')); ?>

                                                        </option>
                                                        <option value="M.">
                                                            Monsieur
                                                        </option>
                                                        <option value="Mme">
                                                            Madame
                                                        </option>
                                                    </select>
                                                    <?php $__errorArgs = ['civilite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="firstname"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Prénom<span
                                                    class="text-danger mx-1">*</span>
                                            </label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <div class="pt-2">
                                                    <input name="firstname" type="text"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="firstname" value="<?php echo e($user->firstname ?? old('firstname')); ?>"
                                                        autocomplete="firstname" placeholder="Votre prénom">
                                                </div>
                                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="name"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Nom<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="name" type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="name" value="<?php echo e($user->name ?? old('name')); ?>"
                                                    autocomplete="name" placeholder="Votre Nom">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="date_naissance"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Date
                                                naissance<span class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input type="date" name="date_naissance"
                                                    value="<?php echo e($user->date_naissance?->format('Y-m-d') ?? old('date_naissance')); ?>"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="date_naissance" placeholder="Date naissance">
                                                <?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="lieu naissance"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Lieu
                                                naissance<span class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="lieu_naissance" type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="lieu_naissance"
                                                    value="<?php echo e($user->lieu_naissance ?? old('lieu_naissance')); ?>"
                                                    autocomplete="lieu_naissance" placeholder="Votre Lieu naissance">
                                                <?php $__errorArgs = ['lieu_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="Email"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Email<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="email" type="email"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="Email" value="<?php echo e($user->email ?? old('email')); ?>"
                                                    autocomplete="email" placeholder="Votre adresse e-mail">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="telephone"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Téléphone<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="telephone" type="telephone"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="telephone" value="<?php echo e($user->telephone ?? old('telephone')); ?>"
                                                    autocomplete="telephone" placeholder="Votre n° de téléphone">
                                                <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="adresse"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Adresse<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="adresse" type="adresse"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="adresse" value="<?php echo e($user->adresse ?? old('adresse')); ?>"
                                                    autocomplete="adresse" placeholder="Votre adresse de résidence">
                                                <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="adresse"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Situation
                                                familiale<span class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <select name="situation_familiale"
                                                    class="form-select form-select-sm <?php $__errorArgs = ['situation_familiale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-familiale"
                                                    data-placeholder="Choisir situation familiale">
                                                    <option
                                                        value="<?php echo e($user->situation_familiale ?? old('situation_familiale')); ?>">
                                                        <?php echo e($user->situation_familiale ?? old('situation_familiale')); ?>

                                                    </option>
                                                    <option value="Marié(e)">
                                                        Marié(e)
                                                    </option>
                                                    <option value="Célibataire">
                                                        Célibataire
                                                    </option>
                                                    <option value="Veuf(ve)">
                                                        Veuf(ve)
                                                    </option>
                                                    <option value="Divorsé(e)">
                                                        Divorsé(e)
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['situation_familiale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="adresse"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Situation
                                                professionnelle<span class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <select name="situation_professionnelle"
                                                    class="form-select  <?php $__errorArgs = ['situation_professionnelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-professionnelle"
                                                    data-placeholder="Choisir situation professionnelle">
                                                    <option
                                                        value="<?php echo e($user->situation_professionnelle ?? old('situation_professionnelle')); ?>">
                                                        <?php echo e($user->situation_professionnelle ?? old('situation_professionnelle')); ?>

                                                    </option>
                                                    <option value="Employé(e)">
                                                        Employé(e)
                                                    </option>
                                                    <option value="Informel">
                                                        Informel
                                                    </option>
                                                    <option value="Elève ou étudiant">
                                                        Elève ou étudiant
                                                    </option>
                                                    <option value="chercheur emploi">
                                                        chercheur emploi
                                                    </option>
                                                    <option value="Stage ou période essai">
                                                        Stage ou période essai
                                                    </option>
                                                    <option value="Entrepreneur ou freelance">
                                                        Entrepreneur ou freelance
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['situation_professionnelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="facebook"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Facebook
                                                profil</label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="facebook" type="facebook"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="facebook" value="<?php echo e($user->facebook ?? old('facebook')); ?>"
                                                    autocomplete="facebook" placeholder="lien de votre compte facebook">
                                                <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="twitter"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">X
                                                profil (ex
                                                twitter)</label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="twitter" type="twitter"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="twitter" value="<?php echo e($user->twitter ?? old('twitter')); ?>"
                                                    autocomplete="twitter"
                                                    placeholder="lien de votre compte x (ex twitter)">
                                                <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="instagram"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Instagram
                                                profil</label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="instagram" type="instagram"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="instagram" value="<?php echo e($user->instagram ?? old('instagram')); ?>"
                                                    autocomplete="instagram" placeholder="lien de votre compte instagram">
                                                <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <label for="linkedin"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Linkedin
                                                profil</label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <input name="linkedin" type="linkedin"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="linkedin" value="<?php echo e($user->linkedin ?? old('linkedin')); ?>"
                                                    autocomplete="linkedin" placeholder="lien de votre ompte linkedin">
                                                <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-info">Sauvegarder les
                                                modifications</button>
                                        </div>
                                        <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail()): ?>
                                            <div>
                                                <p class="text-sm mt-2 text-gray-800 dark:text-gray-200">
                                                    <?php echo e(__('Votre adresse e-mail n\'est pas vérifiée.')); ?>


                                                    
                                                <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                                    <?php echo csrf_field(); ?>

                                                    <div>
                                                        <button type="submit"
                                                            class="btn btn-outline-primary"><?php echo e(__('Cliquez ici pour renvoyer l\'e-mail de vérification.')); ?></button>
                                                        
                                                    </div>
                                                </form>
                                                </p>

                                                <?php if(session('status') === 'verification-link-sent'): ?>
                                                    <p class="mt-2 font-medium text-sm text-green-600 dark:text-green-400">
                                                        <?php echo e(__('Un nouveau lien de vérification a été envoyé à votre adresse e-mail.')); ?>

                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                        <!-- End Profile Edit Form -->
                                    </form>
                                </div>
                            </div>
                            <div class="tab-content pt-2">
                                
                                <div class="tab-pane fade pt-3" id="profile-change-password">
                                    <!-- Change Password Form -->
                                    <form method="post" action="<?php echo e(route('password.update')); ?>">
                                        
                                        <div class="flex items-center gap-4">
                                            <!-- Bordered Tabs -->
                                            <div class="tab-pane fade show profile-overview" id="profile-overview">
                                                <h5 class="card-title">Modification du mot de passe</h5>
                                                <!-- Change Password Form -->
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <div class="row mb-3">
                                                    <label for="update_password_current_password"
                                                        class="col-md-4 col-lg-3 col-form-label label">Mot de
                                                        passe actuel<span class="text-danger mx-1">*</span></label>
                                                    <div class="col-md-6 col-lg-6">
                                                        <input name="current_password" type="password"
                                                            class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            id="update_password_current_password"
                                                            placeholder="Votre mot de passe actuel"
                                                            autocomplete="current-password">
                                                        
                                                    </div>
                                                </div>
                                                <!-- Mot de passe -->
                                                <div class="row mb-3">
                                                    <label for="password"
                                                        class="col-md-4 col-lg-3 col-form-label label">Mot
                                                        de
                                                        passe<span class="text-danger mx-1">*</span></label>
                                                    <div class="col-md-6 col-lg-6">
                                                        <input type="password" name="password"
                                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            id="password" placeholder="Votre mot de passe"
                                                            value="<?php echo e(old('password')); ?>" autocomplete="new-password">
                                                        <div class="invalid-feedback">
                                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Mot de passe de confirmation -->
                                                <div class="row mb-3">
                                                    <label for="password_confirmation"
                                                        class="col-md-4 col-lg-3 col-form-label label">Confirmez<span
                                                            class="text-danger mx-1">*</span></label>
                                                    <div class="col-md-6 col-lg-6">
                                                        <input type="password" name="password_confirmation"
                                                            class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            id="password_confirmation"
                                                            placeholder="Confimez votre mot de passe"
                                                            value="<?php echo e(old('password_confirmation')); ?>"
                                                            autocomplete="new-password_confirmation">
                                                        <div class="invalid-feedback">
                                                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <button type="submit" class="btn btn-primary">Changer
                                                        le mot de
                                                        passe</button>
                                                </div>
                                                <!-- End Change Password Form -->
                                            </div>
                                        </div>
                                        
                                    </form><!-- End Change Password Form -->
                                </div>
                            </div><!-- End Bordered Tabs -->


                            <div class="tab-content pt-2">
                                
                                <div class="tab-pane fade files" id="files">
                                    <div class="row mb-3">
                                        <h5 class="card-title col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                            <?php echo e(__('Fichiers téléchargés')); ?></h5>
                                        <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                            <table class="table table-bordered table-hover datatables" id="table-iles">
                                                <thead>
                                                    <tr>
                                                        <th width="5%" class="text-center">N°</th>
                                                        <th>Légende</th>
                                                        <th width="10%" class="text-center">File</th>
                                                        <th width="5%" class="text-center"><i class="bi bi-gear"></i>
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="text-center"><?php echo e($i++); ?></td>
                                                            <td><?php echo e($file?->legende); ?></td>
                                                            <td class="text-center">
                                                                <a class="btn btn-default btn-sm"
                                                                    title="télécharger le fichier joint" target="_blank"
                                                                    href="<?php echo e(asset($file->getFichier())); ?>">
                                                                    <i class="bi bi-download"></i>
                                                                </a>
                                                            </td>
                                                            <td class="text-center">
                                                                <form action="<?php echo e(route('fileDestroy')); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('put'); ?>
                                                                    <input type="hidden" name="idFile"
                                                                        value="<?php echo e($file->id); ?>">
                                                                    <button type="submit"
                                                                        style="background:none;border:0px;"
                                                                        class="show_confirm" title="retirer"><i
                                                                            class="bi bi-trash"></i></button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <form method="post" action="<?php echo e(route('files.update', $user->id)); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('patch'); ?>

                                        <h5 class="card-title"><?php echo e(__("Ajouter d'autres fichiers")); ?></h5>
                                        <span style="color:red;">NB:</span> <span>Seule la Carte nationale d'identité
                                            (Recto/Verso)</span> <span style="color:red;"> est obligatoire</span>
                                        <!-- Profile Edit Form -->

                                        <div class="row mb-3 mt-3">
                                            <label for="legende"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Légende<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                
                                                <select name="legende"
                                                    class="form-select  <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    aria-label="Select" id="select-field-file"
                                                    data-placeholder="Choisir">
                                                    <option value="<?php echo e(old('legende')); ?>">
                                                        <?php echo e(old('legende')); ?>

                                                    </option>
                                                    <?php $__currentLoopData = $user_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($file?->id); ?>">
                                                            <?php echo e($file?->legende); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="file"
                                                class="col-12 col-md-4 col-lg-4 col-sm-12 col-xs-12 col-xxl-4 col-form-label">Fichier<span
                                                    class="text-danger mx-1">*</span></label>
                                            <div class="col-12 col-md-8 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                                <div class="pt-2">
                                                    <input type="file" name="file" id="file"
                                                        class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> btn btn-primary btn-sm">
                                                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="text-center mt-2">
                                            <button type="submit" class="btn btn-info btn-sm">Ajouter</button>
                                        </div>

                                    </form>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if(auth()->user()->hasRole('Demandeur')): ?>
        <section class="section dashboard">
            <div class="row">
                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="row">
                        <!-- Sales Card -->
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('demandesIndividuelle')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Demandes <span>| Individuelles</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-person-plus-fill"></i>
                                                <?php echo e(count($individuelles)); ?>

                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('demandesCollective')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Demandes <span>| collectives</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-person-plus-fill"></i>
                                                <?php echo e(count($collectives)); ?>

                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    
                                                </h6>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <!-- Sales Card -->
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('showprojetProgramme')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Projets <span>| Programmes</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-person-plus-fill"></i>
                                                <?php echo e(count($count_projets)); ?>

                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="card info-card sales-card">
                                    <div class="filter">
                                        <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                                class="bi bi-three-dots"></i></a>
                                    </div>
                                    <a href="<?php echo e(route('projetsIndividuelle', ['id' => $projet?->id])); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($projet?->type_projet); ?> <span>|
                                                    <?php echo e($projet?->sigle); ?></span></h5>
                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-person-plus-fill"></i>
                                                    <span><?php echo e(count($projet?->individuelles?->where('projets_id', $projet?->id)?->where('users_id', $user?->id))); ?></span>
                                                </div>
                                                <div class="ps-3">
                                                    <span>
                                                        <span
                                                            class="btn btn-sm <?php echo e($projet?->statut); ?>"><?php echo e($projet?->statut); ?></span><br>
                                                        <span
                                                            class="text-muted small pt-2 ps-1"><?php echo e('Clôture, le ' . date_format(date_create($projet?->date_fermeture), 'd/m/Y')); ?></span>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employe-view')): ?>
            <section class="section faq">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                        <div class="row">
                            <div class="list-group">
                                <?php if(!empty(Auth::user()->employee)): ?>
                                    <?php $__currentLoopData = Auth::user()->employee->arrives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!empty($arrive)): ?>
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="table-courriers-emp">
                                                <thead class="table-default">
                                                    <tr>
                                                        <th style="width:40%;">Imputations</th>
                                                        <th style="width:15%;">Instructions DG</th>
                                                        
                                                        <th class="text-center">
                                                            <?php if (! (auth()->user()->unReadNotifications->isEmpty())): ?>
                                                                <a class="nav-link nav-icon" href="#"
                                                                    data-bs-toggle="dropdown">
                                                                    <i class="bi bi-bell"></i>
                                                                    <span
                                                                        class="badge bg-primary badge-number"><?php echo auth()->user()->unReadNotifications->count(); ?></span>
                                                                </a><!-- End Notification Icon -->
                                                                <ul
                                                                    class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                                                                    <li class="dropdown-header">
                                                                        <?php echo auth()->user()->unReadNotifications->count(); ?> nouveaux commentaires non lus
                                                                        <a href="<?php echo e(url('notifications')); ?>" target="_blank"><span
                                                                                class="badge rounded-pill bg-primary p-2 ms-2">Voir
                                                                                tous</span></a>
                                                                    </li>
                                                                </ul>
                                                            <?php endif; ?>
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = Auth::user()->employee?->arrives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $i = 1;
                                                        $x = 0;
                                                        $y = 0;
                                                        $z = 0;
                                                        $xy = 0;
                                                        $xz = 0;
                                                        ?>
                                                        <tr>
                                                            <td>
                                                                
                                                                <h4><a href="<?php echo route('arrives.show', $arrive?->id); ?>"><?php echo $arrive?->courrier?->objet ?? ''; ?></a>
                                                                </h4>
                                                                <?php if(isset($arrive->courrier->file)): ?>
                                                                    <label for="reference" class="form-label">Scan courrier :
                                                                    </label>
                                                                    <a class="btn btn-outline-secondary btn-sm"
                                                                        title="télécharger le fichier joint" target="_blank"
                                                                        href="<?php echo e(asset($arrive->courrier->getFile())); ?>">
                                                                        <i class="bi bi-download"></i>
                                                                    </a>
                                                                <?php endif; ?>
                                                                
                                                                <p><?php echo $arrive?->courrier?->message; ?></p>
                                                                
                                                                <div class="d-flex justify-content-between align-items-center">
                                                                    
                                                                    <small>Imputer le, <?php echo Carbon\Carbon::parse($arrive?->courrier?->date_imp)?->translatedFormat('l jS F Y'); ?></small>
                                                                    <span
                                                                        class="badge badge-info"><?php echo $arrive?->courrier?->user?->firstname; ?>&nbsp;<?php echo $arrive?->courrier?->user?->name; ?></span>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <p><?php echo $arrive?->courrier->description ?? ''; ?></p>
                                                            </td>
                                                            
                                                            <td>
                                                                <h5 class="card-title">Commentaires
                                                                    (<?php echo e(count($arrive->courrier->comments)); ?>)
                                                                </h5>
                                                                <?php $__empty_1 = true; $__currentLoopData = $arrive->courrier->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <div class="accordion accordion-flush"
                                                                        id="accordionFlushExample">
                                                                        <div class="accordion-item">
                                                                            <h2 class="accordion-header"
                                                                                id="flush-heading<?php echo e($x++); ?>">
                                                                                <button class="accordion-button collapsed"
                                                                                    type="button" data-bs-toggle="collapse"
                                                                                    data-bs-target="#flush-collapse<?php echo e($z++); ?>"
                                                                                    aria-expanded="false"
                                                                                    aria-controls="flush-collapse<?php echo e($xy++); ?>">
                                                                                    Commentaire # <?php echo e($i++); ?>

                                                                                </button>
                                                                            </h2>
                                                                            <div id="flush-collapse<?php echo e($xz++); ?>"
                                                                                class="accordion-collapse collapse"
                                                                                aria-labelledby="flush-heading<?php echo e($y++); ?>"
                                                                                data-bs-parent="#accordionFlushExample">
                                                                                <div class="accordion-body">
                                                                                    <span><?php echo $comment?->user?->firstname . ' ' . $comment?->user?->name; ?></span>
                                                                                    <div class="activity">
                                                                                        <div
                                                                                            class="activity-item d-flex col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                                                            <div
                                                                                                class="activite-label col-2 col-md-2 col-lg-2 col-sm-2 col-xs-2 col-xxl-2">
                                                                                                <?php echo Carbon\Carbon::parse($comment?->created_at)?->diffForHumans(); ?>

                                                                                            </div>
                                                                                            &nbsp;
                                                                                            <i
                                                                                                class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
                                                                                            &nbsp;
                                                                                            <div
                                                                                                class="activity-content col-10 col-md-10 col-lg-10 col-sm-10 col-xs-10 col-xxl-10">
                                                                                                <?php echo $comment->content; ?>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <?php
                                                                                    $a = 1;
                                                                                    $b = '1a';
                                                                                    $c = '1a';
                                                                                    $d = '1a';
                                                                                    $e = '1a';
                                                                                    $f = '1a';
                                                                                    ?>
                                                                                    <h5 class="card-title">Réponses au
                                                                                        commentaire #
                                                                                        <?php echo e($i - 1); ?></h5>
                                                                                    <div class="activity">
                                                                                        <?php $__empty_2 = true; $__currentLoopData = $comment->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replayComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                                            <div
                                                                                                class="row col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                                                                <label for=""
                                                                                                    class="col-1 col-md-1 col-lg-1 col-sm-1 col-xs-1 col-xxl-1"></label>
                                                                                                <div
                                                                                                    class="col-11 col-md-11 col-lg-11 col-sm-11 col-xs-11 col-xxl-11">

                                                                                                    <h2 class="accordion-header"
                                                                                                        id="flush-heading<?php echo e($b++); ?>">
                                                                                                        <button
                                                                                                            class="accordion-button collapsed"
                                                                                                            type="button"
                                                                                                            data-bs-toggle="collapse"
                                                                                                            data-bs-target="#flush-collapse<?php echo e($d++); ?>"
                                                                                                            aria-expanded="false"
                                                                                                            aria-controls="flush-collapse<?php echo e($e++); ?>">
                                                                                                            Réponse #
                                                                                                            <?php echo e($a++); ?>

                                                                                                        </button>
                                                                                                    </h2>
                                                                                                    

                                                                                                    <div id="flush-collapse<?php echo e($f++); ?>"
                                                                                                        class="accordion-collapse collapse"
                                                                                                        aria-labelledby="flush-heading<?php echo e($c++); ?>"
                                                                                                        data-bs-parent="#accordionFlushExample">
                                                                                                        <div
                                                                                                            class="accordion-body">
                                                                                                            <span><?php echo $comment?->user?->firstname . ' ' . $comment?->user?->name; ?></span>
                                                                                                            <div
                                                                                                                class="activity-item d-flex">
                                                                                                                <div
                                                                                                                    class="activite-label col-3 col-md-3 col-lg-3 col-sm-3 col-xs-3 col-xxl-3">
                                                                                                                    
                                                                                                                    <?php echo Carbon\Carbon::parse($replayComment?->created_at)?->diffForHumans(); ?>

                                                                                                                </div>
                                                                                                                &nbsp;
                                                                                                                <i
                                                                                                                    class='bi bi-circle-fill activity-badge text-info align-self-start'></i>
                                                                                                                &nbsp;
                                                                                                                <div
                                                                                                                    class="activity-content col-8 col-md-8 col-lg-8 col-sm-8 col-xs-8 col-xxl-8">
                                                                                                                    <?php echo $replayComment?->content; ?>

                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                                            <div class="alert alert-info">Aucune
                                                                                                réponse à ce commentaire</div>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                                    <div class="alert alert-info">Aucun commentaire pour ce
                                                                        courrier
                                                                    </div>
                                                                <?php endif; ?>

                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-info"> <?php echo e(__("Vous n'avez pas de courrier à votre nom")); ?> </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="alert alert-info"> <?php echo e(__("Vous n'êtes pas encore employé")); ?> </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-courriers-emp', {
            /* layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            }, */
            /* "order": [
                [0, 'desc']
            ], */

            "lengthMenu": [
                [1, 5, 10, 25, 50, 100, -1],
                [1, 5, 10, 25, 50, 100, "Tout"]
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-ap\resources\views/profile/profile-page.blade.php ENDPATH**/ ?>