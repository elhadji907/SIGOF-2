<div class="card">
    <div class="card-body pb-0">
        <h5 class="card-title">Actualités <span>| Derniers événements</span></h5>
        <div class="news mb-5">
            <?php $__currentLoopData = App\Models\Poste::orderBy("created_at", "desc")->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-item clearfix" data-bs-toggle="modal" data-bs-target="#ShowPostModal<?php echo e($poste->id); ?>">
                    <img src="<?php echo e(asset($poste->getPoste())); ?>" class="w-20" alt="<?php echo e($poste->legende); ?>">
                    <h4><a href="#"><?php echo e($poste->legende); ?></a></h4>
                    <p><?php echo e(substr($poste->name, 0, 90)); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__currentLoopData = App\Models\Poste::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div
        class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12 d-flex flex-column align-items-center justify-content-center">
        <div class="modal fade" id="ShowPostModal<?php echo e($poste->id); ?>" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <form method="post" action="#" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="card-header text-center bg-gradient-default">
                            <h1 class="h4 text-black mb-0"><?php echo e($poste->legende); ?></h1>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">

                                <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                    <img src="<?php echo e(asset($poste->getPoste())); ?>" class="d-block w-100"
                                        alt="<?php echo e($poste->legende); ?>">
                                </div>
                                <p><?php echo e($poste->name); ?>


                            </div>
                            <div class="modal-footer mt-5">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-bs-dismiss="modal">Fermer</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/actualite.blade.php ENDPATH**/ ?>