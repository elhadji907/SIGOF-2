
<?php $__env->startSection('title', 'ONFP - traitement dossiers agrément operateurs'); ?>
<?php $__env->startSection('space-work'); ?>

    <div class="pagetitle">
        
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Données</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">
                            
                            
                            <a href="#">
                                <div class="card-body">
                                    <h5 class="card-title">Operateurs <span>| Nouvelle</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e($operateur_new); ?>

                                            </h6>
                                            <span
                                                class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_new, 2, ',', ' ') . '%'); ?></span>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">
                            
                            
                            <a href="#">
                                <div class="card-body">
                                    <h5 class="card-title">Opérateurs <span>| Renouvellement</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e($operateur_renew); ?>

                                            </h6>
                                            <span
                                                class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_renew, 2, ',', ' ') . '%'); ?></span>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Traitement dossiers agrément opérateurs</h5>
                        <table class="table datatables table-bordered table-hover align-middle table-striped"
                            id="table-operateurs">
                            <thead>
                                <tr>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-dossier-operateur')): ?>
                                        <th width="5%" class="text-center">Dossier</th>
                                    <?php endif; ?>
                                    <th width="5%" class="text-center">Année</th>
                                    <th width="5%" class="text-center">Type</th>
                                    <th width="55%" class="text-center">Opérateurs</th>
                                    <th width="10%" class="text-center">Sigle</th>
                                    <th width="15%" class="text-center">Statut</th>
                                    <th width="5%"><i class="bi bi-gear"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $operateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-dossier-operateur')): ?>
                                            <td class="text-center"><?php echo e($operateur?->numero_dossier); ?></td>
                                        <?php endif; ?>
                                        <td style="text-align: center"><?php echo e($operateur?->annee_agrement?->format('Y')); ?></td>
                                        <td style="text-align: center"><span class="<?php echo e($operateur->type_demande); ?>">
                                                <?php echo e($operateur?->type_demande); ?></span></td>
                                        <td><?php echo e($operateur?->user?->operateur); ?></td>
                                        <td><?php echo e($operateur?->user?->username); ?></td>
                                        <td style="text-align: center"><span class="<?php echo e($operateur->statut_agrement); ?>">
                                                <?php echo e($operateur?->statut_agrement); ?></span></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agrement-show')): ?>
                                                <span class="d-flex align-items-baseline"><a
                                                        href="<?php echo e(route('showAgrement', ['id' => $operateur->id])); ?>"
                                                        class="btn btn-primary btn-sm" title="voir détails"><i
                                                            class="bi bi-eye"></i></a>
                                                    
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-operateurs', {
            layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            },
            "order": [
                [4, 'desc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/operateurs/agrements/index.blade.php ENDPATH**/ ?>