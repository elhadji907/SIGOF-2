
<?php $__env->startSection('title', 'Détails courrier arrivé'); ?>

<?php $__env->startSection('space-work'); ?>
    <section class="section profile">
        <div class="row">
            <?php if($message = Session::get('status')): ?>
                <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show" role="alert">
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <span class="d-flex mt-2 align-items-baseline"><a href="<?php echo e(route('arrives.index')); ?>"
                    class="btn btn-success btn-sm" title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                <p> | Liste des courriers arrivés</p>
            </span>
            

            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">

                <div class="card border-info mb-3">
                    <div class="card-body pt-3">
                        <!-- Bordered Tabs -->
                        <ul class="nav nav-tabs nav-tabs-bordered">

                            <li class="nav-item">
                                <button class="nav-link active" data-bs-toggle="tab"
                                    data-bs-target="#profile-overview">Courrier</button>
                            </li>

                            

                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab"
                                    data-bs-target="#modifier_courrier">Modifier</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab"
                                    data-bs-target="#imputer_courrier">Imputer</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link" data-bs-toggle="tab"
                                    data-bs-target="#profile-settings">Commentaires</button>
                            </li>
                        </ul>

                        <div class="tab-content pt-0">

                            <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                <h5 class="card-title">Objet</h5>
                                <p class="small fst-italic"><?php echo e($arrive->courrier->objet); ?>.</p>

                                <h5 class="card-title">Détails</h5>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Date arrivé</div>
                                    <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->date_recep?->translatedFormat('l jS F Y')); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Date correspondance</div>
                                    <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->date_cores?->translatedFormat('l jS F Y')); ?>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">N° correspondance</div>
                                    <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->numero); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label">Année</div>
                                    <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->annee); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Expéditeur</div>
                                    <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->expediteur); ?></div>
                                </div>
                                <div class="row">
                                    <?php if(isset($arrive->courrier->reference)): ?>
                                        <div class="col-lg-3 col-md-4 label">Référence</div>
                                        <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->reference); ?></div>
                                    <?php endif; ?>
                                </div>

                                <?php if(isset($arrive->courrier->numero_reponse)): ?>
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">N° réponse</div>
                                        <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->numero_reponse); ?></div>
                                        <div class="col-lg-3 col-md-4 label">Date réponse</div>
                                        <div class="col-lg-3 col-md-4"><?php echo e($arrive->courrier->date_reponse->format('d/m/Y')); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(isset($arrive->courrier->observation)): ?>
                                    <h5 class="card-title">Observations</h5>
                                    <p class="small fst-italic"><?php echo e($arrive->courrier->observation); ?>.</p>
                                <?php endif; ?>

                                <div class="row">
                                    <div class="col-lg-3 col-md-4 label ">Imputation</div>
                                    <div class="col-lg-9 col-md-8">
                                        <?php $i = 1; ?>
                                        <?php $__currentLoopData = $arrive?->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <br><?php echo e($i++); ?>. <?php echo $employee?->user?->firstname . ' ' . $employee?->user?->name; ?>

                                            <b>[<?php echo $employee?->direction?->sigle ?? ''; ?>]</b>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>


                            </div>

                            <div class="tab-pane fade pt-3" id="profile-settings">

                                <!-- Settings Form -->

                                <form method="POST" action="<?php echo e(route('comments.store', $arrive->courrier)); ?>"
                                    class="mt-3">
                                    <?php echo csrf_field(); ?>
                                    <div class="row mb-3">
                                        <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Commentaires</label>
                                        <div class="col-md-8 col-lg-9">

                                            <div class="form-floating mb-3">
                                                <textarea class="form-control <?php $__errorArgs = ['commentaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ecrire votre commentaire ici..."
                                                    name="commentaire" id="commentaire" style="height: 100px;"></textarea>
                                                <label for="floatingTextarea">Ecrire votre commentaire ici</label>
                                            </div>
                                            <small id="emailHelp" class="form-text text-muted">
                                                <?php if($errors->has('commentaire')): ?>
                                                    <?php $__currentLoopData = $errors->get('commentaire'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <p class="text-danger"><?php echo e($message); ?></p>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </small>

                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary">Poster</button>
                                    </div>
                                </form><!-- End settings Form -->
                                <hr>
                                <h3 class="card-title text-center">Commentaires</h3>
                                <?php $__empty_1 = true; $__currentLoopData = $arrive->courrier->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="card mt-2">
                                        <div class="card-body">
                                            <div><?php echo $comment->content; ?>

                                                <div class="d-flex justify-content-between align-items-center mt-2">
                                                    
                                                    <small>Posté le <?php echo Carbon\Carbon::parse($comment->created_at)->diffForHumans(); ?></small>
                                                    <span
                                                        class="badge bg-info mx-1"><?php echo $comment->user->firstname ?? ''; ?>&nbsp;<?php echo $comment->user->name ?? ''; ?></span>
                                                </div>
                                            </div>
                                            <div>
                                                <solution-button></solution-button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php $__currentLoopData = $comment->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replayComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row mb-3">
                                            <label for="" class="col-md-1 col-lg-1 col-form-label"></label>
                                            <div class="col-md-11 col-lg-11">
                                                <div class="card form-floating mb-3">
                                                    <div class="card-body">
                                                        <?php echo $replayComment->content; ?>

                                                        <div
                                                            class="d-flex justify-content-between align-items-center mt-2">
                                                            <small>Posté le <?php echo Carbon\Carbon::parse($replayComment->created_at)->diffForHumans(); ?></small>
                                                            <span
                                                                class="badge bg-primary mx-1"><?php echo $replayComment->user->firstname ?? ''; ?>&nbsp;<?php echo $replayComment->user->name ?? ''; ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(auth()->guard()->check()): ?>
                                        <button class="btn btn-info btn-sm mt-0 mb-2" id="commentReplyId"
                                            onclick="toggleReplayComment(<?php echo e($comment->id); ?>)">
                                            Répondre
                                        </button>
                                        <form method="POST" action="<?php echo e(route('comments.storeReply', $comment)); ?>"
                                            class="ml-5 d-none" id="replayComment-<?php echo e($comment->id); ?>">
                                            <?php echo csrf_field(); ?>



                                            <div class="row mb-3">
                                                <label for="fullName" class="col-md-4 col-lg-3 col-form-label">Réponse
                                                    commentaires</label>
                                                <div class="col-md-8 col-lg-9">

                                                    <div class="form-floating mb-3">
                                                        <textarea class="form-control <?php $__errorArgs = ['replayComment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Répondre à ce commentaire"
                                                            name="replayComment" id="replayComment" style="height: 100px;"></textarea>
                                                        <label for="floatingTextarea">Répondre à ce commentaire</label>
                                                    </div>
                                                    <small id="emailHelp" class="form-text text-muted">
                                                        <?php if($errors->has('replayComment')): ?>
                                                            <?php $__currentLoopData = $errors->get('replayComment'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <p class="text-danger"><?php echo e($message); ?></p>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </small>

                                                    <button class="btn btn-primary btn-sm m-2">
                                                        Répondre à ce commentaire
                                                    </button>
                                                </div>
                                            </div>

                                            


                                            
                                        </form>
                                    <?php endif; ?>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <div class="alert alert-info">Aucun commentaire pour ce courrier</div>

                                <?php endif; ?>
                            </div>
                            <div class="tab-pane fade pt-3" id="modifier_courrier">
                                <form method="post" action="<?php echo e(url('arrives/' . $arrive->id)); ?>"
                                    enctype="multipart/form-data" class="row g-3">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="date_arrivee" class="form-label">Date arrivée<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="date" name="date_arrivee"
                                            value="<?php echo e($arrive->courrier->date_recep?->format('Y-m-d') ?? old('date_arrivee')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['date_arrivee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="date_arrivee" placeholder="Date arrivée">
                                        <?php $__errorArgs = ['date_arrivee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="numero_arrive" class="form-label">Numéro<span
                                                class="text-danger mx-1">*</span></label>
                                        <div class="input-group has-validation">
                                            <input type="number" min="0" name="numero_arrive"
                                                value="<?php echo e($arrive->numero ?? old('numero_arrive')); ?>"
                                                class="form-control form-control-sm <?php $__errorArgs = ['numero_arrive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="numero_arrive" placeholder="Numéro de correspondance">
                                            <?php $__errorArgs = ['numero_arrive'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="date_correspondance" class="form-label">Date correspondance<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="date" name="date_correspondance"
                                            value="<?php echo e($arrive->courrier->date_cores?->format('Y-m-d') ?? old('date_correspondance')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['date_correspondance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="date_correspondance" placeholder="nom">
                                        <?php $__errorArgs = ['date_correspondance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="numero_correspondance" class="form-label">Numéro correspondance<span
                                                class="text-danger mx-1">*</span></label>
                                        <div class="input-group has-validation">
                                            <input type="text" min="0" name="numero_correspondance"
                                                value="<?php echo e($arrive->courrier->numero ?? old('numero_correspondance')); ?>"
                                                class="form-control form-control-sm <?php $__errorArgs = ['numero_correspondance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="numero_correspondance" placeholder="Numéro de correspondance">
                                            <?php $__errorArgs = ['numero_correspondance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="annee" class="form-label">Année<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="number" min="2024" name="annee"
                                            value="<?php echo e($arrive->courrier->annee ?? old('annee')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['annee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="annee" placeholder="Année">
                                        <?php $__errorArgs = ['annee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="expediteur" class="form-label">Expéditeur<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="text" name="expediteur"
                                            value="<?php echo e($arrive->courrier->expediteur ?? old('expediteur')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['expediteur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="expediteur" placeholder="Expéditeur">
                                        <?php $__errorArgs = ['expediteur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="objet" class="form-label">Objet<span
                                                class="text-danger mx-1">*</span></label>
                                        <input type="text" name="objet"
                                            value="<?php echo e($arrive->courrier->objet ?? old('objet')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="objet" placeholder="Objet">
                                        <?php $__errorArgs = ['objet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="reference" class="form-label">Référence</label>
                                        <input type="text" name="reference"
                                            value="<?php echo e($arrive->courrier->reference ?? old('reference')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="reference" placeholder="Référence">
                                        <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="numero_reponse" class="form-label">Numéro réponse</label>
                                        <input type="number" min="0" name="numero_reponse"
                                            value="<?php echo e($arrive->courrier->numero_reponse ?? old('numero_reponse')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['numero_reponse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="numero_reponse" placeholder="Numéro réponse">
                                        <?php $__errorArgs = ['numero_reponse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="date_reponse" class="form-label">Date réponse</label>
                                        <input type="date" min="0" name="date_reponse"
                                            value="<?php echo e($arrive->courrier->date_reponse?->format('Y-m-d') ?? old('date_reponse')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['date_reponse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="date_reponse" placeholder="Numéro réponse">
                                        <?php $__errorArgs = ['date_reponse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-12 col-lg-8 col-sm-12 col-xs-12 col-xxl-8">
                                        <label for="observation" class="form-label">Observations </label>
                                        <textarea name="observation" id="observation" rows="1" class="form-control form-control-sm"
                                            placeholder="Observations"><?php echo e(old('observation', $arrive->courrier->observation)); ?></textarea>
                                        <?php $__errorArgs = ['observation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="legende" class="form-label">Légende</label>
                                        <input type="text" name="legende"
                                            value="<?php echo e($arrive->courrier->legende ?? old('legende')); ?>"
                                            class="form-control form-control-sm <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="legende" placeholder="Le nom du fichier scanné">
                                        <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <label for="reference" class="form-label">Scan courrier</label>
                                        <input type="file" name="file" id="file"
                                            class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> btn btn-primary btn-sm">
                                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <div><?php echo e($message); ?></div>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 col-md-6 col-lg-4 col-sm-12 col-xs-12 col-xxl-4">
                                        <?php if(isset($arrive->courrier->file)): ?>
                                            <label for="reference" class="form-label">Cliquer ici pour
                                                télécharger</label><br>
                                            <a class="btn btn-outline-secondary btn-sm"
                                                title="télécharger le fichier joint" target="_blank"
                                                href="<?php echo e(asset($arrive->courrier->getFile())); ?>">
                                                <i class="bi bi-download">&nbsp;Cliquer ici pour télécharger le courrier
                                                    scanné</i>
                                            </a>
                                        <?php endif; ?>
                                        
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn btn-outline-success btn-sm">Modifier</button>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane fade pt-3" id="imputer_courrier">
                                <div class="col-lg-12">
                                    <div class="col-sm-12 col-md-12 pt-2">

                                        <div class="card">
                                            <div class="card-body custom-edit-service">
                                                <div class="d-flex justify-content-between align-items-center mt-3">
                                                    <span><a href="<?php echo e(route('arrives.index')); ?>"
                                                            class="btn btn-success btn-sm" title="retour"><i
                                                                class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                                        | Liste des courriers arrivés
                                                    </span>

                                                    
                                                    <form action="<?php echo e(route('couponArrive')); ?>" method="post"
                                                        target="_blank">
                                                        <?php echo csrf_field(); ?>
                                                        
                                                        <input type="hidden" name="id"
                                                            value="<?php echo e($arrive->id); ?>">
                                                        <button class="btn btn-outline-primary btn-sm"><i
                                                                class="fa fa-print" aria-hidden="true"></i>Télécharger
                                                            coupon</button>
                                                    </form>
                                                </div>
                                                <?php echo csrf_field(); ?>
                                                <div class="row form-row pt-3">
                                                    <div class="pb-1"><b>Expéditeur:</b>
                                                        <?php echo e($arrive->courrier->expediteur); ?></div>
                                                    <div class="pb-3"><b>Objet:</b> <?php echo e($arrive->courrier->objet); ?></div>
                                                    
                                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                                        <div class="form-group">
                                                            <label for="">Employé</label>
                                                            <input type="text" placeholder="rechercher employé..."
                                                                class="form-control form-control-sm <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="product" id="product" value=""
                                                                <?php if(true): echo 'required'; endif; ?>>
                                                            <div class="col-lg-6" id="productList">
                                                            </div>
                                                            <?php $__errorArgs = ['product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <div><?php echo e($message); ?></div>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-6">
                                                        <div class="form-group">
                                                            <label for="">Direction/Service/Cellule</label>
                                                            <input type="text" placeholder="Personne responsable"
                                                                class="form-control form-control-sm <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="direction" id="direction" value="" readonly>
                                                            <?php $__errorArgs = ['direction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <div><?php echo e($message); ?></div>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            <input type="hidden" name="id_direction" id="id_direction" value="" readonly>
                                                        </div>
                                                    </div>

                                                    <input type="hidden" placeholder="ID"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['id_emp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="id_emp" id="id_emp" value="0.0" min="0">
                                                    <input type="hidden" placeholder="imp"
                                                        class="form-control form-control-sm <?php $__errorArgs = ['imp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="imp" id="imp" value="1">

                                                    <div class="col-xs-12 col-sm-12 col-md-12 pt-3 text-center">
                                                        <button id="addMore" class="btn btn-success btn-sm"><i
                                                                class="fa fa-plus"
                                                                aria-hidden="true"></i>&nbsp;Ajouter</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <form method="post" action="<?php echo e(url('arrives/' . $arrive->id)); ?>"
                                            enctype="multipart/form-data" class="row g-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            
                                            <div class="table-responsive">
                                                <table class="table table-bordered" style="display: none;">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 50%">Direction</th>
                                                            <th>Responsable</th>
                                                            <th style="width: 5%">#</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="addRow" class="addRow">
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="1" class="">
                                                                
                                                                <label for="description" class="form-label">Actions
                                                                    attendues<span
                                                                        class="text-danger mx-1">*</span></label>
                                                                <select name="description"
                                                                    class="form-select font-italic <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    aria-label="Select" id="select-field-familiale"
                                                                    data-placeholder="Choisir une instruction..."
                                                                    <?php if(true): echo 'required'; endif; ?>>
                                                                    <option
                                                                        value="<?php echo e($arrive?->courrier?->description); ?>">
                                                                        <?php echo e($arrive?->courrier?->description ?? old('description')); ?>

                                                                    </option>
                                                                    <option value="Urgent">
                                                                        Urgent
                                                                    </option>
                                                                    <option value="M'en parler">
                                                                        M'en parler
                                                                    </option>
                                                                    <option value="Répondre">
                                                                        Répondre
                                                                    </option>
                                                                    <option value="Suivi">
                                                                        Suivi
                                                                    </option>
                                                                    <option value="Information">
                                                                        Information
                                                                    </option>
                                                                    <option value="Diffusion">
                                                                        Diffusion
                                                                    </option>
                                                                    <option value="Attribution">
                                                                        Attribution
                                                                    </option>
                                                                    <option value="Classement">
                                                                        Classement
                                                                    </option>
                                                                </select>
                                                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <div><?php echo e($message); ?></div>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </td>
                                                            <td colspan="1">
                                                                <strong><label
                                                                        for="date_imp"><?php echo e(__('Date imputation')); ?></label></strong>
                                                                <input id="date_imp"
                                                                    <?php echo e($errors->has('date_imp') ? 'is-invalid' : ''); ?>

                                                                    type="date"
                                                                    class="form-control form-control-sm <?php $__errorArgs = ['date_imp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    name="date_imp" placeholder="Date imputation" required
                                                                    value="<?php echo e(optional($arrive->courrier->date_imp)->format('Y-m-d') ?? old('date_imp')); ?>"
                                                                    autocomplete="date_imp">
                                                                <?php $__errorArgs = ['date_imp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <div><?php echo e($message); ?></div>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="4" class="text-center">
                                                                

                                                                <div class="text-center">
                                                                    <button type="submit"
                                                                        class="btn btn-outline-primary pull-right">Imputer</button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>

                                                </table>
                                            </div>
                                        </form>
                                        
                                        <div>
                                            <h5 class="card-title">Imputation employés</h5>
                                            
                                            <!-- Table with stripped rows -->
                                            <table class="table datatables align-middle" id="table-employes">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Matricule</th>
                                                        <th>Prénom</th>
                                                        <th>Nom</th>
                                                        <th>E-mail</th>
                                                        <th>Téléphone</th>
                                                        <th>Direction</th>
                                                        <?php if(auth()->user()->hasRole('super-admin')): ?>
                                                            <th>#</th>
                                                        <?php endif; ?>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i = 1; ?>
                                                    <?php $__currentLoopData = $arrive?->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <th scope="row"><img class="rounded-circle w-20"
                                                                    alt="Profil"
                                                                    src="<?php echo e(asset($employe->user->getImage())); ?>"
                                                                    width="40" height="auto">
                                                            </th>
                                                            
                                                            <td><?php echo e($employe?->matricule); ?></td>
                                                            <td><?php echo e($employe?->user?->firstname); ?></td>
                                                            <td><?php echo e($employe?->user?->name); ?></td>
                                                            <td><a
                                                                    href="mailto:<?php echo e($employe?->user?->email); ?>"><?php echo e($employe?->user?->email); ?></a>
                                                            </td>
                                                            <td><a href="tel:+221<?php echo e($employe?->user?->telephone); ?>"><?php echo e($employe?->user?->telephone); ?></a></td>
                                                            <td><?php echo e($employe?->direction?->name); ?></td>
                                                            <?php if(auth()->user()->hasRole('super-admin')): ?>
                                                                <td>
                                                                    <span class="d-flex mt-2 align-items-baseline"><a
                                                                            href="<?php echo e(route('employes.show', $employe->id)); ?>"
                                                                            class="btn btn-success btn-sm mx-1"
                                                                            title="voir détails"><i
                                                                                class="bi bi-eye"></i></a>
                                                                        <div class="filter">
                                                                            <a class="icon" href="#"
                                                                                data-bs-toggle="dropdown"><i
                                                                                    class="bi bi-three-dots"></i></a>
                                                                            <ul
                                                                                class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                                
                                                                                
                                                                            </ul>
                                                                        </div>
                                                                    </span>
                                                                </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

                                    <link rel="stylesheet"
                                        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
                                    <script src="//code.jquery.com/jquery.js"></script>
                                    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.7.6/handlebars.min.js"></script>
                                    <script id="document-template" type="text/x-handlebars-template">
                                        <tr class="delete_add_more_item" id="delete_add_more_item">    
                                            <td>
                                                <input type="hidden" name="id_emp[]" value="{{ id_emp }}" required placeholder="Id Employé" class="form-control form-control-sm">
                                                <input type="text" name="product[]" value="{{ product }}" required placeholder="Employé" class="form-control form-control-sm" readonly>                            
                                                <input type="hidden" name="imp" value="{{ imp }}">
                                            </td>
                                            <td>
                                                <input type="text" class="direction form-control form-control-sm" name="direction[]" value="{{ direction }}" required min="1" placeholder="Le nom du responsable" readonly>
                                                <input type="hidden" class="direction form-control form-control-sm" name="id_direction[]" value="{{ id_direction }}" required min="1" placeholder="Le nom du responsable">
                                          </td>
                                            <td>
                                            <i class="removeaddmore" style="cursor:pointer;color:red;" title="supprimer"><i class="bi bi-trash"></i></i>
                                            </td>    
                                        </tr>
                                        </script>
                                    <script type="text/javascript">
                                        $(document).on('click', '#addMore', function() {
                                            $('.table').show();
                                            var product = $("#product").val();
                                            var id_emp = $("#id_emp").val();
                                            var direction = $("#direction").val();
                                            var id_direction = $("#id_direction").val();
                                            var imp = $("#imp").val();
                                            var source = $("#document-template").html();
                                            var template = Handlebars.compile(source);
                                            var data = {
                                                product: product,
                                                id_emp: id_emp,
                                                direction: direction,
                                                id_direction: id_direction,
                                                imp: imp,
                                            }
                                            var html = template(data);
                                            $("#addRow").append(html)
                                            total_ammount_price();
                                        });
                                        $(document).on('click', '.removeaddmore', function(event) {
                                            $(this).closest('.delete_add_more_item').remove();
                                            total_ammount_price();
                                        });

                                        $('#product').keyup(function() {
                                            var query = $(this).val();
                                            if (query != '') {
                                                var _token = $('input[name="_token"]').val();
                                                $.ajax({
                                                    url: "<?php echo e(route('arrive.fetch')); ?>",
                                                    method: "POST",
                                                    data: {
                                                        query: query,
                                                        _token: _token
                                                    },
                                                    success: function(data) {
                                                        $('#productList').fadeIn();
                                                        $('#productList').html(data);
                                                    }
                                                });
                                            }
                                        });
                                        $(document).on('click', 'li', function() {
                                            $('#product').val($(this).text());
                                            $('#id_emp').val($(this).data("id"));
                                            $('#direction').val($(this).data("direction"));
                                            $('#id_direction').val($(this).data("iddirection"));
                                            $('#productList').fadeOut();
                                        });
                                    </script>
                                </div>
                            </div>
                        </div><!-- End Bordered Tabs -->

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function toggleReplayComment(id) {
            let element = document.getElementById('replayComment-' + id);
            element.classList.toggle('d-none');
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/courriers/arrives/show.blade.php ENDPATH**/ ?>