<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title><?php echo e($title); ?></title>

    <!-- Favicons -->
    <link href="<?php echo e(asset('assets/img/favicon-onfp.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
    <style>
        @page {
            margin: 0cm 0cm;
        }

        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 25px;
            border: 0px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            font-size: 13px;
            line-height: 22px;
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            color: #555;
        }

        /** RTL **/
        .rtl {
            imputation: rtl;
        }

        .invoice-box table tr.heading td {
            background: rgb(255, 255, 255);
            border: 0px solid #000000;
            border-collapse: collapse;
            font-weight: bold;
        }


        .invoice-box table tr.total td {
            /* border-top: 2px solid #eee;
            border-bottom: 1px solid #eee;
            border-left: 1px solid #eee;
            border-right: 1px solid #eee; */
            /* background: #eee;
            font-weight: normal; */
        }

        /* .invoice-box table tr.item td {
            border: 1px solid #000000;
        } */

        table {
            /* border-left: 0px solid rgb(0, 0, 0);
            border-right: 0;
            border-top: 0px solid rgb(0, 0, 0);
            border-bottom: 0; */
            width: 100%;
            /* border-spacing: 0px; */
            border-collapse: collapse;
        }

        table td,
        table th {
            border-left: 1px solid rgb(0, 0, 0);
            border-right: 1px solid rgb(0, 0, 0);
            border-top: 1px solid rgb(0, 0, 0);
            border-bottom: 1px solid rgb(0, 0, 0);
            border: 1px solid;
        }

        .Oui {
            color: #198754;
            text-align: center;
        }

        .Non {
            color: #DC3545;
            padding: 4px 8px;
            text-align: center;
        }

        footer {
            position: fixed;
            bottom: 0cm;
            left: 0cm;
            right: 0cm;
            height: 2cm;

            /** Extra personal styles **/
            background-color: #ffffff;
            color: rgb(0, 0, 0);
            text-align: center;
            line-height: 1.5cm;
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="//db.onlinewebfonts.com/c/dd79278a2e4c4a2090b763931f2ada53?family=ArialW02-Regular" rel="stylesheet"
        type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>
    <h6 valign="top" style="text-align: center;">
        <b>REPUBLIQUE DU SENEGAL<br></b>
        Un Peuple - Un But - Une Foi<br>
        <b>********<br>
            MINISTERE DE LA FORMATION PROFESSIONNELLE<br>
            ********<br>
            <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('assets/img/logo-onfp.jpg')))); ?>"
                style="width: 100%; max-width: 300px" />
        </b>
    </h6>
    <h4 style="text-align: center;">FICHE DE SYNTHESE DU DOSSIER D'AGREMENT
        <?php echo e('DU ' . $commission?->date?->format('d/m/Y')); ?></h4>
    <?php $__currentLoopData = $commission?->operateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="invoice-box">
            <table class="table table-responsive">
                <thead>
                    <tr class="heading">
                        <td colspan="3" width="40%">DOSSIER D'AGREMENT N° : <span
                                style="color: red"><?php echo e($operateur?->numero_dossier); ?></span></td>
                        <td colspan="2"></td>
                        <td colspan="3" width="40%">COURRIER ARRIVEE N° : <span
                                style="color: red"><?php echo e($operateur?->numero_arrive); ?></span></td>
                    </tr>
                </thead>
                <tbody>
                    <tr class="item">
                        <td><b><?php echo e(__("DENOMINATION DE L'OPERATEUR")); ?></b></td>
                        <td colspan="6"><?php echo e($operateur?->user?->operateur); ?>

                            <?php if(!empty($operateur?->user?->username)): ?>
                                <?php echo e('(' . $operateur?->user?->username . ')'); ?>

                            <?php endif; ?>
                        </td>
                        <td colspan="1" width="10%" style="text-align: center;">
                            <b><?php echo e(__('VISITE DE CONFORMITE')); ?></b>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('RESPONSABLE')); ?></b></td>
                        <td colspan="6">
                            <?php if(!empty($operateur?->user?->firstname)): ?>
                                <?php echo e($operateur?->user?->firstname); ?>

                            <?php endif; ?>
                            <?php if(!empty($operateur?->user?->name)): ?>
                                <?php echo e($operateur?->user?->name); ?>

                            <?php endif; ?>
                        </td>
                        <td rowspan="13" colspan="1" width="10%" style="text-align: center;">
                            <?php if(!empty($operateur?->visite_conformite)): ?>
                                <span
                                    class="<?php echo e($operateur?->visite_conformite); ?>"><?php echo e($operateur?->visite_conformite); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('CIVILITE')); ?></b></td>
                        <td colspan="6">
                            <?php if(!empty($operateur?->user?->civilite)): ?>
                                <?php echo e($operateur?->user?->civilite); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('TITRE')); ?></b></td>
                        <td colspan="6">
                            <?php if(!empty($operateur?->user?->fonction_responsable)): ?>
                                <?php echo e($operateur?->user?->fonction_responsable); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('ADRESSE')); ?></b></td>
                        <td colspan="6">
                            <?php if(!empty($operateur?->user?->adresse)): ?>
                                <?php echo e($operateur?->user?->adresse); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('CONTACTS')); ?></b></td>
                        <td colspan="3">
                            <?php if(!empty($operateur?->user?->fixe)): ?>
                                Tél 1 : <a
                                    href="tel:+<?php echo e($operateur?->user?->fixe); ?>"><?php echo e($operateur?->user?->fixe); ?></a>
                            <?php endif; ?>
                            <?php if(!empty($operateur?->user?->telephone)): ?>
                                / <a
                                    href="tel:+<?php echo e($operateur?->user?->telephone); ?>"><?php echo e($operateur?->user?->telephone); ?></a>
                            <?php endif; ?>
                            <br>
                            <?php if(!empty($operateur?->user?->telephone_parent)): ?>
                                Tél 2 : <a
                                    href="tel:+<?php echo e($operateur?->user?->telephone_parent); ?>"><?php echo e($operateur?->user?->telephone_parent); ?></a>
                            <?php endif; ?>
                        </td>
                        <td colspan="3">
                            <?php if(!empty($operateur?->user?->email)): ?>
                                Email 1 : <a
                                    href="mailto:<?php echo e($operateur?->user?->email); ?>"><?php echo e($operateur?->user?->email); ?></a>
                            <?php endif; ?>
                            <br>
                            <?php if(!empty($operateur?->user->email_responsable)): ?>
                                Email 2 : <a
                                    href="mailto:<?php echo e($operateur?->user?->email_responsable); ?>"><?php echo e($operateur?->user?->email_responsable); ?></a>
                            <?php endif; ?>
                            <br>
                            <?php if(!empty($operateur?->user?->web)): ?>
                                Web : <?php echo e($operateur?->user?->web); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td><b><?php echo e(__('STATUT JURIDIQUE')); ?></b></td>
                        <td colspan="6">
                            <?php if(!empty($operateur?->statut)): ?>
                                <?php echo e($operateur?->statut); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td rowspan="7"><b><?php echo e(__('DOSSIERS FOURNIS')); ?></b></td>
                        <td colspan="6">
                            Demande d'agrément signée :
                            <?php if(!empty($operateur?->demande_signe)): ?>
                                <?php echo e($operateur?->demande_signe); ?>

                            <?php else: ?>
                                Non
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="6">
                            Formulaire de demande d'agrément renseigné, daté et signé :
                            <?php if(!empty($operateur?->formulaire_signe)): ?>
                                <?php echo e($operateur?->formulaire_signe); ?>

                            <?php else: ?>
                                Non
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="3" rowspan="3">
                            Actes de création de l'entreprise
                        </td>
                        <td colspan="3">
                            RCCM / NINEA : <?php echo e($operateur?->user?->rccm); ?>

                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="3">
                            Numéro : <span style="color: red"><?php echo e($operateur?->user?->ninea); ?></span>
                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="3">
                            Arrêté :
                            <?php if(!empty($operateur?->arrete_creation)): ?>
                                <?php echo e($operateur?->arrete_creation); ?>

                            <?php else: ?>
                                Non
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="6">
                            CV formateur(s) daté(s) et signé(s) :
                            <?php echo e($operateur?->cvsigne); ?>

                        </td>
                    </tr>
                    <tr class="item">
                        <td colspan="6">
                            Quitus fiscal ou récépissé de dépôt du quitus fiscal :
                            <?php echo e($operateur?->quitusfiscal); ?>

                        </td>
                    </tr>
                </tbody>
            </table>

            <div style="page-break-after: always;"></div>

            <div class="invoice-box">
                <table class="table table-responsive mt-10">
                    <tbody>
                        <tr class="item">
                            <td rowspan="<?php echo e(count($operateur?->operateurmodules) + 1); ?>">
                                <b><?php echo e(__("DOMAINES D'INTERVENTION")); ?></b>
                            </td>

                            <td colspan="3">
                                <b>DOMAINE</b>
                            </td>

                            <td colspan="4">
                                <b>MODULE</b>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $operateur?->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                <td colspan="3">
                                    <?php echo e($operateurmodule?->domaine); ?>

                                </td>

                                <td colspan="4">
                                    <?php echo e($operateurmodule?->module); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="item">
                            <td rowspan="<?php echo e(count($operateur->operateurformateurs) + 1); ?>">
                                <b><?php echo e(__('COMPETENCES DISPONIBLES (formateurs)')); ?></b>
                            </td>

                            <td colspan="3">
                                <b>Nom formateur</b>
                            </td>

                            <td colspan="4">
                                <b>Champs profes. et années d'expérience</b>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $operateur?->operateurformateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurformateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                <td colspan="3">
                                    <?php echo e($operateurformateur?->name); ?>

                                </td>

                                <td colspan="4">
                                    <?php echo e($operateurformateur?->domaine . ' (' . $operateurformateur?->nbre_annees_experience . ' ans)'); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div style="page-break-after: always;"></div>

            <div class="invoice-box">
                <table class="table table-responsive mt-10">
                    <tbody>
                        <tr class="item">
                            <td rowspan="<?php echo e(count($operateur->operateurequipements) + 1); ?>">
                                <b><?php echo e(__('MOYENS PEDAGOGIQUES')); ?></b>
                            </td>

                            

                            <td colspan="6" width="100%">
                                <b>Type & Désignation</b>
                            </td>
                            <td style="text-align: center">
                                <b>Qté</b>
                            </td>
                            <td style="text-align: center">
                                <b>Etat</b>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $operateur?->operateurequipements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurequipement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                

                                <td colspan="6">
                                    <b><u>Type</u></b> : <?php echo e($operateurequipement?->type); ?> <br>
                                    <b><u>Désignation</u></b> : <?php echo e($operateurequipement?->designation); ?> <br>
                                </td>
                                <td style="text-align: center">
                                    <?php echo e($operateurequipement?->quantite); ?>

                                </td>
                                <td style="text-align: center">
                                    <?php echo e($operateurequipement?->etat); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <div style="page-break-after: always;"></div>

            <div class="invoice-box">
                <table class="table table-responsive mt-10">
                    <tbody>

                        <tr class="item">
                            <td rowspan="<?php echo e(count($operateur?->operateureferences) + 1); ?>">
                                <b><?php echo e(__('EXPERIENCES')); ?></b>
                            </td>

                            

                            <td colspan="7">
                                <b>Référence & Activités</b>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $operateur?->operateureferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateureference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                

                                <td colspan="7">
                                    <b><u>Référence</u></b> : <?php echo e($operateureference?->organisme . ','); ?>

                                    <?php echo e($operateureference?->periode); ?> <br>
                                    <?php if(!empty($operateureference?->contact)): ?>
                                        Tél : <a
                                            href="tel:+<?php echo e($operateureference?->contact); ?>"><?php echo e($operateureference?->contact); ?></a>
                                        <br>
                                    <?php endif; ?>
                                    <b><u>Description</u></b> : <?php echo e($operateureference?->description); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <tr class="item">
                            <td><b><?php echo e(__('OBSERVATIONS')); ?></b></td>
                            <td colspan="7">
                                <?php if(!empty($operateur?->observations)): ?>
                                    <?php echo e($operateur?->observations); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            
        </div>
        <div style="page-break-after: always;"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/operateurs/fichesynthese.blade.php ENDPATH**/ ?>