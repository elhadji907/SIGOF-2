

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__("ONFP E-MAIL")); ?></title>
</head>

<body>
    <header>
        
        <h1><?php echo e($subject); ?></h1>
    </header>

    <body>
        <h3>Salut ,<?php echo e($toUserName); ?></h3>
        <h4> <?php echo e($module); ?></h4>
        
        
    </body>
    <footer>
        <p>&copy; ONFP <?php echo e(date('Y')); ?></p>
        
    </footer>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formations/maildebut.blade.php ENDPATH**/ ?>