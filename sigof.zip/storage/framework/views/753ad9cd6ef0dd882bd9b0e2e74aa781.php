
<?php $__env->startSection('title', 'ajouter dans la formation'); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12 pt-0">
                                <span class="d-flex mt-0 align-items-baseline"><a
                                        href="<?php echo e(route('formations.show', $formation->id)); ?>" class="btn btn-success btn-sm"
                                        title="retour"><i class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                    <p> | Liste des formations</p>
                                </span>
                            </div>
                        </div>
                        <h5><u><b>Module</b></u> : <?php echo e($collectivemodule?->module); ?></h5>
                        <h5><u><b>Région</b></u> : <?php echo e($localite?->nom); ?></h5>
                        <h5><u><b>Sélectionnés</b></u> : <?php echo e($candidatsretenus?->count() ?? ''); ?></h5>
                        <form method="post"
                            action="<?php echo e(url('formationdemandeurscollectives', ['$idformation' => $formation->id, '$idcollectivemodule' => $formation->collectivemodule->id, '$idlocalite' => $formation->departement->region->id])); ?>"
                            enctype="multipart/form-data" class="row g-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row mb-3">
                                <div class="form-check col-md-2 pt-5">
                                    <label for="#">Choisir tout</label>
                                    <input type="checkbox" class="form-check-input" id="checkAll">
                                </div>
                                <div></div>
                                <div class="form-check col-md-12">
                                    <table class="table datatables align-middle" id="table-individuelles">
                                        <thead>
                                            <tr>
                                                <th scope="col">CIN</th>
                                                <th scope="col">Civilité</th>
                                                <th scope="col">Prénom</th>
                                                <th scope="col">Nom</th>
                                                <th scope="col">Date naissance</th>
                                                <th scope="col">Lieu naissance</th>
                                                <th scope="col">Niveau étude</th>
                                                <th scope="col">Module</th>
                                                <th scope="col">Statut</th>
                                                <th><i class="bi bi-gear"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $listecollectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listecollective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="listecollectives[]"
                                                                value="<?php echo e($listecollective->id); ?>"
                                                                <?php echo e(in_array($listecollective->formations_id, $listecollectiveFormation) ? 'checked' : ''); ?>

                                                                class="form-check-input <?php $__errorArgs = ['listecollectives'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                            <?php $__errorArgs = ['listecollectives'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <div><?php echo e($message); ?></div>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php echo e($listecollective?->cin); ?>

                                                            </td>
                                                            <td><?php echo e($listecollective?->civilite); ?></td>
                                                            <td><?php echo e($listecollective?->prenom); ?></td>
                                                            <td><?php echo e($listecollective?->nom); ?></td>
                                                            <td><?php echo e($listecollective?->date_naissance->format('d/m/Y')); ?>

                                                            </td>
                                                            <td><?php echo e($listecollective?->lieu_naissance); ?></td>
                                                            <td><?php echo e($listecollective?->niveau_etude); ?></td>
                                                            <td><?php echo e($listecollective?->collectivemodule?->module); ?></td>
                                                            <td>
                                                                <span
                                                                    class="<?php echo e($listecollective?->statut); ?>"><?php echo e($listecollective?->statut); ?></span>
                                                            </td>
                                                            <td>
                                                                <span class="d-flex align-items-baseline">
                                                                    <a href="<?php echo e(route('listecollectives.show', $listecollective?->id)); ?>"
                                                                        class="btn btn-primary btn-sm"
                                                                        title="voir détails" target="_blank"><i class="bi bi-eye"></i></a>
                                                                    <div class="filter">
                                                                        <a class="icon" href="#"
                                                                            data-bs-toggle="dropdown"><i
                                                                                class="bi bi-three-dots"></i></a>
                                                                        <ul
                                                                            class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                            <li><a class="dropdown-item btn btn-sm"
                                                                                    href="<?php echo e(route('listecollectives.edit', $listecollective->id)); ?>"
                                                                                    class="mx-1" title="Modifier"><i
                                                                                        class="bi bi-pencil"></i>Modifier</a>
                                                                            </li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-outline-primary"><i
                                                    class="bi bi-check2-circle"></i>&nbsp;Sélectionner</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/formations/collectives/add-listecollectives.blade.php ENDPATH**/ ?>