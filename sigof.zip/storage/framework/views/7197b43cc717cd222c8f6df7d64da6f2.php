
<?php $__env->startSection('title', $module->name . ' ' . $localite->nom); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="pagetitle">
                    
                    <nav>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                            <li class="breadcrumb-item">Tables</li>
                            <li class="breadcrumb-item active">Données</li>
                        </ol>
                    </nav>
                </div><!-- End Page Title -->
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="pt-1">
                            <?php if(isset($demandeur->numero_dossier)): ?>
                                <a href="<?php echo e(route('individuelles.create')); ?>"
                                    class="btn btn-primary float-end btn-rounded"><i class="fas fa-plus"></i>
                                    <i class="bi bi-person-plus" title="Ajouter"></i> </a>
                            <?php else: ?>
                                <a class="btn btn-primary float-end btn-rounded"
                                    href="<?php echo e(route('demandeurs.show', Auth::user()?->id)); ?>"><i class="bi bi-person-plus"
                                        title="Ajouter"></i> </a></a>
                            <?php endif; ?>
                        </div>
                        <h5 class="card-title"><?php echo e($localite->nom . ': ' . $module->name); ?></h5>
                        
                        <!-- Table with stripped rows -->
                        <table class="table datatables align-middle justify-content-center" id="table-modules">
                            <thead>
                                <tr>
                                   
                                    <th class="text-center">CIN</th>
                                    <th>Prénom</th>
                                    <th>NOM</th>
                                    <th>Date naissance</th>
                                    <th>Lieu naissance</th>
                                    <th>Département</th>
                                    <th>Telephone</th>
                                    <th class="text-center">Statut</th>
                                    <th class="text-center">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $individuelles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individuelle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($individuelle?->numero)): ?>
                                        <tr>
                                           
                                            <td><?php echo e($individuelle?->user?->cin); ?></td>
                                            <td><?php echo e($individuelle?->user?->firstname); ?></td>
                                            <td><?php echo e($individuelle?->user?->name); ?></td>
                                            <td><?php echo e($individuelle?->user->date_naissance?->format('d/m/Y')); ?></td>
                                            <td><?php echo e($individuelle?->user->lieu_naissance); ?></td>
                                            <td><?php echo e($individuelle?->departement?->nom); ?></td>
                                            <td><a
                                                    href="tel:+221<?php echo e($individuelle?->user->telephone); ?>"><?php echo e($individuelle?->user->telephone); ?></a>
                                            </td>
                                            <td>
                                                <a
                                                    href="<?php echo e(url('modulelocalitestatut', ['$idlocalite' => $individuelle->departement->region->id, '$idmodule' => $module?->id, '$statut' => $individuelle->statut])); ?>">
                                                    <span
                                                        class="<?php echo e($individuelle?->statut); ?>"><?php echo e($individuelle?->statut); ?></span>
                                                    
                                                </a>
                                            </td>
                                            <td>
                                                <span class="d-flex align-items-baseline"><a
                                                        href="<?php echo e(route('individuelles.show', $individuelle->id)); ?>"
                                                        class="btn btn-primary btn-sm" title="voir détails"><i
                                                            class="bi bi-eye"></i></a>
                                                    <div class="filter">
                                                        <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                                                class="bi bi-three-dots"></i></a>
                                                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                            <li><a class="dropdown-item btn btn-sm"
                                                                    href="<?php echo e(route('individuelles.edit', $individuelle->id)); ?>"
                                                                    class="mx-1" title="Modifier"><i
                                                                        class="bi bi-pencil"></i>Modifier</a>
                                                            </li>
                                                            <li>
                                                                <form
                                                                    action="<?php echo e(route('individuelles.destroy', $individuelle->id)); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="dropdown-item show_confirm"
                                                                        title="Supprimer"><i
                                                                            class="bi bi-trash"></i>Supprimer</button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-modules', {
            layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            },
            "order": [
                [2, 'desc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/modules/modulelocalite.blade.php ENDPATH**/ ?>