<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
            <li class="nav-item">
                <a class="nav-link " href="<?php echo e(url('/home')); ?>">
                    <i class="bi bi-grid"></i>
                    <span>Tableau de bord</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('courrier-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#courrier-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-envelope"></i><span>Gestion courrier</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="courrier-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('courriers')); ?>">
                            <span>Courriers</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('arrive-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('arrives')); ?>">
                                <span>Arrivés</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('depart-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('departs')); ?>">
                                <span>Départs</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('interne-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('internes')); ?>">
                                <span>Internes</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('demande-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#demande-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-folder-plus"></i><span>Gestion demandeurs</span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="demande-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('individuelle-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('individuelles')); ?>">
                                <span>Demandes individuelles</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('collective-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('collectives')); ?>">
                                <span>Demandes collectives</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pcharge-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="#">
                                <span>Demandes prise en charge</span>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('demandeur-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#demandeurs-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-folder-plus"></i><span>Mes demandes</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="demandeurs-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(route('demandesIndividuelle')); ?>">
                            <span>Individuelles</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(route('demandesCollective')); ?>">
                            <span>Collectives</span>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('devenir-operateur-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#demandeurs-operateur-nav" data-bs-toggle="collapse"
                    href="#">
                    <i class="bi bi-folder-plus"></i><span>Devenir opérateur</span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="demandeurs-operateur-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(route('devenirOperateur')); ?>">
                            <span>Agrément</span>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operateur-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#operateur-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-people-fill"></i><span>Gestion opérateurs</span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="operateur-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('operateurs')); ?>">
                            <span>Opérateurs</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agrement-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('agrement')); ?>">
                                <span>Traitement agréments</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agrement-commission')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('commissionagrements.index')); ?>">
                                <span>Commission agrément</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agrement-module')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('operateurmodules')); ?>">
                                <span>Modules</span>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#formations-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-folder-symlink-fill"></i><span><?php echo e(__('Gestion formations')); ?></span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="formations-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('formations')); ?>">
                            <span>Formations</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ingenieur-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('ingenieurs')); ?>">
                                <span>Ingénieurs</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('evaluateur-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('evaluateurs')); ?>">
                                <span>Evaluateurs</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('evaluateur-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('onfpevaluateurs')); ?>">
                                <span>Evaluateurs ONFP</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('formation-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('showConventions')); ?>">
                                <span>Conventions & DETF</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('localite-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#localite-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-globe"></i><span>Gestion localités</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="localite-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('localites')); ?>">
                            <span>Localités</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('region-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('regions')); ?>">
                                <span>Régions</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('departements')); ?>">
                            <span>Départements</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('arrondissements')); ?>">
                            <span>Arrondissement</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('communes')); ?>">
                            <span>Commune</span>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employe-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#employes-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-people"></i><span>Gestion employés</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="employes-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('/employes')); ?>">
                            <span>Employés</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('direction-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/directions')); ?>">
                                <span>Directions</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('categorie-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/categories')); ?>">
                                <span>Catégories</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fonction-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/fonctions')); ?>">
                                <span>Fonction</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('loi-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/lois')); ?>">
                                <span>Lois</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('decret-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/decrets')); ?>">
                                <span>Decret</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pv-recrutement-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/procesverbals')); ?>">
                                <span>PV</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('decision')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/decisions')); ?>">
                                <span>Décisions</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('article-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/articles')); ?>">
                                <span>Articles</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('nommination-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('/nomminations')); ?>">
                                <span>Nomminations</span>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('module-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#modules-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-layers-half"></i><span><?php echo e(__('Gestion modules')); ?></span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="modules-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('modules')); ?>">
                            <span>Modules</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('domaine-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('domaines')); ?>">
                                <span>Domaines</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('secteur-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('secteurs')); ?>">
                                <span>Secteurs</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(url('projets')); ?>">
                    <i class="bi bi-layers-half"></i>
                    <span>Gestion des projets</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projet-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(url('postes')); ?>">
                    <i class="bi bi-file-post"></i>
                    <span>Actualités</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('une-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(url('unes')); ?>">
                    <i class="bi bi-book"></i>
                    <span>A la une</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(url('user')); ?>">
                    <i class="bi bi-person-plus"></i>
                    <span>Gestion utilisateurs</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-suivi-formes-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#suivi-formes-nav" data-bs-toggle="collapse"
                    href="#">
                    <i class="bi bi-diagram-3-fill"></i><span><?php echo e(__('Suivi des formés')); ?></span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="suivi-formes-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(route('suiviformes.suivi-individuelle')); ?>">
                            <span>Individuelles</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(route('suiviformes.suivi-collective')); ?>">
                            <span>Collectives</span>
                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#autorisation-nav" data-bs-toggle="collapse"
                    href="#">
                    <i class="bi bi-key"></i><span><?php echo e(__("Contrôle d'accès")); ?></span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="autorisation-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="<?php echo e(url('roles')); ?>">
                            <span>Roles</span>
                        </a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(url('permissions')); ?>">
                                <span>Permissions</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" data-bs-target="#rapport-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-files"></i><span><?php echo e(__('Générer rapports')); ?></span><i
                        class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="rapport-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-individuelle-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('individuelles.rapport')); ?>">
                                <span>Demandes individuelles</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-collective-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('collectives.rapport')); ?>">
                                <span>Demandes collectives</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-individuelle-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('modules.rapport')); ?>">
                                <span>Demandeurs modules</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-formation-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('formations.rapport')); ?>">
                                <span>Formations</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-arrive-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('arrives.rapport')); ?>">
                                <span>Courriers arrivés</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-depart-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('departs.rapport')); ?>">
                                <span>Courriers départs</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-operateur-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('operateurs.rapport')); ?>">
                                <span>Opérateurs</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-user-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('users.rapport')); ?>">
                                <span>Utilisateurs</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-formes-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('formes.rapport')); ?>">
                                <span>Formés individuelles</span>
                            </a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rapport-formes-view')): ?>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(route('formesCollective.rapport')); ?>">
                                <span>Formés collectives</span>
                            </a>
                        </li>
                    <?php endif; ?>

                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('file-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('files.index')); ?>">
                    <i class="bi bi-files"></i> <span>Fichiers utilisateurs</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('convention-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('conventions.index')); ?>">
                    <i class="bi bi-journal"></i> <span>Conventions collectives</span>
                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('referentiel-view')): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('referentiels.index')); ?>">
                    <i class="bi bi-journals"></i> <span>Référentiels formations</span>
                </a>
            </li>
        <?php endif; ?>

    </ul>

</aside>
<?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/layout/page-sidebar.blade.php ENDPATH**/ ?>