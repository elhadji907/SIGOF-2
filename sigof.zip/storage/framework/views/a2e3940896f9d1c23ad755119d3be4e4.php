
<?php $__env->startSection('space-work'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('home-view')): ?>
        <section class="section dashboard">
            <div class="row">
                <!-- Left side columns -->
                
                
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Graphique linéaire demandes individuelles</h5>

                            <canvas id="lineChart" style="max-height: 400px;"></canvas>
                            <script>
                                document.addEventListener("DOMContentLoaded", () => {
                                    new Chart(document.querySelector('#lineChart'), {
                                        type: 'line',
                                        data: {
                                            labels: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août',
                                                'Septembre', 'Octobre', 'Novembre', 'Décembre'
                                            ],
                                            datasets: [{
                                                label: 'Graphique linéaire',
                                                data: [<?php echo e($janvier); ?>, <?php echo e($fevrier); ?>, <?php echo e($mars); ?>,
                                                    <?php echo e($avril); ?>, <?php echo e($mai); ?>, <?php echo e($juin); ?>,
                                                    <?php echo e($juillet); ?>, <?php echo e($aout); ?>, <?php echo e($septembre); ?>,
                                                    <?php echo e($octobre); ?>, <?php echo e($novembre); ?>, <?php echo e($decembre); ?>

                                                ],
                                                fill: false,
                                                borderColor: 'rgb(75, 192, 192)',
                                                tension: 0.1
                                            }]
                                        },
                                        options: {
                                            scales: {
                                                y: {
                                                    beginAtZero: true
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>

                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Diagramme circulaire demandes individulles</h5>

                            <!-- Donut Chart -->
                            <div id="donutChart" style="min-height: 365px;" class="echart"></div>

                            <script>
                                document.addEventListener("DOMContentLoaded", () => {
                                    echarts.init(document.querySelector("#donutChart")).setOption({
                                        tooltip: {
                                            trigger: 'item'
                                        },
                                        legend: {
                                            top: '5%',
                                            left: 'center'
                                        },
                                        series: [{
                                            name: 'Access From',
                                            type: 'pie',
                                            radius: ['40%', '70%'],
                                            avoidLabelOverlap: false,
                                            label: {
                                                show: false,
                                                position: 'center'
                                            },
                                            emphasis: {
                                                label: {
                                                    show: true,
                                                    fontSize: '18',
                                                    fontWeight: 'bold'
                                                }
                                            },
                                            labelLine: {
                                                show: false
                                            },
                                            data: [{
                                                    value: <?php echo e($attente); ?>,
                                                    name: 'Attente'
                                                },
                                                {
                                                    value: <?php echo e($nouvelle); ?>,
                                                    name: 'Nouvelles'
                                                },
                                                {
                                                    value: <?php echo e($retenue); ?>,
                                                    name: 'Retenues'
                                                },
                                                {
                                                    value: <?php echo e($terminer); ?>,
                                                    name: 'Terminées'
                                                },
                                                {
                                                    value: <?php echo e($rejeter); ?>,
                                                    name: 'Rejetées'
                                                }
                                            ]
                                        }]
                                    });
                                });
                            </script>
                            <!-- End Donut Chart -->

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section dashboard">
            <div class="row">
                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="row">
                        <!-- Sales Card -->
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="#">
                                    <div class="card-body">
                                        <h5 class="card-title">Individuelles<span> | aujourd'hui</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-calendar-check-fill"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    <span
                                                        class="text-primary"><?php echo e(number_format($count_today, 0, '', ' ')); ?></span>
                                                </h6>
                                                <span class="text-success small pt-1 fw-bold">Aujourd'hui</span>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('individuelles.index')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Individuelles <span>| toutes</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-file-earmark-text"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    <span
                                                        class="text-primary"><?php echo e(number_format(count($individuelles), 0, '', ' ')); ?></span>
                                                </h6>
                                                <span class="text-success small pt-1 fw-bold">Toutes</span>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('showMasculin')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Individuelles <span>| hommes</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-file-earmark-text"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    <span
                                                        class="text-primary"><?php echo e(number_format($masculin, 0, '', ' ')); ?></span>
                                                </h6>
                                                <span
                                                    class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_hommes, 2, ',', ' ') . '%'); ?></span>
                                                <span class="text-muted small pt-2 ps-1">Hommes</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="card info-card sales-card">
                                <div class="filter">
                                    <a class="icon" href="#" data-bs-toggle="dropdown"><i
                                            class="bi bi-three-dots"></i></a>
                                </div>
                                <a href="<?php echo e(route('showFeminin')); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title">Individuelles <span>| femmes</span></h5>
                                        <div class="d-flex align-items-center">
                                            <div
                                                class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-file-earmark-text"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6>
                                                    <span class="text-primary"><?php echo e(number_format($feminin, 0, '', ' ')); ?></span>
                                                </h6>
                                                <span
                                                    class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_femmes, 2, ',', ' ') . '%'); ?></span>
                                                <span class="text-muted small pt-2 ps-1">Femmes</span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </section>

        <section class="section dashboard">
            <div class="row">

                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="row">
                        <!-- Sales Card -->
                        <?php if(auth()->user()->hasRole('super-admin|admin')): ?>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="card info-card sales-card">

                                    

                                    <a href="<?php echo e(url('/user')); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title">Utilisateurs <span>| Tous</span></h5>

                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-person-plus-fill"></i>
                                                </div>
                                                <div class="ps-3">
                                                    <h6><?php echo e(number_format($total_user, 0, '', ' ')); ?></h6>
                                                    <span
                                                        class="text-success small pt-1 fw-bold"><?php echo e(number_format($email_verified_at, 2, ',', ' ') . '%'); ?></span>
                                                    <span class="text-muted small pt-2 ps-1">comptes vérifiés</span>

                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div><!-- End Sales Card -->
                        <?php endif; ?>

                        <?php if(auth()->user()->hasRole('super-admin|admin|courrier')): ?>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="card info-card sales-card">

                                    <a href="<?php echo e(url('/arrives')); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title">Courriers <span>| Arrivés</span></h5>

                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-envelope-open"></i>
                                                </div>
                                                <div class="ps-3">
                                                    <h6><?php echo e(number_format($total_arrive, 0, '', ' ')); ?></h6>
                                                    <span
                                                        class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_arrive, 2, ',', ' ') . '%'); ?></span>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </a>

                                </div>
                            </div><!-- End Sales Card -->
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="card info-card sales-card">

                                    <a href="<?php echo e(url('/departs')); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title">Courriers <span>| Départs</span></h5>

                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-envelope"></i>
                                                </div>
                                                <div class="ps-3">
                                                    <h6><?php echo e(number_format($total_depart, 0, '', ' ')); ?></h6>
                                                    <span
                                                        class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_depart, 2, ',', ' ') . '%'); ?></span>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div><!-- End Sales Card -->
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="card info-card sales-card">

                                    <a href="#">
                                        <div class="card-body">
                                            <h5 class="card-title">Courriers <span>| Internes</span></h5>

                                            <div class="d-flex align-items-center">
                                                <div
                                                    class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-envelope"></i>
                                                </div>
                                                <div class="ps-3">
                                                    <h6><?php echo e(number_format($total_interne, 0, '', ' ')); ?></h6>
                                                    <span
                                                        class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_interne, 2, ',', ' ') . '%'); ?></span>
                                                    

                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div><!-- End Sales Card -->
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/home-page.blade.php ENDPATH**/ ?>