<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>ONFP</span></strong>. Tous droits réservés
    </div>
    <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
        Conçu par <a href="https://www.onfp.sn/" target="_blank">Lamine BADJI</a>
    </div>
</footer>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>
<?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/layout/footer.blade.php ENDPATH**/ ?>