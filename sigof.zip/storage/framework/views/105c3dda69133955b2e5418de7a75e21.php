
<?php $__env->startSection('space-work'); ?>
    <div class="pagetitle">
        
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Courriers</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section dashboard">
        <div class="row">
            <!-- Left side columns -->
            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Diagramme à barres des courriers</h5>

                        <canvas id="barChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                new Chart(document.querySelector('#barChart'), {
                                    type: 'bar',
                                    data: {
                                        labels: ['Arrivés', 'Départs', 'Internes'],
                                        datasets: [{
                                            label: 'Diagramme à barres',
                                            data: [<?php echo e($arrives); ?>, <?php echo e($departs); ?>, <?php echo e($internes); ?>],
                                            backgroundColor: [
                                                'rgba(255, 99, 132, 0.2)',
                                                'rgba(255, 159, 64, 0.2)',
                                                'rgba(255, 205, 86, 0.2)',
                                            ],
                                            borderColor: [
                                                'rgb(255, 99, 132)',
                                                'rgb(255, 159, 64)',
                                                'rgb(255, 205, 86)',
                                            ],
                                            borderWidth: 1
                                        }]
                                    },
                                    options: {
                                        scales: {
                                            y: {
                                                beginAtZero: true
                                            }
                                        }
                                    }
                                });
                            });
                        </script>

                    </div>
                </div>
            </div>
            
            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Diagramme circulaire courriers</h5>

                        <!-- Donut Chart -->
                        <div id="donutChart" style="min-height: 365px;" class="echart"></div>

                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                                echarts.init(document.querySelector("#donutChart")).setOption({
                                    tooltip: {
                                        trigger: 'item'
                                    },
                                    legend: {
                                        top: '5%',
                                        left: 'center'
                                    },
                                    series: [{
                                        name: 'Access From',
                                        type: 'pie',
                                        radius: ['40%', '70%'],
                                        avoidLabelOverlap: false,
                                        label: {
                                            show: false,
                                            position: 'center'
                                        },
                                        emphasis: {
                                            label: {
                                                show: true,
                                                fontSize: '18',
                                                fontWeight: 'bold'
                                            }
                                        },
                                        labelLine: {
                                            show: false
                                        },
                                        data: [{
                                                value: <?php echo e($arrives); ?>,
                                                name: 'Arrivés'
                                            },
                                            {
                                                value: <?php echo e($departs); ?>,
                                                name: 'Départs'
                                            },
                                            {
                                                value: <?php echo e($internes); ?>,
                                                name: 'Internes'
                                            }
                                        ]
                                    }]
                                });
                            });
                        </script>
                        <!-- End Donut Chart -->

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section dashboard">
        <div class="row">

            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">

                            <a href="<?php echo e(url('/courriers')); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Courriers <span>| Tous</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-person-plus-fill"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($total_courrier); ?></h6>
                                            

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- End Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">

                            <a href="<?php echo e(url('/arrives')); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Courriers <span>| Arrivés</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-envelope-open"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($total_arrive); ?></h6>
                                            <span
                                                class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_arrive, 2, ',', ' ') . '%'); ?></span>
                                            

                                        </div>
                                    </div>
                                </div>
                            </a>

                        </div>
                    </div><!-- End Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">

                            <a href="<?php echo e(url('/departs')); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Courriers <span>| Départs</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-envelope"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($total_depart); ?></h6>
                                            <span
                                                class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_depart, 2, ',', ' ') . '%'); ?></span>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- End Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">

                            <a href="#">
                                <div class="card-body">
                                    <h5 class="card-title">Courriers <span>| Interne</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-envelope"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($total_interne); ?></h6>
                                            <span
                                                class="text-success small pt-1 fw-bold"><?php echo e(number_format($pourcentage_interne, 2, ',', ' ') . '%'); ?></span>
                                            

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div><!-- End Sales Card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/courriers/index.blade.php ENDPATH**/ ?>