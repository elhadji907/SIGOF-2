
<?php $__env->startSection('title', $commissionagrement?->commission); ?>
<?php $__env->startSection('space-work'); ?>
    <section class="section dashboard">
        <div class="pagetitle">
            
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Accueil</a></li>
                    <li class="breadcrumb-item">Tables</li>
                    <li class="breadcrumb-item active"><?php echo e($commissionagrement?->commission); ?></li>
                </ol>
            </nav>
        </div><!-- End Page Title -->
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Sales Card -->
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">
                            
                            <a href="<?php echo e(route('commissionagrements.show', $commissionagrement->id)); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Operateurs <span>| Total</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e(count($commissionagrement?->operateurs)); ?>

                                            </h6>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card sales-card">
                            
                            <a href="<?php echo e(route('showAgreer', ['id' => $commissionagrement->id])); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Opérateurs <span>| agréés</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e($operateurs_agreer_count); ?>

                                            </h6>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card revenue-card">
                            
                            <a href="<?php echo e(route('showReserve', ['id' => $commissionagrement->id])); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Opérateurs <span>| Agréés sou réserve</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e($operateurs_reserve_count); ?>

                                            </h6>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                        <div class="card info-card customers-card">
                            
                            <a href="<?php echo e(route('showRejeter', ['id' => $commissionagrement->id])); ?>">
                                <div class="card-body">
                                    <h5 class="card-title">Opérateurs <span>| Rejetés</span></h5>
                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6>
                                                <?php echo e($operateurs_rejeter_count); ?>

                                            </h6>
                                            
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <?php if($message = Session::get('status')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="d-flex mt-0 align-items-baseline"><a
                                    href="<?php echo e(route('commissionagrements.index', $commissionagrement->id)); ?>"
                                    class="btn btn-success btn-sm" title="retour"><i
                                        class="bi bi-arrow-counterclockwise"></i></a>&nbsp;
                                <p> | <?php echo e($commissionagrement?->commission); ?></p>
                            </span>
                            <h5 class="card-title">
                                <a href="<?php echo e(route('addopCommission', ['id' => $commissionagrement->id])); ?>"
                                    class="btn btn-success btn-sm" title="ajouter"><i class="bi bi-plus"></i></a>
                            </h5>
                        </div>
                        
                            <div class="row mb-0">
                                <div class="form-check col-md-12 pt-5">
                                    <table class="table datatables align-middle" id="table-operateurs">
                                        <thead>
                                            <tr>
                                                <th>N° agrément</th>
                                                <th>Opérateurs</th>
                                                <th>Sigle</th>
                                                <th class="text-center">Modules</th>
                                                <th width="15%" class="text-center">Statut</th>
                                                <th><i class="bi bi-gear"></i></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; ?>
                                            <?php $__currentLoopData = $operateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($operateur?->numero_agrement)): ?>
                                                    <tr>
                                                        <td><?php echo e($operateur?->numero_agrement); ?></td>
                                                        <td><?php echo e($operateur?->user?->operateur); ?></td>
                                                        <td><?php echo e($operateur?->user?->username); ?></td>
                                                        <td style="text-align: center;">
                                                            <?php $__currentLoopData = $operateur?->operateurmodules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operateurmodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($loop->last): ?>
                                                                    <a href="#"><span
                                                                            class="badge bg-info"><?php echo e($loop->count); ?></span></a>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <span
                                                                class="<?php echo e($operateur->statut_agrement); ?>"><?php echo e($operateur->statut_agrement); ?></span>
                                                        </td>
                                                        <td>
                                                            <span class="d-flex align-items-baseline"><a
                                                                    href="<?php echo e(route('agrements', ['id' => $operateur?->id])); ?>"
                                                                    class="btn btn-primary btn-sm"
                                                                    title="voir détails"><i class="bi bi-eye"></i></a>
                                                                <div class="filter">
                                                                    <a class="icon" href="#"
                                                                        data-bs-toggle="dropdown"><i
                                                                            class="bi bi-three-dots"></i></a>
                                                                    <ul
                                                                        class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                                                        
                                                                        <form
                                                                            action="<?php echo e(route('retirerOperateur', ['id' => $operateur->id])); ?>"
                                                                            method="post">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('PUT'); ?>
                                                                            <button
                                                                                class="show_confirm_retirer btn btn-sm mx-1"><i
                                                                                    class="bi bi-reply-fill"
                                                                                    title="Retirer"></i>&nbsp;Retirer</button>
                                                                        </form>
                                                                       
                                                                    </ul>
                                                                </div>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        new DataTable('#table-operateurs', {
            /* layout: {
                topStart: {
                    buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
                }
            }, */
            "lengthMenu": [
                [10, 25, 50, 100, -1],
                [10, 25, 50, 100, "Tout"]
            ],
            "order": [
                [2, 'desc']
            ],
            language: {
                "sProcessing": "Traitement en cours...",
                "sSearch": "Rechercher&nbsp;:",
                "sLengthMenu": "Afficher _MENU_ &eacute;l&eacute;ments",
                "sInfo": "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
                "sInfoEmpty": "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
                "sInfoFiltered": "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
                "sInfoPostFix": "",
                "sLoadingRecords": "Chargement en cours...",
                "sZeroRecords": "Aucun &eacute;l&eacute;ment &agrave; afficher",
                "sEmptyTable": "Aucune donn&eacute;e disponible dans le tableau",
                "oPaginate": {
                    "sFirst": "Premier",
                    "sPrevious": "Pr&eacute;c&eacute;dent",
                    "sNext": "Suivant",
                    "sLast": "Dernier"
                },
                "oAria": {
                    "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                    "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
                },
                "select": {
                    "rows": {
                        _: "%d lignes sÃ©lÃ©ctionnÃ©es",
                        0: "Aucune ligne sÃ©lÃ©ctionnÃ©e",
                        1: "1 ligne sÃ©lÃ©ctionnÃ©e"
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\onfp-app\resources\views/operateurs/commissionagrements/show.blade.php ENDPATH**/ ?>