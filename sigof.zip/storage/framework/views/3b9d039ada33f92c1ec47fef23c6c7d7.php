<?php $__env->startSection('space-work'); ?>
    <div class="container">
        <div class="justify-content-center">
            <section class="section dashboard">
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert"><strong><?php echo e($error); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="row">
                    <!-- Left side columns -->
                    <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                        <div class="card">
                            <div class="card-body pb-0">
                                <?php if(auth()->user()->hasRole('super-admin|admin|DEC')): ?>
                                    <div class="pt-1">
                                        <button type="button" class="btn btn-primary btn-sm float-end btn-rounded"
                                            data-bs-toggle="modal" data-bs-target="#AddPosteModal">Ajouter</button>
                                    </div>
                                <?php endif; ?>
                                <h5 class="card-title">Postes <span>| les plus récents</span></h5>
                                <div class="news mb-5">
                                    <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="post-item clearfix">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <img src="<?php echo e(asset($poste->getPoste())); ?>" class="w-20"
                                                        alt="<?php echo e($poste->legende); ?>" data-bs-toggle="modal"
                                                        data-bs-target="#ShowPostModal<?php echo e($poste->id); ?>">
                                                    <h4><a href="#"><?php echo e($poste->legende); ?></a></h4>
                                                    <p><?php echo e(substr($poste->name, 0, 250)); ?>

                                                    </p>
                                                </div>
                                                <div>
                                                    <span class="d-flex mt-2 align-items-baseline">
                                                        

                                                        <button type="button" class="dropdown-item btn btn-sm"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#EditPostModal<?php echo e($poste->id); ?>">
                                                            <i class="bi bi-pencil" title="Modifier"></i>
                                                        </button>

                                                        <form action="<?php echo e(route('postes.destroy', $poste->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="dropdown-item show_confirm btn btn-sm"
                                                                title="Supprimer"><span style="color: red"><i
                                                                        class="bi bi-trash"></i>
                                                                </span></button>
                                                        </form>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div
                class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12 d-flex flex-column align-items-center justify-content-center">
                <div class="modal fade" id="AddPosteModal" tabindex="-1">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <form method="post" action="<?php echo e(route('postes.store')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-header text-center bg-gradient-default">
                                    <h1 class="h4 text-black mb-0">CRÉER UN POST</h1>
                                </div>
                                <div class="modal-body">
                                    <div class="row g-3">

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <label for="name" class="form-label">Post<span
                                                    class="text-danger mx-1">*</span></label>
                                            <textarea name="name" id="name" rows="3"
                                                class="form-control form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ecrire votre poste ici"><?php echo e(old('name')); ?></textarea>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <label for="legende" class="form-label">Légende<span
                                                    class="text-danger mx-1">*</span></label>
                                            <textarea name="legende" id="legende" rows="1"
                                                class="form-control form-control-sm <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Légende"><?php echo e(old('legende')); ?></textarea>
                                            <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                            <label for="image" class="form-label">Image<span
                                                    class="text-danger mx-1">*</span></label>
                                            <input type="file" name="image" value="<?php echo e(old('image')); ?>"
                                                class="form-control form-control-sm <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="image" placeholder="Image">
                                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <div><?php echo e($message); ?></div>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                    <div class="modal-footer mt-5">
                                        <button type="button" class="btn btn-secondary btn-sm"
                                            data-bs-dismiss="modal">Fermer</button>
                                        <button type="submit" class="btn btn-primary btn-sm">POSTER</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12 d-flex flex-column align-items-center justify-content-center">
                    <div class="modal fade" id="ShowPostModal<?php echo e($poste->id); ?>" tabindex="-1">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <form method="post" action="#" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-header text-center bg-gradient-default">
                                        <h1 class="h4 text-black mb-0"><?php echo e($poste->legende); ?></h1>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row g-3">

                                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                <img src="<?php echo e(asset($poste->getPoste())); ?>" class="d-block w-100"
                                                    alt="<?php echo e($poste->legende); ?>">
                                            </div>
                                            <p><?php echo e($poste->name); ?>

                                            </p>

                                        </div>
                                        <div class="modal-footer mt-5">
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-bs-dismiss="modal">Fermer</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $postes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poste): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12 d-flex flex-column align-items-center justify-content-center">
                    <div class="modal fade" id="EditPostModal<?php echo e($poste->id); ?>" tabindex="-1">
                        <div class="modal-dialog modal-xl">
                            <div class="modal-content">
                                <form method="post" action="<?php echo e(route('postes.update', $poste->id)); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="card-header text-center bg-gradient-default">
                                        <h1 class="h4 text-black mb-0">MODIFICATION POST</h1>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row g-3">

                                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                <label for="name" class="form-label">Poste<span
                                                        class="text-danger mx-1">*</span></label>
                                                <textarea name="name" id="name" rows="3"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ecrire votre poste ici"><?php echo e($poste->name ?? old('name')); ?></textarea>
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xs-12 col-xxl-12">
                                                <label for="legende" class="form-label">Légende<span
                                                        class="text-danger mx-1">*</span></label>
                                                <textarea name="legende" id="legende" rows="1"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Légende"><?php echo e($poste->legende ?? old('legende')); ?></textarea>
                                                <?php $__errorArgs = ['legende'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-12 col-md-12 col-lg-10 col-sm-12 col-xs-12 col-xxl-10">
                                                <label for="image" class="form-label">Image<span
                                                        class="text-danger mx-1">*</span></label>
                                                <input type="file" name="image" value="<?php echo e(old('image')); ?>"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="image" placeholder="Image">
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <div><?php echo e($message); ?></div>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="col-12 col-md-12 col-lg-2 col-sm-12 col-xs-12 col-xxl-2">
                                                <label for="reference" class="form-label">Image</label><br>
                                                <?php if(isset($poste->image)): ?>
                                                    <div>
                                                        <img class="w-25" alt="Profil"
                                                            src="<?php echo e(asset($poste->getPoste())); ?>" width="20"
                                                            height="auto">
                                                    </div>
                                                <?php else: ?>
                                                    <div class="badge bg-warning">Aucun</div>
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                        <div class="modal-footer mt-5">
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-bs-dismiss="modal">Fermer</button>
                                            <button type="submit" class="btn btn-primary btn-sm">POSTER</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\html\sigof\resources\views/postes/index.blade.php ENDPATH**/ ?>